# Sample data — provenance, units, schema

Both files were **self-created** by `tools/generate_samples.py` (CC0 / public domain; no third-party data).

| File | What it is | Units |
|---|---|---|
| `sample_rod.stl` | ASCII STL of a 1 m long, 0.02 m radius cylinder (96 triangles). | Authored in metres; STL itself carries no unit metadata, the UI labels it "model units". |
| `sample_nodes_SYNTHETIC.csv` | **SYNTHETIC** nodal temperatures (533 nodes). **NOT an actual ANSYS export.** Values are the analytical rod solution T(x)=100-80x+500x(1-x) sampled on a cylinder lattice. | x_m,y_m,z_m metres; temperature_C degrees Celsius |

## CSV schema (what an ANSYS user would export)
Header must be exactly `node_id,x_m,y_m,z_m,temperature_C`; comma separated; one node per row; `node_id` integer and unique;
other fields finite decimals. In ANSYS Mechanical this corresponds to exporting a nodal Temperature result (e.g. *Worksheet → Export*
or APDL `*VWRITE`), converting coordinates to metres and temperature to Celsius, and writing this header. Native `.rst/.wbpj` files are not supported.
The mesh and the result are **not registered** to each other (not required).

# Dependencies, versions, licences
| Component | Version | Licence | Use |
|---|---|---|---|
| cpp-httplib (`third_party/httplib/httplib.h`) | v0.18.3 (single header, vendored, unmodified) | MIT (`third_party/httplib/LICENSE`) | localhost HTTP transport |
| C++ standard library | C++17 | compiler runtime | everything else |
| MinGW-w64 GCC 13 (posix threads), statically linked (`-static`) | 13.x | GCC runtime library exception | builds Windows exe; **no runtime DLLs shipped or needed** |
| Frontend | none (plain HTML/CSS/JS, own Canvas renderer) | original | no CDN, works offline |
| CMake | >= 3.16 | BSD-3 | build |
Dev-only (not shipped in app): Python 3 + matplotlib for `tools/make_plots.py`; Playwright for the UI smoke test run during development.

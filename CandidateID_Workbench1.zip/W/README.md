# Workbench core (PARTIAL submission - see Not Implemented)
Run: `g++ -std=c++17 -O2 -pthread src/main.cpp -o workbench && ./workbench`
or `cmake -B build && cmake --build build && ./build/workbench` (run from this folder).
Implemented & tested: Task C 1D FEA (+CSV), D serial/threaded batch, E mock devices, F backprop + FD check, STL/CSV validators.
Data: data/example.stl and data/synthetic_nodal_temps.csv are self-created SYNTHETIC (units: m, deg C), not ANSYS exports.
Results: results/*.csv, results/test_log.txt (real output). Timings from a 1-logical-CPU sandbox: speedup NOT assessable.
## Not implemented
GUI/3D viewer, Launch.exe (needs Windows build), editor run config, plots (CSV only), handwritten backprop pages,
block diagram, report, video, git history, AI-use log, STL/CSV size limits testing.

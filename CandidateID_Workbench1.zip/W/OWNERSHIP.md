# Ownership statement
**Reused (third party):** `third_party/httplib/httplib.h` (cpp-httplib v0.18.3, MIT, unmodified).
**AI-generated (Anthropic Claude, in the Claude app):** all other source code, tests, documents and sample-data generators in this archive were drafted by the AI assistant from the candidate's assignment brief.
**Candidate must complete before submitting:** read and be able to defend every file; handwritten backprop appendix (docs/backprop_worked_solution.md is a *reference*, not the submission); demo video; own AI-use-log entries; candidate ID; real clean-machine launch test.
Sample data are self-created (CC0), see data/README_DATA.md.

# CMake generated Testfile for 
# Source directory: /home/claude/W
# Build directory: /home/claude/W/build-win
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test(wb_tests "/home/claude/W/build-win/wb_tests.exe")
set_tests_properties(wb_tests PROPERTIES  _BACKTRACE_TRIPLES "/home/claude/W/CMakeLists.txt;48;add_test;/home/claude/W/CMakeLists.txt;0;")

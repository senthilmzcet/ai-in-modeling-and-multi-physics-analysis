# Empty dependencies file for wb_core.
# This may be replaced when dependencies are built.

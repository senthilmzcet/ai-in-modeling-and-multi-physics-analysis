file(REMOVE_RECURSE
  "CMakeFiles/wb_core.dir/src/core/backprop.cpp.obj"
  "CMakeFiles/wb_core.dir/src/core/backprop.cpp.obj.d"
  "CMakeFiles/wb_core.dir/src/core/batch.cpp.obj"
  "CMakeFiles/wb_core.dir/src/core/batch.cpp.obj.d"
  "CMakeFiles/wb_core.dir/src/core/devices.cpp.obj"
  "CMakeFiles/wb_core.dir/src/core/devices.cpp.obj.d"
  "CMakeFiles/wb_core.dir/src/core/formats.cpp.obj"
  "CMakeFiles/wb_core.dir/src/core/formats.cpp.obj.d"
  "CMakeFiles/wb_core.dir/src/core/thermal.cpp.obj"
  "CMakeFiles/wb_core.dir/src/core/thermal.cpp.obj.d"
  "libwb_core.a"
  "libwb_core.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/wb_core.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()

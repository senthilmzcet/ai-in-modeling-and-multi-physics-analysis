
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/home/claude/W/src/core/backprop.cpp" "CMakeFiles/wb_core.dir/src/core/backprop.cpp.obj" "gcc" "CMakeFiles/wb_core.dir/src/core/backprop.cpp.obj.d"
  "/home/claude/W/src/core/batch.cpp" "CMakeFiles/wb_core.dir/src/core/batch.cpp.obj" "gcc" "CMakeFiles/wb_core.dir/src/core/batch.cpp.obj.d"
  "/home/claude/W/src/core/devices.cpp" "CMakeFiles/wb_core.dir/src/core/devices.cpp.obj" "gcc" "CMakeFiles/wb_core.dir/src/core/devices.cpp.obj.d"
  "/home/claude/W/src/core/formats.cpp" "CMakeFiles/wb_core.dir/src/core/formats.cpp.obj" "gcc" "CMakeFiles/wb_core.dir/src/core/formats.cpp.obj.d"
  "/home/claude/W/src/core/thermal.cpp" "CMakeFiles/wb_core.dir/src/core/thermal.cpp.obj" "gcc" "CMakeFiles/wb_core.dir/src/core/thermal.cpp.obj.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")

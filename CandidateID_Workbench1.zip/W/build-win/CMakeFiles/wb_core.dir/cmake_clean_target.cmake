file(REMOVE_RECURSE
  "libwb_core.a"
)

file(REMOVE_RECURSE
  "CMakeFiles/wb_tests.dir/tests/test_main.cpp.obj"
  "CMakeFiles/wb_tests.dir/tests/test_main.cpp.obj.d"
  "libwb_tests.dll.a"
  "wb_tests.exe"
  "wb_tests.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/wb_tests.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()

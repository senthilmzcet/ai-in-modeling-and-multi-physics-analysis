# Empty dependencies file for wb_tests.
# This may be replaced when dependencies are built.

file(REMOVE_RECURSE
  "CMakeFiles/Launch.dir/src/launcher/launcher.cpp.obj"
  "CMakeFiles/Launch.dir/src/launcher/launcher.cpp.obj.d"
  "Launch.exe"
  "Launch.pdb"
  "libLaunch.dll.a"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/Launch.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()

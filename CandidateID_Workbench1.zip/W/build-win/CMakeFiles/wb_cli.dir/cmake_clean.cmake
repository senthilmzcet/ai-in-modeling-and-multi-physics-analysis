file(REMOVE_RECURSE
  "CMakeFiles/wb_cli.dir/src/cli/main.cpp.obj"
  "CMakeFiles/wb_cli.dir/src/cli/main.cpp.obj.d"
  "libwb_cli.dll.a"
  "wb_cli.exe"
  "wb_cli.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/wb_cli.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()

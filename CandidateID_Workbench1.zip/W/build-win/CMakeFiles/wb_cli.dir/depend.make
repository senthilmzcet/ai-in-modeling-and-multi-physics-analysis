# Empty dependencies file for wb_cli.
# This may be replaced when dependencies are built.

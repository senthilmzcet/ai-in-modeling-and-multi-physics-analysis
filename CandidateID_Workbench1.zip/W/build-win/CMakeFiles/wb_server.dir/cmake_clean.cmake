file(REMOVE_RECURSE
  "CMakeFiles/wb_server.dir/src/server/main.cpp.obj"
  "CMakeFiles/wb_server.dir/src/server/main.cpp.obj.d"
  "libwb_server.dll.a"
  "wb_server.exe"
  "wb_server.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/wb_server.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()

# Empty dependencies file for wb_server.
# This may be replaced when dependencies are built.

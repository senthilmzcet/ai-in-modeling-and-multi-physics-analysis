#!/usr/bin/env python3
"""Plots the raw CSVs in results/ (evidence figures). Reads only files produced by wb_cli."""
import csv, collections, math
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
R = "results/"
rows = list(csv.DictReader(open(R + "fea_nodes.csv"))); by = collections.defaultdict(list)
for r in rows: by[int(r["N"])].append((float(r["x_m"]), float(r["T_fe_C"]), float(r["T_exact_C"])))
fig, ax = plt.subplots(figsize=(7, 4.5))
for N, v in by.items(): ax.plot([a[0] for a in v], [a[1] for a in v], "o-" if N <= 20 else "-", ms=3, label=f"FE N={N}")
v = by[80]; ax.plot([a[0] for a in v], [a[2] for a in v], "k--", label="exact")
ax.set(xlabel="x (m)", ylabel="Temperature T (°C)", title="Rod temperature: FE (linear elements) vs exact"); ax.legend(); ax.grid(alpha=.3); fig.tight_layout(); fig.savefig(R + "plot_fea_temperature.png", dpi=130)
c = list(csv.DictReader(open(R + "fea_convergence.csv"))); h = [float(r["h_m"]) for r in c]; e = [float(r["max_midpoint_abs_err_C"]) for r in c]
fig, ax = plt.subplots(figsize=(6, 4.5)); ax.loglog(h, e, "o-", label="max midpoint |error|"); ax.loglog(h, [e[0] * (x / h[0]) ** 2 for x in h], "k--", label="slope 2 reference")
ax.set(xlabel="element size h (m)", ylabel="max |T_FE − T_exact| at midpoints (°C)", title="Mesh convergence"); ax.legend(); ax.grid(alpha=.3, which="both"); fig.tight_layout(); fig.savefig(R + "plot_fea_convergence.png", dpi=130)
b = list(csv.DictReader(open(R + "benchmark.csv"))); w = [int(r["workers"]) for r in b]; s = [float(r["speedup_T1_over_Tp"]) for r in b]
fig, ax = plt.subplots(figsize=(6, 4.5)); ax.plot(w, s, "o-", label="measured"); ax.plot(w, w, "k--", label="ideal"); ax.set(xlabel="workers p", ylabel="speedup T1/Tp", title="Batch speedup (1 logical CPU host: speedup NOT assessable)"); ax.legend(); ax.grid(alpha=.3); fig.tight_layout(); fig.savefig(R + "plot_benchmark_speedup.png", dpi=130)
l = list(csv.DictReader(open(R + "backprop_loss.csv"))); fig, ax = plt.subplots(figsize=(6, 4.5))
ax.semilogy([int(r["step"]) for r in l], [float(r["loss"]) for r in l]); ax.set(xlabel="training step", ylabel="J = ½(ŷ−y)²", title="Backprop training loss (lr=0.1, log scale)"); ax.grid(alpha=.3, which="both"); fig.tight_layout(); fig.savefig(R + "plot_backprop_loss.png", dpi=130)

#!/usr/bin/env python3
"""Generates the SELF-CREATED sample data in data/ (not an ANSYS export). Not part of the application backend."""
import math
L, R, SEG = 1.0, 0.02, 24
def tri(a, b, c):
    return ("facet normal 0 0 0\n outer loop\n  vertex %.6g %.6g %.6g\n  vertex %.6g %.6g %.6g\n  vertex %.6g %.6g %.6g\n endloop\nendfacet\n" % (*a, *b, *c))
out = ["solid synthetic_rod\n"]
ring = lambda x, i: (x, R*math.cos(2*math.pi*i/SEG), R*math.sin(2*math.pi*i/SEG))
for i in range(SEG):
    j = (i+1) % SEG
    out.append(tri(ring(0,i), ring(L,i), ring(L,j))); out.append(tri(ring(0,i), ring(L,j), ring(0,j)))
    out.append(tri((0,0,0), ring(0,j), ring(0,i))); out.append(tri((L,0,0), ring(L,i), ring(L,j)))
out.append("endsolid synthetic_rod\n")
open("data/sample_rod.stl", "w").write("".join(out))
# SYNTHETIC nodal temperatures: analytical rod profile T(x) sampled on a 3-D cylinder lattice.
T = lambda x: 100 - 80*x/L + (10000/(2*10))*x*(L-x)
rows = ["node_id,x_m,y_m,z_m,temperature_C"]; nid = 1
for k in range(41):
    x = L*k/40
    pts = [(0.0, 0.0)] + [(R*math.cos(2*math.pi*i/12), R*math.sin(2*math.pi*i/12)) for i in range(12)]
    for (y, z) in pts:
        rows.append("%d,%.6g,%.6g,%.6g,%.6f" % (nid, x, y, z, T(x))); nid += 1
open("data/sample_nodes_SYNTHETIC.csv", "w").write("\n".join(rows) + "\n")
print("nodes:", nid-1, "triangles:", 4*SEG)

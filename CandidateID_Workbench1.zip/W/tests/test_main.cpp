// Dependency-free test runner (positive, negative, numerical).
#include "thermal.hpp"
#include "batch.hpp"
#include "formats.hpp"
#include "backprop.hpp"
#include "devices.hpp"
#include <iostream>
#include <cmath>
#include <thread>
using namespace wb;
static int fails = 0, total = 0;
#define CHECK(c) do { ++total; if (!(c)) { ++fails; std::cout << "FAIL " << __LINE__ << ": " #c "\n"; } } while (0)
#define NEAR(a, b, t) CHECK(std::fabs((a) - (b)) <= (t))

int main() {
  // ---- thermal ----
  RodParams p;
  for (int N : {10, 20, 40, 80}) {
    p.N = N; auto r = solveRod(p); double h = p.L / N;
    NEAR(r.T.front(), 100.0, 1e-12); NEAR(r.T.back(), 20.0, 1e-12);                 // BCs imposed
    CHECK(r.maxNodalErr < 1e-9);                                                       // 1-D FE is nodally exact here
    NEAR(r.maxMidErr, p.q * h * h / (8 * p.k), 1e-9);                                  // analytic midpoint interpolation error q h^2/(8k)
  }
  { p.N = 10; auto a = solveRod(p); p.N = 20; auto b = solveRod(p); NEAR(convergenceOrder(a.maxMidErr, b.maxMidErr, 2.0), 2.0, 1e-6); }
  { p.N = 10; p.q = 0; auto r = solveRod(p); NEAR(r.T[5], 60.0, 1e-9); p.q = 10000; }   // pure conduction is linear
  { p.N = 1; auto r = solveRod(p); NEAR(r.T[0], 100, 1e-12); NEAR(r.T[1], 20, 1e-12); p.N = 10; }
  { RodParams b = p; b.k = -1; CHECK(!validate(b).empty()); bool thrown = false; try { solveRod(b); } catch (const std::invalid_argument&) { thrown = true; } CHECK(thrown);
    b = p; b.N = 0; CHECK(!validate(b).empty()); b = p; b.L = NAN; CHECK(!validate(b).empty()); b = p; b.A = 0; CHECK(!validate(b).empty()); }
  // ---- STL ----
  const char* good = "solid t\nfacet normal 0 0 1\nouter loop\nvertex 0 0 0\nvertex 1 0 0\nvertex 0 1 0\nendloop\nendfacet\nendsolid t\n";
  StlMesh m; std::string e;
  CHECK(parseAsciiStl(good, m, e) && m.triangles == 1 && m.bmax[0] == 1.0f);
  CHECK(!parseAsciiStl("", m, e) && e.find("empty") != std::string::npos);
  CHECK(!parseAsciiStl("   \n\n", m, e));
  CHECK(!parseAsciiStl("solid t\nendsolid t\n", m, e) && e.find("no triangles") != std::string::npos);
  CHECK(!parseAsciiStl("solid t\nfacet normal 0 0 1\nouter loop\nvertex 0 0 nan\nvertex 1 0 0\nvertex 0 1 0\nendloop\nendfacet\nendsolid\n", m, e));
  CHECK(!parseAsciiStl("solid t\nfacet normal 0 0 1\nouter loop\nvertex 0 0 inf\nvertex 1 0 0\nvertex 0 1 0\nendloop\nendfacet\nendsolid\n", m, e));
  CHECK(!parseAsciiStl("solid t\nfacet normal 0 0 1\nouter loop\nvertex 0 0 0\nvertex 1 0 0\nendloop\nendfacet\nendsolid\n", m, e));
  CHECK(!parseAsciiStl("solid t\nfacet normal 0 0 1\nouter loop\nvertex 0 0 0\n", m, e));
  CHECK(!parseAsciiStl(std::string("solid t\n\0\1\2", 11), m, e));
  CHECK(!parseAsciiStl("hello world\n", m, e));
  // ---- CSV ----
  NodeSet n; const char* H = "node_id,x_m,y_m,z_m,temperature_C\n";
  CHECK(parseNodeCsv(std::string(H) + "1,0,0,0,100\n2,0.5,0,0,60\n", n, e) && n.id.size() == 2 && n.tmax == 100 && n.tmin == 60);
  CHECK(!parseNodeCsv("", n, e) && e.find("empty") != std::string::npos);
  CHECK(!parseNodeCsv(H, n, e) && e.find("no data rows") != std::string::npos);
  CHECK(!parseNodeCsv("id,x,y,z,t\n1,0,0,0,1\n", n, e));
  CHECK(!parseNodeCsv(std::string(H) + "1,0,0,0\n", n, e));
  CHECK(!parseNodeCsv(std::string(H) + "1,0,0,0,nan\n", n, e));
  CHECK(!parseNodeCsv(std::string(H) + "1,0,0,0,inf\n", n, e));
  CHECK(!parseNodeCsv(std::string(H) + "1,0,0,0,abc\n", n, e));
  CHECK(!parseNodeCsv(std::string(H) + "x,0,0,0,1\n", n, e));
  CHECK(!parseNodeCsv(std::string(H) + "1,0,0,0,1\n1,1,1,1,2\n", n, e) && e.find("duplicate") != std::string::npos);
  // ---- batch ----
  BatchSpec spec; spec.cases = 64; spec.elements = 500;
  auto c1 = generateBatch(spec), c2 = generateBatch(spec);
  CHECK(c1.size() == 64 && c1[7].k == c2[7].k && c1[7].q == c2[7].q);                  // fixed seed reproducible
  { bool pos = true; for (auto& c : c1) pos = pos && c.k > 0 && c.q > 0; CHECK(pos); }
  { BatchSpec s2 = spec; s2.seed = 99; CHECK(generateBatch(s2)[0].k != c1[0].k); }
  std::vector<std::vector<double>> a, b;
  CHECK(solveSerial(c1, a));
  for (int w : {1, 2, 4, 7}) { CHECK(solveParallel(c1, b, w)); CHECK(maxAbsDiff(a, b) <= 1e-8); }   // agreement + ordering
  { BatchControl ctl; ctl.cancel = true; CHECK(!solveParallel(c1, b, 2, &ctl)); BatchControl c3; c3.cancel = true; CHECK(!solveSerial(c1, a, &c3)); }
  { BatchControl ctl; solveParallel(c1, b, 3, &ctl); CHECK(ctl.done == 64); }
  { bool thrown = false; auto bad = c1; bad[3].k = -5; try { solveParallel(bad, b, 4); } catch (const std::invalid_argument&) { thrown = true; } CHECK(thrown); }  // worker error propagates, no hang
  NEAR(median({3, 1, 2}), 2, 0); NEAR(median({4, 1, 2, 3}), 2.5, 0);
  // ---- backprop ----
  { BpParams q; auto g = bpGrad(q, 1, 2); auto f = bpForward(q, 1, 2);
    NEAR(f.h, std::tanh(0.5), 1e-15); NEAR(f.yhat, std::tanh(0.5), 1e-15); NEAR(f.J, 0.5 * std::pow(std::tanh(0.5) - 2, 2), 1e-12);
    auto n2 = bpNumGrad(q, 1, 2, 1e-6);
    NEAR(g.dw, n2.dw, 1e-5); NEAR(g.db, n2.db, 1e-5); NEAR(g.dv, n2.dv, 1e-5); NEAR(g.dc, n2.dc, 1e-5);
    NEAR(g.dc, std::tanh(0.5) - 2, 1e-12); NEAR(g.dw, g.db, 1e-15);
    auto u = bpStep(q, g, 0.1); NEAR(u.c, -0.1 * g.dc, 1e-15); NEAR(u.w, 0.5 - 0.1 * g.dw, 1e-15);
    auto run = bpTrain(u, 1, 2, 0.1, 100); CHECK(run.loss.size() == 101); CHECK(run.loss.back() < run.loss.front()); bool mono = true; for (size_t i = 1; i < run.loss.size(); ++i) mono = mono && run.loss[i] <= run.loss[i - 1] + 1e-15; CHECK(mono); }
  // ---- devices ----
  { DeviceManager dm; CHECK(dm.discover().size() == 3); std::string j;
    CHECK(!dm.telemetry("mcu0", j).ok);                                                  // not connected
    auto r = dm.connect("mcu0", true); CHECK(!r.ok && r.code == "TIMEOUT");              // injected failure
    r = dm.connect("mcu0", false); CHECK(r.ok);                                          // recovery by retry
    CHECK(dm.telemetry("mcu0", j).ok && j.find("\"simulated\":true") != std::string::npos);
    CHECK(dm.connect("fpga0", false).ok && dm.connect("jtag0", false).ok && dm.telemetry("fpga0", j).ok && dm.telemetry("jtag0", j).ok);
    CHECK(dm.disconnect("mcu0").ok && !dm.telemetry("mcu0", j).ok); CHECK(dm.connect("nope", false).code == "UNKNOWN_DEVICE");
    std::vector<Capability> cp; CHECK(dm.capabilities("jtag0", cp).ok && !cp.empty()); }
  std::cout << (total - fails) << "/" << total << " checks passed\n";
  return fails ? 1 : 0;
}

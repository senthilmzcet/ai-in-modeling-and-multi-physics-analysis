# Architecture
```
src/web/ (HTML/CSS/JS, Canvas)  --HTTP/JSON, 127.0.0.1-->  src/server/main.cpp (transport only)
                                                          |  calls
                                                src/core/  wb_core (no I/O, no sockets, no UI)
   thermal  batch(threads)  formats(STL/CSV)  backprop  devices(mock)  json(helpers)
src/cli/ (headless evidence generator)   src/launcher/ (Launch.exe: spawn hidden server, open browser)
```
* Presentation (src/web/) never computes; every parse/solve/threading step is C++17 in `wb_core`.
* Transport: cpp-httplib bound to 127.0.0.1 only. Long jobs (batch/benchmark) run on a C++ thread with atomic progress and a cancel flag; the UI polls `/api/job/status`, so it stays responsive. Cancel discards partial results (no corrupted output).
* The server exits ~25 s after the browser stops pinging; `Launch.exe` re-uses a running instance.
* API: `/api/fea`, `/api/fea/csv`, `/api/stl`, `/api/nodes`, `/api/sample/<file>`, `/api/batch/start`, `/api/bench/start`, `/api/job/{status,cancel}`, `/api/hw/{discover,connect,disconnect,telemetry}`, `/api/backprop`, `/api/system`, `/api/ping`.
* Thermal solver: element-wise assembly of ke=(kA/h)[1,−1;−1,1], fe=(qAh/2)[1;1] in tridiagonal storage, Dirichlet by moving known columns to the RHS and replacing boundary rows, Thomas algorithm (O(N)).
* Parallelism: bounded pool of `p` `std::thread`s pulling case indices from an atomic counter; result slot i written only by the worker that solved case i (deterministic order, no locks on the hot path). Serial path is a plain loop over the same function.

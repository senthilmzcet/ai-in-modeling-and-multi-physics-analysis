# Task E — Embedded-system integration design (design + SIMULATED mocks)
Block diagram: Hardware view in the app (SVG) — host PC ↔ powered USB hub ↔ {MCU board, FPGA board, JTAG adapter}; JTAG adapter ↔ target JTAG/SWD headers; level shifting only where voltage domains differ; single GND reference.

| Topic | MCU board | FPGA board | JTAG adapter |
|---|---|---|---|
| Power | USB 5 V → on-board 3.3 V | USB/DC → on-board rails (core ≈1.0 V, aux, 3.3 V I/O) | USB 5 V; I/O buffers run from VTref |
| Ground | common GND (USB + probe cable) | same | GND pins tied to both targets |
| Voltage domain | 3.3 V I/O (assumed) | 3.3 V bank VCCO (assumed — verify) | follows target VTref (1.8–3.3 V assumed) |
| Level shifting | none @3.3 V | none @3.3 V; needed if bank ≠ probe level | adaptive; external shifter outside range |
| Connector | USB + 10/20-pin debug header (assumed) | USB + JTAG header (assumed) | USB + 10/20-pin target cable |
| Host comms | USB-UART 115200 8N1 | USB bridge / vendor driver | USB vendor protocol |
| JTAG ownership | target: drives TDO | target: drives TDO | **probe drives TCK, TMS, TDI (TRST/SRST open-drain); samples TDO, VTref** |
| Pinout | device-specific, from board schematic | device-specific | per adapter datasheet; check pin-1 keying |

**Why a JTAG adapter is not a compute board:** it is a USB↔TAP protocol bridge. It owns the debug clock and mode lines, has a fixed vendor protocol/driver, takes its logic level from the target, and runs no user application. It cannot replace the MCU or FPGA, and nothing here assumes the three devices share a connector, voltage or protocol.

**Mocks (C++, `src/core/devices.*`):** `IDevice` interface → `Mcu`, `Fpga`, `Jtag` mocks with discovery, capabilities, connect/disconnect and one telemetry message each. A **simulated 500 ms timeout** can be injected on connect; the UI reports it, the state stays disconnected, and an immediate retry succeeds (recoverable failure). Everything is labelled SIMULATED in API payloads and UI.

**Safe integration plan:** (1) power each board alone from USB, measure rails; (2) connect GND first, then check VTref/VCCO with a meter before attaching JTAG; (3) attach the probe to one target, read IDCODE only; (4) then chain; (5) read-only operations before any programming; (6) never connect a 5 V signal to a 3.3 V pin; hub with current limiting.
**Limitations:** no real wiring, drivers, PCB or FPGA programming; voltages/headers are labelled assumptions; telemetry values are synthetic.

# AI-use log
**Tool:** Claude (Anthropic) in the Claude mobile/web app, single working session. No other AI tools were used in this archive.

## Representative prompt (verbatim, summarised)
"Develop a complete, fully functional Unified Engineering Workbench based on my uploaded PASS SCIENCE WORKS internship assignment PDF. Implement all 6 tasks (A–F) … C++17, CMake … Test all features, fix errors … generate CandidateID_Workbench.zip. Do not provide incomplete code or fake test results."

## What the AI produced / how it was validated
| Output | Validation evidence |
|---|---|
| Thermal FEM + midpoint error | Test checks nodal exactness (<1e-9), midpoint error equals analytic q·h²/(8k) (1.25, 0.3125, 0.078125, 0.01953125 °C), observed order 2.000 (`results/fea_convergence.csv`) |
| Batch/threads | serial vs 1/2/4/7 workers agree ≤1e-8 (actual 0), cancel test, error-propagation test |
| Parsers | 20+ positive/negative cases incl. NaN/Inf, empty, binary, truncated, duplicate IDs |
| Backprop | analytic vs central-difference error ≈1e-10 |
| Windows build | cross-built; tests re-run under Wine (see results/test_log.txt) |

## Defects / unsuitable AI output found during this session (real, all fixed)
1. Folder creation used shell brace expansion that `sh` did not expand → stray `{src` directory; detected by `ls`, removed, folders recreated explicitly.
2. Ternary expression mixing `double` and `std::string` in `/api/fea/csv` → compile error; rewritten as if/else.
3. `wb_tests` was not statically linked in the Windows build → silent exit code 53 under Wine; found because the output was empty, fixed in CMake (`-static`).
4. `curl --data-binary` default form content-type made the server return 404 for `/api/stl` (httplib treats form bodies specially); front-end now sends `Content-Type: text/plain` explicitly.
5. My first idle-watchdog design stopped the test server mid-session (intended behaviour but surprising during manual testing) – documented in README.
6. First backprop loss plot used 99 follow-up steps; the brief says 100 steps *after* the handwritten update → corrected to 100 (steps 1…101).
7. A `pkill -f` pattern matched its own shell and killed the tool session; replaced with a safer pattern.

## Candidate section (YOU must fill in — not fabricated here)
- Your own prompts, edits and independent checks after reading the code: _…_
- One challenge test you ran yourself and its outcome: _…_

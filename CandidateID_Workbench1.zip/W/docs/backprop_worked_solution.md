# Task F — reference solution (NOT the submission)
The brief requires **your own handwritten derivation (scan/photo, max 2 pages)**. Use this as a checking sheet; copy the derivation by hand and be ready to defend it.

Model: z = wx+b, h = tanh z, ŷ = v h + c, J = ½(ŷ−y)². x=1, y=2, w=0.5, b=0, v=1, c=0, η=0.1.

**Forward:** z = 0.5; h = tanh 0.5 = 0.46211716; ŷ = 1·h + 0 = 0.46211716; e = ŷ−y = −1.53788284; J = ½e² = 1.18254182.

**Chain rule** (e = ∂J/∂ŷ):
- ∂J/∂c = e·1 = −1.53788284
- ∂J/∂v = e·h = −0.71068205
- ∂J/∂h = e·v = −1.53788284
- ∂J/∂z = ∂J/∂h·(1−tanh²z) = −1.53788284 × 0.78644773 = −1.20946448
- ∂J/∂w = ∂J/∂z·x = −1.20946448
- ∂J/∂b = ∂J/∂z·1 = −1.20946448

**Simultaneous update** (all gradients from the original parameters), θ_new = θ − η∇J:
w = 0.5 + 0.120946448 = 0.62094645; b = 0 + 0.12094645 = 0.12094645; v = 1 + 0.07106820 = 1.07106820; c = 0 + 0.15378828 = 0.15378828.

**Direction:** every gradient is negative, i.e. increasing any parameter would *decrease* J (ŷ is too small), so stepping against the gradient raises w,b,v,c and moves ŷ up towards 2. After the step J = 0.68577 (computed by `wb_cli`).

**C++ check:** `results/backprop_gradcheck.csv` — central differences, ε=1e-6, max error ≈1.1e-10 (limit 1e-5).
**Loss plot:** `results/plot_backprop_loss.png`. Loss falls monotonically (≈1.08e-20 after 101 steps) because one sample with four free parameters can be fitted exactly; the curve is geometric (roughly linear on the log plot) with a rate set by η and the local curvature. It shows the fit of a single point, not generalisation.

---
title: "Unified Engineering Workbench — Technical Report"
geometry: margin=2cm
fontsize: 10pt
---
**Candidate ID:** _[add]_ · **Effort:** _[record your actual hours]_ · **Status:** AI-drafted prototype; verified as described below.

## 1. Design choices
C++17 core library (`wb_core`) holds all parsing, FEM, threading, mock devices and backprop; a thin localhost HTTP server (cpp-httplib, vendored) is the transport; the UI is plain HTML/JS on Canvas (no CDN, works offline). `Launch.exe` (Win32 GUI subsystem) spawns the statically linked server hidden, waits for `/api/ping`, and opens the default browser. Long jobs run on C++ threads with atomic progress and a cancel flag, so the UI never blocks and cancelled jobs discard partial results.

## 2. Thermal FEA and verification
Equation −(kA T′)′ = qA, L=1 m, A=1e-4 m², k=10 W/m·K, q=1e4 W/m³, T(0)=100 °C, T(L)=20 °C; constant properties, insulated sides, steady state. Two-node elements: ke=(kA/h)[1 −1;−1 1], fe=(qAh/2)[1 1]ᵀ; Dirichlet values imposed by moving the known columns to the right-hand side and replacing the boundary rows; tridiagonal Thomas solve. Exact: T=100−80x/L+(q/2k)x(L−x).

| N | h (m) | max midpoint error (°C) | observed order |
|---|---|---|---|
| 10 | 0.1 | 1.25 | – |
| 20 | 0.05 | 0.3125 | 2.00 |
| 40 | 0.025 | 0.078125 | 2.00 |
| 80 | 0.0125 | 0.01953125 | 2.00 |

Nodal values are exact to round-off (≤1.2e-12 °C) because the 1-D linear element is nodally exact for this problem; the midpoint error comes entirely from interpolating a parabola with straight lines and equals q h²/(8k) (checked in the unit tests). **Debugging insight:** measuring error only at nodes would suggest "zero error" and hide the convergence behaviour; the requirement to evaluate at midpoints with FE interpolation is what exposes the O(h²) rate. Plots: `results/plot_fea_temperature.png`, `plot_fea_convergence.png`; CSV: `results/fea_*.csv`.

## 3. Performance (Task D)
Batch generator: mt19937, seed 12345, k∈[2,60] W/m·K, q∈[1e3,5e4] W/m³, 2000 cases × 20000 elements. Serial = plain loop; parallel = bounded pool of p `std::thread`s taking indices from an atomic counter; each case writes only its own slot (deterministic order). Host: Intel Xeon @2.8 GHz, **1 logical / 1 physical core**, 3.9 GB RAM, GCC 13.3, `-O2 -std=c++17`; 1 warm-up + 5 measured reps, median; file load, rendering and compilation excluded.

| workers | median (s) | speedup | efficiency | max ΔT vs serial |
|---|---|---|---|---|
| 1 (serial) | 0.5847 | 1.00 | 1.00 | 0 |
| 2 | 0.5995 | 0.975 | 0.488 | 0 (≤1e-8 required) |

**Honest reading:** with a single logical CPU the 2-thread run cannot be faster; the result demonstrates a working parallel path and exact agreement, **not** speedup. Expected overheads on real hardware: thread creation, atomic counter contention (small), memory bandwidth (each solve streams ~O(N) doubles), and cache effects; efficiency <1 is normal. Re-run on a multicore machine to obtain meaningful numbers. Launch-to-ready is reported by the server (≈ms, excludes browser).

## 4. Embedded design (Task E)
Modular host-connected design with MCU board, FPGA board and JTAG adapter; full table and block diagram in the app and `docs/embedded_design.md`. Key points: common ground first; each board keeps its own voltage domain (3.3 V assumed — flagged as assumption); JTAG probe follows target VTref and *owns* TCK/TMS/TDI while targets own TDO; a JTAG adapter is a protocol bridge, not an interchangeable compute board. C++ mocks implement discovery, capabilities, connect/disconnect and telemetry for all three; an injected 500 ms timeout is shown, then recovered by retry. Everything is labelled simulated.

## 5. Backpropagation (Task F)
Analytic gradients at (w,b,v,c)=(0.5,0,1,0): (−1.20946, −1.20946, −0.71068, −1.53788); central-difference check (ε=1e-6) max error 1.1e-10 ≤ 1e-5. After one update (η=0.1): (0.62095, 0.12095, 1.07107, 0.15379); loss 1.1825 → 0.6858 and falls geometrically to ≈1e-20 after 100 further steps (single sample can be fit exactly). The handwritten derivation is **to be supplied by the candidate** (reference: `docs/backprop_worked_solution.md`).

## 6. Test outcomes
86/86 unit checks pass natively and for the Windows exe under Wine; large inputs: 100k-triangle STL 0.54 s, 500k-node CSV 1.3 s; headless-browser smoke test passed (details in `results/test_log.txt`).

## 7. Limitations
Not tested on real Windows 11 or on a multicore CPU; Canvas renderer (no GPU); embedded part is design + simulation only; Task F handwriting, video and AI-log candidate section outstanding; no code signing.

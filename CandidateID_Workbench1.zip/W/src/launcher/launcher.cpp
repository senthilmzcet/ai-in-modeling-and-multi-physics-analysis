// Launch.exe: starts bin\wb_server.exe hidden (no console), waits until ready, opens the default browser.
// Relative paths only. No admin rights, no install. If the server already runs, just re-opens the browser.
#define WIN32_LEAN_AND_MEAN
#include <winsock2.h>
#include <ws2tcpip.h>
#include <windows.h>
#include <shellapi.h>
#include <string>
#pragma comment(lib, "ws2_32.lib")

static std::string httpGet(int port, const char* path) {
  SOCKET s = socket(AF_INET, SOCK_STREAM, 0); if (s == INVALID_SOCKET) return "";
  sockaddr_in a{}; a.sin_family = AF_INET; a.sin_port = htons((u_short)port); a.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
  DWORD to = 800; setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, (char*)&to, sizeof to); setsockopt(s, SOL_SOCKET, SO_SNDTIMEO, (char*)&to, sizeof to);
  std::string out;
  if (connect(s, (sockaddr*)&a, sizeof a) == 0) {
    std::string req = std::string("GET ") + path + " HTTP/1.0\r\nHost: 127.0.0.1\r\n\r\n"; send(s, req.c_str(), (int)req.size(), 0);
    char b[512]; int n; while ((n = recv(s, b, sizeof b, 0)) > 0) out.append(b, n);
  }
  closesocket(s); return out;
}
static bool isOurs(int port) { return httpGet(port, "/api/ping").find("UnifiedWorkbench") != std::string::npos; }
static bool portBusy(int port) { return !httpGet(port, "/api/ping").empty() ; }

int WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int) {
  WSADATA w; WSAStartup(MAKEWORD(2, 2), &w);
  char exe[MAX_PATH]; GetModuleFileNameA(nullptr, exe, MAX_PATH);
  std::string dir = exe; dir = dir.substr(0, dir.find_last_of("\\/"));
  int port = 0;
  for (int p = 8765; p < 8785; ++p) { if (isOurs(p)) { port = p; break; } }
  if (!port) {
    for (int p = 8765; p < 8785 && !port; ++p) {
      if (portBusy(p)) continue;
      std::string cmd = "\"" + dir + "\\bin\\wb_server.exe\" --port " + std::to_string(p) + " --web \"" + dir + "\\src\\web\" --data \"" + dir + "\\data\"";
      STARTUPINFOA si{}; si.cb = sizeof si; si.dwFlags = STARTF_USESHOWWINDOW; si.wShowWindow = SW_HIDE; PROCESS_INFORMATION pi{};
      if (!CreateProcessA(nullptr, &cmd[0], nullptr, nullptr, FALSE, CREATE_NO_WINDOW, nullptr, dir.c_str(), &si, &pi)) {
        MessageBoxA(nullptr, "Could not start bin\\wb_server.exe.\nExtract the whole ZIP first (do not run from inside the ZIP viewer).", "Unified Workbench", MB_ICONERROR); return 1; }
      CloseHandle(pi.hThread);
      for (int i = 0; i < 100; ++i) { if (isOurs(p)) { port = p; break; } DWORD ec; if (GetExitCodeProcess(pi.hProcess, &ec) && ec != STILL_ACTIVE) break; Sleep(100); }
      CloseHandle(pi.hProcess);
    }
  }
  if (!port) { MessageBoxA(nullptr, "The workbench backend did not become ready. Check that no security software blocks bin\\wb_server.exe.", "Unified Workbench", MB_ICONERROR); return 1; }
  std::string url = "http://127.0.0.1:" + std::to_string(port) + "/";
  ShellExecuteA(nullptr, "open", url.c_str(), nullptr, nullptr, SW_SHOWNORMAL);
  WSACleanup(); return 0;
}

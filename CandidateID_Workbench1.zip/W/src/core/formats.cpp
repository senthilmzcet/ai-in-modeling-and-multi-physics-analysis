#include "formats.hpp"
#include <cmath>
#include <cstdlib>
#include <cerrno>
#include <sstream>
#include <unordered_set>
#include <algorithm>
#include <cstring>
namespace wb {
namespace {
std::string trim(const std::string& s) {
  size_t a = s.find_first_not_of(" \t\r\n"), b = s.find_last_not_of(" \t\r\n");
  return a == std::string::npos ? "" : s.substr(a, b - a + 1);
}
bool toD(const std::string& s, double& d) {
  if (s.empty()) return false;
  char* e; errno = 0; d = std::strtod(s.c_str(), &e);
  return *e == 0 && errno == 0 && std::isfinite(d);
}
}

bool parseAsciiStl(const std::string& text, StlMesh& m, std::string& err) {
  m = StlMesh();
  if (trim(text).empty()) { err = "STL file is empty (0 usable bytes). Select a non-empty ASCII STL."; return false; }
  if (std::memchr(text.data(), 0, std::min<size_t>(text.size(), 4096))) {
    err = "File contains binary data. Only ASCII STL is supported (re-export as ASCII)."; return false; }
  std::istringstream in(text); std::string line; size_t ln = 0; bool sawSolid = false;
  int vcount = 0; bool inFacet = false;
  float mn[3] = {INFINITY, INFINITY, INFINITY}, mx[3] = {-INFINITY, -INFINITY, -INFINITY};
  while (std::getline(in, line)) {
    ++ln; std::istringstream ls(line); std::string w; if (!(ls >> w)) continue;
    std::transform(w.begin(), w.end(), w.begin(), ::tolower);
    if (w == "solid") { sawSolid = true; }
    else if (!sawSolid) { err = "Line " + std::to_string(ln) + ": file does not start with 'solid' - not an ASCII STL."; return false; }
    else if (w == "facet") { if (inFacet) { err = "Line " + std::to_string(ln) + ": nested 'facet'."; return false; } inFacet = true; vcount = 0; }
    else if (w == "vertex") {
      if (!inFacet) { err = "Line " + std::to_string(ln) + ": 'vertex' outside a facet."; return false; }
      if (vcount >= 3) { err = "Line " + std::to_string(ln) + ": facet has more than 3 vertices."; return false; }
      std::string a, b, c; double d[3];
      if (!(ls >> a >> b >> c) || !toD(a, d[0]) || !toD(b, d[1]) || !toD(c, d[2])) {
        err = "Line " + std::to_string(ln) + ": vertex needs 3 finite numbers (NaN/Inf/garbage rejected)."; return false; }
      for (int i = 0; i < 3; ++i) { float f = (float)d[i];
        if (!std::isfinite(f)) { err = "Line " + std::to_string(ln) + ": value out of float range."; return false; }
        m.v.push_back(f); mn[i] = std::min(mn[i], f); mx[i] = std::max(mx[i], f); }
      ++vcount;
    } else if (w == "endfacet") {
      if (!inFacet || vcount != 3) { err = "Line " + std::to_string(ln) + ": facet must contain exactly 3 vertices."; return false; }
      inFacet = false; ++m.triangles;
    }
  }
  if (inFacet) { err = "File ends inside a facet (truncated file)."; return false; }
  if (!sawSolid) { err = "No 'solid' keyword found."; return false; }
  if (m.triangles == 0) { err = "STL contains a solid but no triangles."; return false; }
  for (int i = 0; i < 3; ++i) { m.bmin[i] = mn[i]; m.bmax[i] = mx[i]; }
  return true;
}

bool parseNodeCsv(const std::string& text, NodeSet& o, std::string& err) {
  o = NodeSet();
  if (trim(text).empty()) { err = "CSV file is empty. Expected header node_id,x_m,y_m,z_m,temperature_C followed by data rows."; return false; }
  std::istringstream in(text); std::string line; size_t ln = 0; bool header = false;
  std::unordered_set<long long> seen;
  while (std::getline(in, line)) {
    ++ln; line = trim(line); if (line.empty()) continue;
    std::vector<std::string> f; std::stringstream ss(line); std::string t;
    while (std::getline(ss, t, ',')) f.push_back(trim(t));
    if (!line.empty() && line.back() == ',') f.push_back("");
    if (!header) {
      if (f.size() != 5 || f[0] != "node_id" || f[1] != "x_m" || f[2] != "y_m" || f[3] != "z_m" || f[4] != "temperature_C") {
        err = "Line " + std::to_string(ln) + ": header must be exactly node_id,x_m,y_m,z_m,temperature_C"; return false; }
      header = true; continue;
    }
    if (f.size() != 5) { err = "Line " + std::to_string(ln) + ": expected 5 columns, found " + std::to_string(f.size()) + "."; return false; }
    char* e; errno = 0; long long id = std::strtoll(f[0].c_str(), &e, 10);
    if (f[0].empty() || *e || errno) { err = "Line " + std::to_string(ln) + ": node_id must be an integer."; return false; }
    double v[4];
    for (int i = 0; i < 4; ++i) if (!toD(f[i + 1], v[i])) {
      err = "Line " + std::to_string(ln) + ": column " + std::to_string(i + 2) + " is not a finite number ('" + f[i + 1] + "')."; return false; }
    if (!seen.insert(id).second) { err = "Line " + std::to_string(ln) + ": duplicate node_id " + std::to_string(id) + "."; return false; }
    o.id.push_back(id); o.x.push_back(v[0]); o.y.push_back(v[1]); o.z.push_back(v[2]); o.T.push_back(v[3]);
  }
  if (!header) { err = "No header found."; return false; }
  if (o.id.empty()) { err = "CSV has a header but no data rows."; return false; }
  o.tmin = *std::min_element(o.T.begin(), o.T.end()); o.tmax = *std::max_element(o.T.begin(), o.T.end());
  return true;
}
}

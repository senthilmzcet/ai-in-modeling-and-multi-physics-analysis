#include "devices.hpp"
#include <cmath>
#include <sstream>
namespace wb {
namespace {
class Mcu : public IDevice {
public:
  DevInfo info() const override { return {"mcu0", "MockMCU (generic Cortex-M class board)", "microcontroller", "3.3 V", "USB-UART (simulated)", connected}; }
  std::vector<Capability> capabilities() const override { return {{"core", "32-bit MCU (simulated)"}, {"io_voltage", "3.3 V"}, {"interfaces", "UART, SPI, I2C, SWD/JTAG"}, {"telemetry", "temperature, vbus, uptime"}}; }
  HwResult connect(bool inj) override { if (inj) return {false, "TIMEOUT", "mcu0: no response within 500 ms (simulated)"}; connected = true; tick_ = 0; return {true, "OK", "mcu0 connected (simulated)"}; }
  HwResult disconnect() override { connected = false; return {true, "OK", "mcu0 disconnected"}; }
  HwResult telemetry(std::string& j) override {
    if (!connected) return {false, "NOT_CONNECTED", "mcu0 is not connected"};
    ++tick_; std::ostringstream o; o.precision(4);
    o << "{\"device\":\"mcu0\",\"simulated\":true,\"seq\":" << tick_ << ",\"die_temp_C\":" << 31.5 + 0.5 * std::sin(tick_ * 0.7)
      << ",\"vbus_V\":" << 3.30 + 0.01 * std::cos(tick_) << ",\"uptime_ms\":" << tick_ * 1000 << "}";
    j = o.str(); return {true, "OK", "telemetry"}; }
};
class Fpga : public IDevice {
public:
  DevInfo info() const override { return {"fpga0", "MockFPGA (generic dev board, assumed 3.3 V I/O banks)", "fpga", "3.3 V I/O (core rails on-board)", "USB (simulated)", connected}; }
  std::vector<Capability> capabilities() const override { return {{"logic_cells", "~35k (assumed)"}, {"io_voltage", "3.3 V banks (assumed)"}, {"config", "JTAG / SPI flash"}, {"telemetry", "temperature, config_done, clock_MHz"}}; }
  HwResult connect(bool inj) override { if (inj) return {false, "TIMEOUT", "fpga0: no response within 500 ms (simulated)"}; connected = true; tick_ = 0; return {true, "OK", "fpga0 connected (simulated)"}; }
  HwResult disconnect() override { connected = false; return {true, "OK", "fpga0 disconnected"}; }
  HwResult telemetry(std::string& j) override {
    if (!connected) return {false, "NOT_CONNECTED", "fpga0 is not connected"};
    ++tick_; std::ostringstream o; o.precision(4);
    o << "{\"device\":\"fpga0\",\"simulated\":true,\"seq\":" << tick_ << ",\"die_temp_C\":" << 42.0 + 1.0 * std::sin(tick_ * 0.5)
      << ",\"config_done\":true,\"clock_MHz\":100.0}";
    j = o.str(); return {true, "OK", "telemetry"}; }
};
class Jtag : public IDevice {
public:
  DevInfo info() const override { return {"jtag0", "MockJTAG adapter (debug interface only)", "jtag-adapter", "VTref sense 1.8-3.3 V", "USB (simulated)", connected}; }
  std::vector<Capability> capabilities() const override { return {{"role", "debug/programming probe - NOT a compute board"}, {"signals", "TCK,TMS,TDI (out), TDO (in), SRST, VTref (in)"}, {"max_tck", "10 MHz (assumed)"}, {"chain", "mcu0 + fpga0 (simulated)"}}; }
  HwResult connect(bool inj) override { if (inj) return {false, "TIMEOUT", "jtag0: adapter did not enumerate within 500 ms (simulated)"}; connected = true; tick_ = 0; return {true, "OK", "jtag0 connected (simulated)"}; }
  HwResult disconnect() override { connected = false; return {true, "OK", "jtag0 disconnected"}; }
  HwResult telemetry(std::string& j) override {
    if (!connected) return {false, "NOT_CONNECTED", "jtag0 is not connected"};
    ++tick_; std::ostringstream o;
    o << "{\"device\":\"jtag0\",\"simulated\":true,\"seq\":" << tick_ << ",\"vtref_V\":3.3,\"tck_Hz\":6000000,\"idcodes_found\":2}";
    j = o.str(); return {true, "OK", "telemetry"}; }
};
}
DeviceManager::DeviceManager() {
  devs_["mcu0"] = std::make_unique<Mcu>(); devs_["fpga0"] = std::make_unique<Fpga>(); devs_["jtag0"] = std::make_unique<Jtag>();
}
IDevice* DeviceManager::find(const std::string& id) const { auto i = devs_.find(id); return i == devs_.end() ? nullptr : i->second.get(); }
std::vector<DevInfo> DeviceManager::discover() const { std::vector<DevInfo> v; for (auto& d : devs_) v.push_back(d.second->info()); return v; }
HwResult DeviceManager::capabilities(const std::string& id, std::vector<Capability>& o) const {
  auto* d = find(id); if (!d) return {false, "UNKNOWN_DEVICE", "no such device: " + id}; o = d->capabilities(); return {true, "OK", ""}; }
HwResult DeviceManager::connect(const std::string& id, bool inj) { auto* d = find(id); return d ? d->connect(inj) : HwResult{false, "UNKNOWN_DEVICE", "no such device: " + id}; }
HwResult DeviceManager::disconnect(const std::string& id) { auto* d = find(id); return d ? d->disconnect() : HwResult{false, "UNKNOWN_DEVICE", "no such device: " + id}; }
HwResult DeviceManager::telemetry(const std::string& id, std::string& j) { auto* d = find(id); return d ? d->telemetry(j) : HwResult{false, "UNKNOWN_DEVICE", "no such device: " + id}; }
}

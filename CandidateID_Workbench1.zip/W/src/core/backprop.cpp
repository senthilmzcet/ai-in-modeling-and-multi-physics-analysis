#include "backprop.hpp"
#include "json.hpp"
#include <cmath>
#include <sstream>
namespace wb {
BpForward bpForward(const BpParams& p, const BpSample& s) {
    BpForward f; f.z = p.w * s.x + p.b; f.h = std::tanh(f.z); f.yhat = p.v * f.h + p.c; double e = f.yhat - s.y; f.J = 0.5 * e * e; return f;
}
BpGrad bpGradient(const BpParams& p, const BpSample& s) {
    BpForward f = bpForward(p, s);
    double e = f.yhat - s.y;               // dJ/dyhat
    BpGrad g; g.dv = e * f.h;              // dyhat/dv = h
    g.dc = e;                              // dyhat/dc = 1
    double dh = e * p.v;                   // dyhat/dh = v
    double dz = dh * (1.0 - f.h * f.h);    // d tanh(z)/dz = 1-h^2
    g.dw = dz * s.x; g.db = dz; return g;
}
BpGrad bpNumericGradient(const BpParams& p, const BpSample& s, double eps) {
    auto J = [&](BpParams q) { return bpForward(q, s).J; };
    BpGrad g; BpParams a, b;
    a = b = p; a.w += eps; b.w -= eps; g.dw = (J(a) - J(b)) / (2 * eps);
    a = b = p; a.b += eps; b.b -= eps; g.db = (J(a) - J(b)) / (2 * eps);
    a = b = p; a.v += eps; b.v -= eps; g.dv = (J(a) - J(b)) / (2 * eps);
    a = b = p; a.c += eps; b.c -= eps; g.dc = (J(a) - J(b)) / (2 * eps);
    return g;
}
BpParams bpStep(const BpParams& p, const BpGrad& g, double lr) { return {p.w - lr * g.dw, p.b - lr * g.db, p.v - lr * g.dv, p.c - lr * g.dc}; }
std::string bpReportJson(int steps, double lr) {
    BpParams p; BpSample s; BpForward f0 = bpForward(p, s); BpGrad g = bpGradient(p, s), gn = bpNumericGradient(p, s, 1e-6);
    double err[4] = {std::fabs(g.dw - gn.dw), std::fabs(g.db - gn.db), std::fabs(g.dv - gn.dv), std::fabs(g.dc - gn.dc)};
    double maxErr = 0; for (double e : err) maxErr = std::max(maxErr, e);
    BpParams p1 = bpStep(p, g, lr); BpForward f1 = bpForward(p1, s);
    std::vector<double> loss{f0.J, f1.J}; BpParams q = p1;     // loss[0]=initial, loss[1]=after the single hand-checked update
    for (int i = 0; i < steps; ++i) { q = bpStep(q, bpGradient(q, s), lr); loss.push_back(bpForward(q, s).J); }
    std::ostringstream o;
    o << "{\"ok\":true,\"lr\":" << jnum(lr) << ",\"forward\":{\"z\":" << jnum(f0.z) << ",\"h\":" << jnum(f0.h) << ",\"yhat\":" << jnum(f0.yhat) << ",\"J\":" << jnum(f0.J) << "}"
      << ",\"grad\":{\"dw\":" << jnum(g.dw) << ",\"db\":" << jnum(g.db) << ",\"dv\":" << jnum(g.dv) << ",\"dc\":" << jnum(g.dc) << "}"
      << ",\"numeric\":{\"dw\":" << jnum(gn.dw) << ",\"db\":" << jnum(gn.db) << ",\"dv\":" << jnum(gn.dv) << ",\"dc\":" << jnum(gn.dc) << "}"
      << ",\"absErr\":" << jarr(std::vector<double>(err, err + 4)) << ",\"maxAbsErr\":" << jnum(maxErr) << ",\"gradCheckPass\":" << (maxErr <= 1e-5 ? "true" : "false")
      << ",\"updated\":{\"w\":" << jnum(p1.w) << ",\"b\":" << jnum(p1.b) << ",\"v\":" << jnum(p1.v) << ",\"c\":" << jnum(p1.c) << ",\"J\":" << jnum(f1.J) << "}"
      << ",\"loss\":" << jarr(loss) << ",\"finalParams\":{\"w\":" << jnum(q.w) << ",\"b\":" << jnum(q.b) << ",\"v\":" << jnum(q.v) << ",\"c\":" << jnum(q.c) << "},\"finalLoss\":" << jnum(loss.back()) << "}";
    return o.str();
}
}  // namespace wb

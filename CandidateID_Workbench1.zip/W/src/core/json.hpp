// Minimal JSON emit helpers (no parsing needed: the API uses query params / raw text bodies).
#pragma once
#include <cmath>
#include <cstdio>
#include <string>
#include <vector>
namespace wb {
inline std::string jnum(double v) {
    if (!std::isfinite(v)) return "null";
    char b[40]; std::snprintf(b, sizeof b, "%.17g", v); return b;
}
inline std::string jstr(const std::string& s) {
    std::string o = "\"";
    for (unsigned char c : s) {
        switch (c) {
            case '"': o += "\\\""; break; case '\\': o += "\\\\"; break;
            case '\n': o += "\\n"; break; case '\r': o += "\\r"; break; case '\t': o += "\\t"; break;
            default: if (c < 0x20) { char b[8]; std::snprintf(b, sizeof b, "\\u%04x", c); o += b; } else o += (char)c;
        }
    }
    return o + "\"";
}
template <class T> inline std::string jarr(const std::vector<T>& v) {
    std::string o = "[";
    for (size_t i = 0; i < v.size(); ++i) { if (i) o += ","; o += jnum((double)v[i]); }
    return o + "]";
}
inline std::string jerr(const std::string& msg, const std::string& hint = "") {
    return "{\"ok\":false,\"error\":" + jstr(msg) + ",\"hint\":" + jstr(hint) + "}";
}
}  // namespace wb

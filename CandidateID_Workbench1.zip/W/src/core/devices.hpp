// SIMULATED embedded-device adapters. No hardware is touched.
#pragma once
#include <string>
#include <vector>
#include <memory>
#include <map>
namespace wb {
enum class DevKind { Mcu, Fpga, Jtag };
struct Capability { std::string name, value; };
struct DevInfo { std::string id, name, kind, voltage, transport; bool connected; };
struct HwResult { bool ok; std::string code, message; };   // code: OK, TIMEOUT, NOT_CONNECTED, UNKNOWN_DEVICE ...

class IDevice {
public:
  virtual ~IDevice() = default;
  virtual DevInfo info() const = 0;
  virtual std::vector<Capability> capabilities() const = 0;
  virtual HwResult connect(bool injectTimeout) = 0;
  virtual HwResult disconnect() = 0;
  virtual HwResult telemetry(std::string& json) = 0;   // one telemetry message
  bool connected = false;
protected:
  int tick_ = 0;
};
class DeviceManager {
public:
  DeviceManager();
  std::vector<DevInfo> discover() const;
  HwResult capabilities(const std::string& id, std::vector<Capability>& out) const;
  HwResult connect(const std::string& id, bool injectTimeout);
  HwResult disconnect(const std::string& id);
  HwResult telemetry(const std::string& id, std::string& json);
private:
  std::map<std::string, std::unique_ptr<IDevice>> devs_;
  IDevice* find(const std::string& id) const;
};
}

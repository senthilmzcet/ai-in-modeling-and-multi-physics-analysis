#include "fileio.hpp"
#include "json.hpp"
#include <algorithm>
#include <cctype>
#include <cmath>
#include <cstdlib>
#include <set>
#include <sstream>
namespace wb {
static ParseStatus fail(const std::string& e, const std::string& h = "") { ParseStatus s; s.error = e; s.hint = h; return s; }
static bool toDouble(const std::string& s, double& v) {
    if (s.empty()) return false; char* end = nullptr; v = std::strtod(s.c_str(), &end);
    return end && *end == 0 && std::isfinite(v);
}
ParseStatus parseAsciiStl(const std::string& t, StlMesh& m) {
    if (t.size() > kMaxFileBytes) return fail("File exceeds the 50 MB limit.", "Decimate the mesh or split it.");
    size_t first = t.find_first_not_of(" \t\r\n\xEF\xBB\xBF");
    if (first == std::string::npos) return fail("The STL file is empty (0 bytes or whitespace only).", "Export a non-empty ASCII STL.");
    for (size_t i = 0; i < std::min<size_t>(t.size(), 4096); ++i) if ((unsigned char)t[i] == 0) return fail("This looks like a binary STL (NUL bytes found). Only ASCII STL is supported.", "Re-export the model as ASCII STL.");
    std::istringstream in(t); std::string tok; m = StlMesh();
    if (!(in >> tok) || tok != "solid") return fail("Missing 'solid' header: not an ASCII STL.", "ASCII STL must start with 'solid <name>'.");
    std::string rest; std::getline(in, rest); { size_t a = rest.find_first_not_of(" \t\r"); m.name = a == std::string::npos ? "" : rest.substr(a); while (!m.name.empty() && (m.name.back() == '\r' || m.name.back() == ' ')) m.name.pop_back(); }
    for (int i = 0; i < 3; ++i) { m.bmin[i] = INFINITY; m.bmax[i] = -INFINITY; }
    bool ended = false; size_t facet = 0;
    auto num = [&](double& v, const char* what) -> bool { std::string s; if (!(in >> s) || !toDouble(s, v)) return false; (void)what; return true; };
    while (in >> tok) {
        if (tok == "endsolid") { ended = true; break; }
        if (tok != "facet") return fail("Unexpected token '" + tok.substr(0, 20) + "' after facet " + std::to_string(facet) + ".", "Expected 'facet normal ...'.");
        ++facet; std::string kw; double n[3];
        if (!(in >> kw) || kw != "normal") return fail("Facet " + std::to_string(facet) + ": missing 'normal'.");
        for (double& d : n) if (!num(d, "normal")) return fail("Facet " + std::to_string(facet) + ": non-numeric or non-finite normal component.", "NaN/Inf values are rejected.");
        std::string a, b; if (!(in >> a >> b) || a != "outer" || b != "loop") return fail("Facet " + std::to_string(facet) + ": missing 'outer loop'.");
        for (int k = 0; k < 3; ++k) {
            if (!(in >> kw) || kw != "vertex") return fail("Facet " + std::to_string(facet) + ": expected 3 'vertex' lines (found fewer).");
            double p[3]; for (double& d : p) if (!num(d, "vertex")) return fail("Facet " + std::to_string(facet) + ": non-numeric or non-finite vertex coordinate.", "NaN/Inf values are rejected.");
            for (int i = 0; i < 3; ++i) { m.v.push_back((float)p[i]); m.bmin[i] = std::min(m.bmin[i], p[i]); m.bmax[i] = std::max(m.bmax[i], p[i]); }
        }
        if (!(in >> kw) || kw != "endloop") return fail("Facet " + std::to_string(facet) + ": expected 'endloop' (more than 3 vertices?).");
        if (!(in >> kw) || kw != "endfacet") return fail("Facet " + std::to_string(facet) + ": expected 'endfacet'.");
        ++m.tris;
    }
    if (!ended) return fail("File ended without 'endsolid' (truncated?).", "Triangles parsed before the break: " + std::to_string(m.tris));
    if (m.tris == 0) return fail("The STL contains a solid but zero triangles.", "Nothing to display.");
    ParseStatus s; s.ok = true; return s;
}
static std::vector<std::string> split(const std::string& l) {
    std::vector<std::string> o; std::string c; std::istringstream s(l);
    while (std::getline(s, c, ',')) { size_t a = c.find_first_not_of(" \t\r"), b = c.find_last_not_of(" \t\r"); o.push_back(a == std::string::npos ? "" : c.substr(a, b - a + 1)); }
    if (!l.empty() && l.back() == ',') o.push_back("");
    return o;
}
ParseStatus parseNodalCsv(const std::string& t, NodeCloud& c) {
    if (t.size() > kMaxFileBytes) return fail("File exceeds the 50 MB limit.", "Split the export.");
    if (t.find_first_not_of(" \t\r\n") == std::string::npos) return fail("The CSV file is empty.", "Expected header node_id,x_m,y_m,z_m,temperature_C followed by data rows.");
    std::istringstream in(t); std::string line; size_t ln = 0; bool header = false; std::set<long long> ids; c = NodeCloud();
    while (std::getline(in, line)) {
        ++ln; if (!line.empty() && line.back() == '\r') line.pop_back();
        if (line.empty() || line[0] == '#') continue;                       // comments / blank lines allowed
        auto f = split(line);
        if (!header) {
            if (ln == 1 || f.size()) { if (f.size() != 5 || f[0] != "node_id" || f[1] != "x_m" || f[2] != "y_m" || f[3] != "z_m" || f[4] != "temperature_C")
                return fail("Line " + std::to_string(ln) + ": header must be exactly node_id,x_m,y_m,z_m,temperature_C.", "Coordinates are metres, temperature degrees Celsius."); }
            header = true; continue;
        }
        if (f.size() != 5) return fail("Line " + std::to_string(ln) + ": expected 5 columns, found " + std::to_string(f.size()) + ".");
        double v[5]; for (int i = 0; i < 5; ++i) if (!toDouble(f[i], v[i])) return fail("Line " + std::to_string(ln) + ", column '" + f[i].substr(0, 20) + "': not a finite number.", "NaN, Inf and empty fields are rejected.");
        if (v[0] != std::floor(v[0]) || v[0] < 0) return fail("Line " + std::to_string(ln) + ": node_id must be a non-negative integer.");
        if (!ids.insert((long long)v[0]).second) return fail("Line " + std::to_string(ln) + ": duplicate node_id " + std::to_string((long long)v[0]) + ".");
        if (v[4] < -273.15) return fail("Line " + std::to_string(ln) + ": temperature below absolute zero (-273.15 C).");
        c.id.push_back(v[0]); c.x.push_back(v[1]); c.y.push_back(v[2]); c.z.push_back(v[3]); c.T.push_back(v[4]);
    }
    if (!header) return fail("No header found.");
    if (c.T.empty()) return fail("The CSV has a header but no data rows.", "Nothing to display.");
    c.tmin = *std::min_element(c.T.begin(), c.T.end()); c.tmax = *std::max_element(c.T.begin(), c.T.end());
    ParseStatus s; s.ok = true; return s;
}
std::string stlToJson(const StlMesh& m) {
    std::ostringstream o;
    o << "{\"ok\":true,\"name\":" << jstr(m.name) << ",\"triangles\":" << m.tris << ",\"bmin\":[" << jnum(m.bmin[0]) << "," << jnum(m.bmin[1]) << "," << jnum(m.bmin[2])
      << "],\"bmax\":[" << jnum(m.bmax[0]) << "," << jnum(m.bmax[1]) << "," << jnum(m.bmax[2]) << "],\"units\":\"as authored in file (unit-less STL)\",\"vertices\":" << jarr(m.v) << "}";
    return o.str();
}
std::string cloudToJson(const NodeCloud& c) {
    std::ostringstream o;
    o << "{\"ok\":true,\"count\":" << c.T.size() << ",\"tmin\":" << jnum(c.tmin) << ",\"tmax\":" << jnum(c.tmax) << ",\"units\":{\"length\":\"m\",\"temperature\":\"C\"},\"id\":" << jarr(c.id)
      << ",\"x\":" << jarr(c.x) << ",\"y\":" << jarr(c.y) << ",\"z\":" << jarr(c.z) << ",\"T\":" << jarr(c.T) << "}";
    return o.str();
}
}  // namespace wb

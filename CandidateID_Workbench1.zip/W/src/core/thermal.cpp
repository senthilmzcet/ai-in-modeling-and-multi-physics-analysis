#include "thermal.hpp"
#include <cmath>
#include <cstdio>
#include <sstream>
#include <stdexcept>
namespace wb {
static bool pos(double v) { return std::isfinite(v) && v > 0; }
std::string validate(const ThermalParams& p) {
    if (p.N < 1 || p.N > 5000000) return "Element count N must be an integer in [1, 5,000,000].";
    if (!pos(p.L)) return "Length L must be a finite positive number (m).";
    if (!pos(p.A)) return "Area A must be a finite positive number (m^2).";
    if (!pos(p.k)) return "Conductivity k must be a finite positive number (W/(m K)).";
    if (!std::isfinite(p.q)) return "Heat generation q must be finite (W/m^3).";
    if (!std::isfinite(p.T0) || !std::isfinite(p.TL)) return "Boundary temperatures T(0), T(L) must be finite (C).";
    return "";
}
double exactTemperature(const ThermalParams& p, double x) {
    return p.T0 + (p.TL - p.T0) * x / p.L + p.q / (2 * p.k) * x * (p.L - x);
}
void solveNodalTemperatures(const ThermalParams& p, std::vector<double>& T) {
    const int n = p.N + 1; const double h = p.L / p.N;
    const double ke = p.k * p.A / h, fe = p.q * p.A * h / 2.0;
    std::vector<double> d(n, 0.0), off(n - 1, 0.0), f(n, 0.0);
    for (int e = 0; e < p.N; ++e) {            // element e connects nodes e, e+1
        d[e] += ke; d[e + 1] += ke; off[e] += -ke;   // Ke = ke*[1 -1; -1 1]
        f[e] += fe; f[e + 1] += fe;                  // fe = qAh/2 each node
    }
    // Dirichlet: move known column to RHS, then identity row (keeps matrix symmetric).
    f[1] -= off[0] * p.T0;  off[0] = 0; d[0] = 1; f[0] = p.T0;
    f[n - 2] -= off[n - 2] * p.TL;  off[n - 2] = 0; d[n - 1] = 1; f[n - 1] = p.TL;
    if (n == 2) { f[0] = p.T0; f[1] = p.TL; }
    // Thomas algorithm (symmetric tridiagonal)
    for (int i = 1; i < n; ++i) { double m = off[i - 1] / d[i - 1]; d[i] -= m * off[i - 1]; f[i] -= m * f[i - 1]; }
    T.assign(n, 0.0); T[n - 1] = f[n - 1] / d[n - 1];
    for (int i = n - 2; i >= 0; --i) T[i] = (f[i] - off[i] * T[i + 1]) / d[i];
}
ThermalResult solveThermal(const ThermalParams& p) {
    std::string v = validate(p); if (!v.empty()) throw std::invalid_argument(v);
    ThermalResult r; const double h = p.L / p.N;
    solveNodalTemperatures(p, r.T);
    for (int i = 0; i <= p.N; ++i) {
        double x = i * h; r.x.push_back(x); r.Texact.push_back(exactTemperature(p, x));
        r.maxErrNode = std::max(r.maxErrNode, std::fabs(r.T[i] - r.Texact[i]));
    }
    for (int e = 0; e < p.N; ++e) {
        double xm = (e + 0.5) * h, tfe = 0.5 * (r.T[e] + r.T[e + 1]), tex = exactTemperature(p, xm);
        r.xmid.push_back(xm); r.Tmid_fe.push_back(tfe); r.Tmid_exact.push_back(tex);
        r.errMid.push_back(std::fabs(tfe - tex)); r.maxErrMid = std::max(r.maxErrMid, r.errMid.back());
    }
    return r;
}
std::string thermalCsv(const ThermalResult& r) {
    std::ostringstream o; o.precision(12);
    o << "# 1D steady thermal FEM, units: x [m], T [C]\nlocation,x_m,T_fe_C,T_exact_C,abs_err_C\n";
    for (size_t i = 0; i < r.x.size(); ++i) o << "node," << r.x[i] << ',' << r.T[i] << ',' << r.Texact[i] << ',' << std::fabs(r.T[i] - r.Texact[i]) << '\n';
    for (size_t i = 0; i < r.xmid.size(); ++i) o << "midpoint," << r.xmid[i] << ',' << r.Tmid_fe[i] << ',' << r.Tmid_exact[i] << ',' << r.errMid[i] << '\n';
    return o.str();
}
}  // namespace wb

// Task F: tiny network h=tanh(w x+b), yhat=v h+c, J=0.5(yhat-y)^2. Manual chain rule, no autodiff.
#pragma once
#include <string>
#include <vector>
namespace wb {
struct BpParams { double w = 0.5, b = 0, v = 1, c = 0; };
struct BpSample { double x = 1, y = 2; };
struct BpForward { double z, h, yhat, J; };
struct BpGrad { double dw, db, dv, dc; };
BpForward bpForward(const BpParams&, const BpSample&);
BpGrad bpGradient(const BpParams&, const BpSample&);                 // analytic (hand-derived)
BpGrad bpNumericGradient(const BpParams&, const BpSample&, double eps);  // central differences
BpParams bpStep(const BpParams&, const BpGrad&, double lr);          // simultaneous update
std::string bpReportJson(int steps, double lr);
}  // namespace wb

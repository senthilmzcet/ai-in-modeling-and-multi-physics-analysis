#include "batch.hpp"
#include "json.hpp"
#include "thermal.hpp"
#include <algorithm>
#include <chrono>
#include <cmath>
#include <fstream>
#include <random>
#include <sstream>
#include <thread>
#ifdef _WIN32
#define NOMINMAX
#include <windows.h>
#endif
#ifndef WB_COMPILE_FLAGS
#define WB_COMPILE_FLAGS "unknown"
#endif
namespace wb {
std::string validate(const BatchSpec& s) {
    if (s.cases < 1 || s.cases > 100000) return "Case count must be in [1, 100000].";
    if (s.elements < 2 || s.elements > 200000) return "Mesh size (elements per case) must be in [2, 200000].";
    return "";
}
std::vector<BatchCase> generateCases(const BatchSpec& s) {
    std::mt19937_64 g(s.seed);
    std::uniform_real_distribution<double> dk(5.0, 50.0), dq(1e3, 5e4);
    std::vector<BatchCase> c(s.cases);
    for (auto& x : c) { x.k = dk(g); x.q = dq(g); }
    return c;
}
static void solveOne(const BatchCase& c, int n, std::vector<double>& T) {
    ThermalParams p; p.k = c.k; p.q = c.q; p.N = n;
    solveNodalTemperatures(p, T);
}
bool runSerial(const std::vector<BatchCase>& cs, int n, BatchResult& out, RunControl rc) {
    out.assign(cs.size(), {});
    for (size_t i = 0; i < cs.size(); ++i) {
        if (rc.cancel && rc.cancel->load()) return false;
        solveOne(cs[i], n, out[i]);
        if (rc.done) rc.done->fetch_add(1);
    }
    return true;
}
bool runParallel(const std::vector<BatchCase>& cs, int n, int workers, BatchResult& out, RunControl rc) {
    workers = std::max(1, std::min<int>(workers, 64));         // bounded pool
    out.assign(cs.size(), {});
    std::atomic<size_t> next{0}; std::atomic<bool> stop{false};
    auto work = [&] {
        for (;;) {
            if ((rc.cancel && rc.cancel->load()) || stop.load()) { stop = true; return; }
            size_t i = next.fetch_add(1); if (i >= cs.size()) return;
            solveOne(cs[i], n, out[i]);                       // each task writes only out[i]: no shared mutable state
            if (rc.done) rc.done->fetch_add(1);
        }
    };
    std::vector<std::thread> th; for (int w = 1; w < workers; ++w) th.emplace_back(work);
    work(); for (auto& t : th) t.join();
    return !stop.load();
}
double maxAbsDiff(const BatchResult& a, const BatchResult& b) {
    if (a.size() != b.size()) return INFINITY;
    double m = 0;
    for (size_t i = 0; i < a.size(); ++i) {
        if (a[i].size() != b[i].size()) return INFINITY;
        for (size_t j = 0; j < a[i].size(); ++j) m = std::max(m, std::fabs(a[i][j] - b[i][j]));
    }
    return m;
}
HardwareInfo hardwareInfo() {
    HardwareInfo h; h.logical = std::max(1u, std::thread::hardware_concurrency()); h.physical = h.logical;
    h.compiler =
#if defined(__clang__)
        std::string("clang ") + __clang_version__;
#elif defined(__GNUC__)
        std::string("GCC ") + __VERSION__;
#elif defined(_MSC_VER)
        "MSVC " + std::to_string(_MSC_VER);
#else
        "unknown";
#endif
    h.flags = WB_COMPILE_FLAGS;
#ifdef _WIN32
    h.os = "Windows";
    SYSTEM_INFO si; GetSystemInfo(&si); h.logical = std::max<unsigned>(1, si.dwNumberOfProcessors);
    MEMORYSTATUSEX m; m.dwLength = sizeof m; if (GlobalMemoryStatusEx(&m)) h.ramGiB = m.ullTotalPhys / 1073741824.0;
    DWORD len = 0; GetLogicalProcessorInformation(nullptr, &len);
    if (len) { std::vector<SYSTEM_LOGICAL_PROCESSOR_INFORMATION> v(len / sizeof(SYSTEM_LOGICAL_PROCESSOR_INFORMATION));
        if (GetLogicalProcessorInformation(v.data(), &len)) { unsigned c = 0; for (auto& e : v) if (e.Relationship == RelationProcessorCore) ++c; if (c) h.physical = c; } }
    char name[128] = {0}; DWORD sz = sizeof name; HKEY k;
    if (RegOpenKeyExA(HKEY_LOCAL_MACHINE, "HARDWARE\\DESCRIPTION\\System\\CentralProcessor\\0", 0, KEY_READ, &k) == ERROR_SUCCESS) {
        RegQueryValueExA(k, "ProcessorNameString", nullptr, nullptr, (LPBYTE)name, &sz); RegCloseKey(k); }
    h.cpu = name[0] ? name : "unknown (Windows)";
#else
    h.os = "Linux";
    std::ifstream ci("/proc/cpuinfo"); std::string line; std::vector<std::string> cores;
    std::string phys, core;
    while (std::getline(ci, line)) {
        auto c = line.find(':'); if (c == std::string::npos) continue; std::string key = line.substr(0, line.find('\t')), val = line.substr(c + 2);
        if (key.rfind("model name", 0) == 0 && h.cpu.empty()) h.cpu = val;
        if (key.rfind("physical id", 0) == 0) phys = val;
        if (key.rfind("core id", 0) == 0) { core = val; cores.push_back(phys + ":" + core); }
    }
    std::sort(cores.begin(), cores.end()); cores.erase(std::unique(cores.begin(), cores.end()), cores.end());
    if (!cores.empty()) h.physical = (unsigned)cores.size();
    if (h.cpu.empty()) h.cpu = "unknown";
    std::ifstream mi("/proc/meminfo"); while (std::getline(mi, line)) if (line.rfind("MemTotal:", 0) == 0) { h.ramGiB = std::stod(line.substr(9)) / 1048576.0; break; }
#endif
    return h;
}
static double median(std::vector<double> v) { std::sort(v.begin(), v.end()); size_t n = v.size(); return n % 2 ? v[n / 2] : 0.5 * (v[n / 2 - 1] + v[n / 2]); }
BenchReport runBenchmark(const BatchSpec& spec, std::atomic<bool>* cancel, std::function<void(double)> progress) {
    BenchReport rep; rep.hw = hardwareInfo(); rep.spec = spec;
    auto cases = generateCases(spec);             // generation excluded from timing
    std::vector<int> workers; for (int p : {1, 2, 4}) if ((unsigned)p <= rep.hw.logical) workers.push_back(p);
    rep.speedupAssessable = rep.hw.logical > 1;
    // configurations: serial, then parallel with p workers; on a 1-CPU host also a parallel-path demo with p=2.
    std::vector<std::pair<bool, int>> cfg{{true, 1}}; for (int p : workers) cfg.push_back({false, p});
    if (!rep.speedupAssessable) cfg.push_back({false, 2});
    const int reps = 5; double total = (double)cfg.size() * (reps + 1), doneUnits = 0;
    BatchResult ref, cur; using clk = std::chrono::steady_clock;
    auto run = [&](bool serial, int p) { return serial ? runSerial(cases, spec.elements, cur) : runParallel(cases, spec.elements, p, cur, {cancel}); };
    double serialMedian = 0;
    for (auto& c : cfg) {
        BenchRow row; row.workers = c.second; row.isSerial = c.first; row.maxDiff = 0;
        if (!run(c.first, c.second)) { rep.cancelled = true; return rep; }       // warm-up (not recorded)
        if (c.first) ref = cur; else row.maxDiff = maxAbsDiff(ref, cur);
        doneUnits += 1; if (progress) progress(doneUnits / total);
        for (int r = 0; r < reps; ++r) {
            auto t0 = clk::now(); bool ok = run(c.first, c.second); auto t1 = clk::now();
            if (!ok) { rep.cancelled = true; return rep; }
            row.times.push_back(std::chrono::duration<double>(t1 - t0).count());
            if (!c.first) row.maxDiff = std::max(row.maxDiff, maxAbsDiff(ref, cur));
            doneUnits += 1; if (progress) progress(doneUnits / total);
        }
        row.median = median(row.times); if (c.first) serialMedian = row.median;
        row.speedup = serialMedian / row.median; row.efficiency = row.speedup / row.workers;   // T1 = serial implementation
        rep.rows.push_back(row);
    }
    return rep;
}
std::string benchToJson(const BenchReport& r) {
    std::ostringstream o;
    o << "{\"ok\":true,\"cancelled\":" << (r.cancelled ? "true" : "false") << ",\"speedupAssessable\":" << (r.speedupAssessable ? "true" : "false")
      << ",\"hw\":{\"cpu\":" << jstr(r.hw.cpu) << ",\"logical\":" << r.hw.logical << ",\"physical\":" << r.hw.physical << ",\"ramGiB\":" << jnum(r.hw.ramGiB)
      << ",\"compiler\":" << jstr(r.hw.compiler) << ",\"flags\":" << jstr(r.hw.flags) << ",\"os\":" << jstr(r.hw.os) << "}"
      << ",\"spec\":{\"cases\":" << r.spec.cases << ",\"elements\":" << r.spec.elements << ",\"seed\":" << r.spec.seed << ",\"warmup\":1,\"repetitions\":5}"
      << ",\"rows\":[";
    for (size_t i = 0; i < r.rows.size(); ++i) { auto& w = r.rows[i]; if (i) o << ",";
        o << "{\"mode\":" << jstr(w.isSerial ? "serial" : "parallel") << ",\"workers\":" << w.workers << ",\"times_s\":" << jarr(w.times) << ",\"median_s\":" << jnum(w.median)
          << ",\"speedup\":" << jnum(w.speedup) << ",\"efficiency\":" << jnum(w.efficiency) << ",\"maxAbsDiff_C\":" << jnum(w.maxDiff) << ",\"agree\":" << (w.maxDiff <= 1e-8 ? "true" : "false") << "}"; }
    o << "]}"; return o.str();
}
std::string benchToCsv(const BenchReport& r) {
    std::ostringstream o; o.precision(9);
    o << "# cpu=" << r.hw.cpu << "; logical=" << r.hw.logical << "; physical=" << r.hw.physical << "; ram_GiB=" << r.hw.ramGiB << "; compiler=" << r.hw.compiler << "; flags=" << r.hw.flags << "\n"
      << "# cases=" << r.spec.cases << "; elements=" << r.spec.elements << "; seed=" << r.spec.seed << "; warmup=1; reps=5; speedup_assessable=" << (r.speedupAssessable ? "yes" : "NO (single logical CPU)") << "\n"
      << "mode,workers,rep1_s,rep2_s,rep3_s,rep4_s,rep5_s,median_s,speedup_Tserial_over_Tp,efficiency,max_abs_diff_C\n";
    for (auto& w : r.rows) { o << (w.isSerial ? "serial" : "parallel") << ',' << w.workers; for (double t : w.times) o << ',' << t; o << ',' << w.median << ',' << w.speedup << ',' << w.efficiency << ',' << w.maxDiff << '\n'; }
    return o.str();
}
}  // namespace wb

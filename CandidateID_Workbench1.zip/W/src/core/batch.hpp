// Batch of independent thermal solves: serial + bounded-worker-pool parallel versions.
#pragma once
#include <atomic>
#include <functional>
#include <string>
#include <vector>
namespace wb {
struct BatchCase { double k, q; };
struct BatchSpec { int cases = 1000; int elements = 20000; unsigned seed = 12345; };
std::string validate(const BatchSpec& s);
std::vector<BatchCase> generateCases(const BatchSpec& s);   // fixed seed -> reproducible; k in [5,50], q in [1e3,5e4]
using BatchResult = std::vector<std::vector<double>>;       // results[i] belongs to case i (input order)
struct RunControl { std::atomic<bool>* cancel = nullptr; std::atomic<int>* done = nullptr; };
// Returns false if cancelled (results then partial and must be discarded).
bool runSerial(const std::vector<BatchCase>&, int elements, BatchResult& out, RunControl rc = {});
bool runParallel(const std::vector<BatchCase>&, int elements, int workers, BatchResult& out, RunControl rc = {});
double maxAbsDiff(const BatchResult& a, const BatchResult& b);

struct HardwareInfo { std::string cpu, compiler, flags, os; unsigned logical = 1, physical = 1; double ramGiB = 0; };
HardwareInfo hardwareInfo();
struct BenchRow { int workers; std::vector<double> times; double median, speedup, efficiency, maxDiff; bool isSerial; };
struct BenchReport { HardwareInfo hw; BatchSpec spec; std::vector<BenchRow> rows; bool speedupAssessable; bool cancelled = false; double warmup_s = 0; };
// Excludes case generation/IO/rendering from timings. 1 warm-up + 5 measured reps per configuration.
BenchReport runBenchmark(const BatchSpec&, std::atomic<bool>* cancel, std::function<void(double)> progress);
std::string benchToJson(const BenchReport&);
std::string benchToCsv(const BenchReport&);
}  // namespace wb

// Parsers/validators for ASCII STL and ANSYS-style nodal temperature CSV.
#pragma once
#include <string>
#include <vector>
namespace wb {
constexpr size_t kMaxFileBytes = 50u * 1024u * 1024u;   // hard limit enforced by parsers (tested up to this size, see docs)
struct StlMesh { std::string name; std::vector<float> v; /* 9 floats per triangle */ size_t tris = 0; double bmin[3], bmax[3]; };
struct NodeCloud { std::vector<double> id, x, y, z, T; double tmin = 0, tmax = 0; };
struct ParseStatus { bool ok = false; std::string error, hint; };
ParseStatus parseAsciiStl(const std::string& text, StlMesh& out);
ParseStatus parseNodalCsv(const std::string& text, NodeCloud& out);
std::string stlToJson(const StlMesh&);
std::string cloudToJson(const NodeCloud&);
}  // namespace wb

// Steady-state 1D thermal FEM: -d/dx(kA dT/dx) = qA, two-node linear elements.
#pragma once
#include <string>
#include <vector>
namespace wb {
struct ThermalParams { double L = 1.0, A = 1e-4, k = 10.0, q = 1e4, T0 = 100.0, TL = 20.0; int N = 10; };
struct ThermalResult {
    std::vector<double> x, T, Texact;                 // nodes
    std::vector<double> xmid, Tmid_fe, Tmid_exact, errMid;  // element midpoints (FE interpolation)
    double maxErrMid = 0, maxErrNode = 0;
};
// Returns "" if valid, otherwise an actionable message.
std::string validate(const ThermalParams& p);
double exactTemperature(const ThermalParams& p, double x);
// Assemble tridiagonal K,f; impose Dirichlet BCs by row/column elimination (symmetry kept); Thomas solve.
void solveNodalTemperatures(const ThermalParams& p, std::vector<double>& T);
ThermalResult solveThermal(const ThermalParams& p);   // throws std::invalid_argument on bad params
std::string thermalCsv(const ThermalResult& r);       // x_m,T_fe_C,T_exact_C,abs_err_C
}  // namespace wb

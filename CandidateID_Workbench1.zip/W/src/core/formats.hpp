// ASCII STL and ANSYS-style nodal temperature CSV parsers + validation.
#pragma once
#include <string>
#include <vector>
namespace wb {
struct ParseError { std::string msg; };   // actionable message, includes line number when known

struct StlMesh {
  std::vector<float> v;                 // 9 floats per triangle
  size_t triangles = 0;
  float bmin[3]{0,0,0}, bmax[3]{0,0,0};
};
// On failure returns false and sets err. Rejects empty, binary, non-finite, incomplete facets.
bool parseAsciiStl(const std::string& text, StlMesh& out, std::string& err);

struct NodeSet {
  std::vector<long long> id; std::vector<double> x, y, z, T;
  double tmin = 0, tmax = 0;
};
// Header must be exactly: node_id,x_m,y_m,z_m,temperature_C
bool parseNodeCsv(const std::string& text, NodeSet& out, std::string& err);
}

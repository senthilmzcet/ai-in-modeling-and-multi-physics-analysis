// Workbench core (C++17): FEA, parallel batch, backprop, mock HW, STL/CSV validators.
#include <bits/stdc++.h>
#include <thread>
using namespace std;
static const double L=1,A=1e-4;
// Task C: 2-node linear elements; K,f assembled, Dirichlet by elimination, Thomas solve.
vector<double> solve(int N,double k,double q,double T0=100,double TL=20){
  double h=L/N,kk=k*A/h,fe=q*A*h/2; int n=N-1; vector<double> T(N+1);T[0]=T0;T[N]=TL;
  if(n<1)return T; vector<double> a(n,0),b(n,0),c(n,0),d(n,0);
  for(int e=0;e<N;e++){int i=e,j=e+1; // global nodes; unknown idx = node-1
    auto add=[&](int r,int cc,double v){if(r<1||r>N-1)return; if(cc>=1&&cc<=N-1){ if(cc==r)b[r-1]+=v; else if(cc==r-1)a[r-1]+=v; else c[r-1]+=v;} else d[r-1]-=v*(cc==0?T0:TL);};
    add(i,i,kk);add(i,j,-kk);add(j,i,-kk);add(j,j,kk);
    if(i>=1)d[i-1]+=fe; if(j<=N-1)d[j-1]+=fe;}
  for(int i=1;i<n;i++){double m=a[i]/b[i-1];b[i]-=m*c[i-1];d[i]-=m*d[i-1];}
  vector<double> x(n);x[n-1]=d[n-1]/b[n-1];for(int i=n-2;i>=0;i--)x[i]=(d[i]-c[i]*x[i+1])/b[i];
  for(int i=0;i<n;i++)T[i+1]=x[i];return T;}
double ex(double x,double k,double q){return 100-80*x/L+q/(2*k)*x*(L-x);}
double midErr(const vector<double>&T,double k,double q){int N=T.size()-1;double h=L/N,m=0;
  for(int e=0;e<N;e++)m=max(m,fabs(0.5*(T[e]+T[e+1])-ex((e+.5)*h,k,q)));return m;}
// Task D
struct Case{double k,q;};
vector<Case> gen(int n,unsigned seed){mt19937 g(seed);uniform_real_distribution<double>K(5,20),Q(1e3,2e4);vector<Case>v;for(int i=0;i<n;i++){double k=K(g),q=Q(g);v.push_back({k,q});}return v;}
vector<vector<double>> run(const vector<Case>&c,int M,int p){vector<vector<double>> r(c.size());
  auto w=[&](size_t s,size_t e){for(size_t i=s;i<e;i++)r[i]=solve(M,c[i].k,c[i].q);};
  if(p<=1){w(0,c.size());return r;} vector<thread>th;size_t ch=(c.size()+p-1)/p;
  for(int t=0;t<p;t++){size_t s=t*ch,e=min(c.size(),s+ch);if(s<e)th.emplace_back(w,s,e);}
  for(auto&t:th)t.join();return r;}
// Task F
struct P{double w=.5,b=0,v=1,c=0;};
double loss(const P&p,double&h,double&yh){h=tanh(p.w*1+p.b);yh=p.v*h+p.c;return .5*(yh-2)*(yh-2);}
array<double,4> grad(const P&p){double h,yh;loss(p,h,yh);double e=yh-2,dz=e*p.v*(1-h*h);return{dz,dz,e*h,e};}//w,b,v,c
double Lf(P p){double h,y;return loss(p,h,y);}
// Task E (simulated)
struct Dev{string id,type;bool conn=false;int fail=0;Dev(string i,string t):id(i),type(t){}
  string caps()const{return type=="MCU"?"UART,SWD 3.3V":type=="FPGA"?"JTAG-target,SPI 1.8/3.3V":"JTAG-probe (debug only) 3.3V";}
  bool connect(){if(fail>0){fail--;return false;}conn=true;return true;}
  string telem()const{return "{\"dev\":\""+id+"\",\"simulated\":true,\"temp_C\":31.5}";}};
// validators
string stl(const string&f,size_t&tri){ifstream s(f);if(!s)return"cannot open";string l;size_t v=0;tri=0;bool any=false,solid=false;
  while(getline(s,l)){any=true;istringstream is(l);string t;is>>t;if(t=="solid")solid=true;if(t=="facet")tri++;if(t=="vertex"){double x,y,z;if(!(is>>x>>y>>z)||!isfinite(x)||!isfinite(y)||!isfinite(z))return"bad/non-finite vertex";v++;}}
  if(!any)return"empty file";if(!solid)return"missing 'solid' header";if(v!=3*tri||!tri)return"vertex count != 3*facets";return"";}
string csv(const string&f,size_t&n){ifstream s(f);if(!s)return"cannot open";string l;n=0;if(!getline(s,l))return"empty file";
  if(l!="node_id,x_m,y_m,z_m,temperature_C")return"bad header";
  while(getline(s,l)){if(l.empty())continue;stringstream ss(l);string t;vector<double>v;try{while(getline(ss,t,',')){size_t p;double d=stod(t,&p);if(p!=t.size()||!isfinite(d))return"non-finite/malformed row "+to_string(n+2);v.push_back(d);}}catch(...){return"malformed row "+to_string(n+2);}
    if(v.size()!=5)return"wrong column count row "+to_string(n+2);n++;}
  return n?"":"no data rows";}
int fails=0;void chk(bool ok,const string&m){cout<<(ok?"PASS ":"FAIL ")<<m<<"\n";if(!ok)fails++;}
double med(vector<double>v){sort(v.begin(),v.end());return v[v.size()/2];}
int main(){
  cout<<fixed;
  {ofstream o("results/fea_convergence.csv");o<<"N,max_midpoint_abs_error_C\n";
   ofstream pr("results/fea_profiles.csv");pr<<"N,x_m,T_fe_C,T_exact_C\n";double prev=1e9;
   for(int N:{10,20,40,80}){auto T=solve(N,10,1e4);double e=midErr(T,10,1e4);o<<N<<","<<setprecision(10)<<e<<"\n";
     for(int i=0;i<=N;i++)pr<<N<<","<<i*1.0/N<<","<<T[i]<<","<<ex(i*1.0/N,10,1e4)<<"\n";
     cout<<"N="<<N<<" midpoint max err="<<scientific<<e<<fixed<<"\n";chk(e<prev,"error decreases at N="+to_string(N));prev=e;}
   chk(fabs(solve(10,10,1e4)[0]-100)<1e-12&&fabs(solve(10,10,1e4)[10]-20)<1e-12,"BCs imposed");}
  { // backprop
   P p;auto g=grad(p);cout<<setprecision(8)<<"grad dw,db,dv,dc = "<<g[0]<<" "<<g[1]<<" "<<g[2]<<" "<<g[3]<<"\n";
   double e=1e-6;bool ok=true;for(int i=0;i<4;i++){P a=p,b=p;double*pa[4]={&a.w,&a.b,&a.v,&a.c},*pb[4]={&b.w,&b.b,&b.v,&b.c};*pa[i]+=e;*pb[i]-=e;
     double fd=(Lf(a)-Lf(b))/(2*e);if(fabs(fd-g[i])>1e-5)ok=false;}
   chk(ok,"central-difference gradient check (eps=1e-6, tol 1e-5)");
   ofstream o("results/backprop_loss.csv");o<<"step,loss\n";double h,y;P q=p;auto g0=grad(q);
   q.w-=.1*g0[0];q.b-=.1*g0[1];q.v-=.1*g0[2];q.c-=.1*g0[3];
   cout<<"after update w,b,v,c = "<<q.w<<" "<<q.b<<" "<<q.v<<" "<<q.c<<"\n";
   for(int s=1;s<=100;s++){o<<s<<","<<loss(q,h,y)<<"\n";auto gg=grad(q);q.w-=.1*gg[0];q.b-=.1*gg[1];q.v-=.1*gg[2];q.c-=.1*gg[3];}
   chk(loss(q,h,y)<loss(p,h,y),"loss decreased over 100 steps");}
  { // batch
   int M=2000,n=4000;auto cs=gen(n,12345);unsigned hw=thread::hardware_concurrency();cout<<"logical CPUs="<<hw<<" cases="<<n<<" mesh="<<M<<"\n";
   auto ref=run(cs,M,1);ofstream o("results/performance.csv");o<<"workers,median_s,speedup,efficiency\n";double t1=0;
   for(int p:{1,2,4}){if((unsigned)p>max(1u,hw)&&!(hw<2&&p==2))break;run(cs,M,p);vector<double>ts;vector<vector<double>>r;
     for(int rep=0;rep<5;rep++){auto a=chrono::steady_clock::now();r=run(cs,M,p);ts.push_back(chrono::duration<double>(chrono::steady_clock::now()-a).count());}
     double m=med(ts);if(p==1)t1=m;double d=0;for(int i=0;i<n;i++)for(int j=0;j<=M;j++)d=max(d,fabs(r[i][j]-ref[i][j]));
     cout<<"p="<<p<<" median="<<m<<" s speedup="<<t1/m<<" eff="<<t1/m/p<<" maxdiff="<<scientific<<d<<fixed<<"\n";o<<p<<","<<m<<","<<t1/m<<","<<t1/m/p<<"\n";chk(d<=1e-8,"serial/parallel agree p="+to_string(p));}
   if(hw<2)cout<<"NOTE: single logical CPU; speedup cannot be assessed\n";}
  { // mock hardware
   vector<Dev>d={{"mcu0","MCU"},{"fpga0","FPGA"},{"jtag0","JTAG"}};d[1].fail=1;
   for(auto&x:d){cout<<"[SIMULATED] "<<x.id<<" caps: "<<x.caps()<<"\n";if(!x.connect()){cout<<"[SIMULATED] timeout on "<<x.id<<", retrying\n";}
     chk(x.connect()||x.conn,"connect "+x.id);cout<<x.telem()<<"\n";}}
  { // validators
   system("printf 'solid t\\n facet normal 0 0 1\\n outer loop\\n vertex 0 0 0\\n vertex 1 0 0\\n vertex 0 1 0\\n endloop\\n endfacet\\nendsolid\\n' > data/example.stl");
   system("printf 'node_id,x_m,y_m,z_m,temperature_C\\n1,0,0,0,100\\n2,.5,0,0,60\\n3,1,0,0,20\\n' > data/synthetic_nodal_temps.csv");
   system("printf 'node_id,x_m,y_m,z_m,temperature_C\\n1,0,0,0,nan\\n' > tests/bad.csv; : > tests/empty.stl; printf 'solid x\\n vertex 0 0 inf\\n' > tests/bad.stl");
   size_t n;chk(stl("data/example.stl",n).empty()&&n==1,"valid STL");chk(stl("tests/empty.stl",n)=="empty file","empty STL explained");
   chk(!stl("tests/bad.stl",n).empty(),"non-finite STL rejected");chk(csv("data/synthetic_nodal_temps.csv",n).empty()&&n==3,"valid CSV");
   chk(!csv("tests/bad.csv",n).empty(),"NaN CSV rejected");}
  cout<<(fails?"FAILURES: ":"ALL PASSED ")<<fails<<"\n";return fails;}

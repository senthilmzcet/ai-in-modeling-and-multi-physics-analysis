// Headless CLI: produces the raw CSV evidence in results/ using the same core library.
#include "../core/thermal.hpp"
#include "../core/batch.hpp"
#include "../core/backprop.hpp"
#include <fstream>
#include <iostream>
#include <iomanip>
#include <cmath>
using namespace wb;
int main(int argc, char** argv) {
  std::string out = argc > 1 ? argv[1] : "results";
  std::cout << std::setprecision(12);
  { RodParams p; std::ofstream n(out + "/fea_nodes.csv"), m(out + "/fea_midpoints.csv"), s(out + "/fea_convergence.csv");
    n << "N,x_m,T_fe_C,T_exact_C,nodal_abs_err_C\n"; m << "N,element,x_mid_m,T_fe_mid_C,T_exact_mid_C,abs_err_C\n";
    s << "N,h_m,max_midpoint_abs_err_C,max_nodal_abs_err_C,observed_order\n"; n << std::setprecision(12); m << std::setprecision(12); s << std::setprecision(12);
    double prev = 0; int pn = 0;
    for (int N : {10, 20, 40, 80}) { p.N = N; auto r = solveRod(p);
      for (int i = 0; i <= N; ++i) n << N << "," << r.x[i] << "," << r.T[i] << "," << exactT(p, r.x[i]) << "," << std::fabs(r.T[i] - exactT(p, r.x[i])) << "\n";
      for (int i = 0; i < N; ++i) { double xm = (i + .5) * p.L / N, tf = .5 * (r.T[i] + r.T[i + 1]); m << N << "," << i << "," << xm << "," << tf << "," << exactT(p, xm) << "," << std::fabs(tf - exactT(p, xm)) << "\n"; }
      s << N << "," << p.L / N << "," << r.maxMidErr << "," << r.maxNodalErr << "," << (pn ? convergenceOrder(prev, r.maxMidErr, (double)N / pn) : NAN) << "\n";
      std::cout << "N=" << N << " max midpoint err=" << r.maxMidErr << " C, nodal err=" << r.maxNodalErr << " C\n"; prev = r.maxMidErr; pn = N; } }
  { BatchSpec spec; auto r = runBenchmark(spec); std::ofstream f(out + "/benchmark.csv"); f << std::setprecision(12);
    f << "workers,rep1_s,rep2_s,rep3_s,rep4_s,rep5_s,median_s,speedup_T1_over_Tp,efficiency,max_abs_diff_C\n";
    for (auto& w : r.rows) { f << w.workers; for (double t : w.times) f << "," << t; f << "," << w.median << "," << w.speedup << "," << w.efficiency << "," << w.diff << "\n"; }
    std::ofstream i(out + "/benchmark_system.txt");
    i << "cpu: " << r.sys.cpu << "\nlogical_cpus: " << r.sys.logical << "\nphysical_cores: " << r.sys.physical << "\nram_gb: " << r.sys.ramGB << "\ncompiler: " << r.sys.compiler
      << "\nflags: " << r.sys.flags << "\nworkload: seed=" << spec.seed << " cases=" << spec.cases << " elements=" << spec.elements << "\nwarmup: 1 run per worker count\nrepetitions: " << r.reps << "\nnote: " << r.note << "\n";
    std::cout << "benchmark rows: " << r.rows.size() << " note: " << r.note << "\n"; for (auto& w : r.rows) std::cout << " p=" << w.workers << " median=" << w.median << "s speedup=" << w.speedup << " diff=" << w.diff << "\n"; }
  { BpParams p; double x = 1, y = 2, lr = 0.1; auto g = bpGrad(p, x, y); auto n = bpNumGrad(p, x, y, 1e-6); auto f = bpForward(p, x, y);
    std::ofstream o(out + "/backprop_gradcheck.csv"); o << std::setprecision(12); o << "param,analytic,numeric_central_diff,abs_error\n";
    o << "w," << g.dw << "," << n.dw << "," << std::fabs(g.dw - n.dw) << "\nb," << g.db << "," << n.db << "," << std::fabs(g.db - n.db) << "\nv," << g.dv << "," << n.dv << "," << std::fabs(g.dv - n.dv) << "\nc," << g.dc << "," << n.dc << "," << std::fabs(g.dc - n.dc) << "\n";
    auto u = bpStep(p, g, lr); auto run = bpTrain(u, x, y, lr, 100); std::ofstream l(out + "/backprop_loss.csv"); l << std::setprecision(12); l << "step,loss\n0," << f.J << "\n1," << bpForward(u, x, y).J << "\n";
    for (size_t i = 1; i < run.loss.size(); ++i) l << i + 1 << "," << run.loss[i] << "\n";
    std::cout << "J0=" << f.J << " grads " << g.dw << " " << g.db << " " << g.dv << " " << g.dc << " updated w=" << u.w << " b=" << u.b << " v=" << u.v << " c=" << u.c << "\n"; }
  return 0;
}

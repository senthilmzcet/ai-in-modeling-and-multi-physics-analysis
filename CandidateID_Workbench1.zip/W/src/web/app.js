'use strict';
const $ = s => document.querySelector(s);
const statusEl = $('#status');
function setStatus(m, err) { statusEl.textContent = m; statusEl.className = err ? 'err' : ''; }
async function api(path, opt) {
  let r, t;
  try { r = await fetch(path, opt); t = await r.text(); } catch (e) { throw new Error('Backend not reachable. Re-open Launch.exe.'); }
  let j; try { j = JSON.parse(t); } catch { j = null; }
  if (!r.ok) throw new Error(j && j.error ? j.error : (j && j.message ? j.message : 'HTTP ' + r.status));
  return j || t;
}
// ---------- tabs & heartbeat ----------
document.querySelectorAll('#tabs button').forEach(b => b.onclick = () => {
  document.querySelectorAll('#tabs button').forEach(x => x.classList.toggle('on', x === b));
  document.querySelectorAll('.view').forEach(v => v.classList.toggle('on', v.id === b.dataset.v));
  if (b.dataset.v === 'geo') viewer.draw();
});
async function ping() { try { const j = await api('/api/ping'); $('#conn').textContent = 'backend online'; $('#conn').className = 'pill ok'; window.launchMs = j.launch_to_ready_ms; }
  catch { $('#conn').textContent = 'backend offline'; $('#conn').className = 'pill bad'; } }
ping(); setInterval(ping, 3000);
window.addEventListener('pagehide', () => {});
// ---------- charts ----------
function chart(cv, o) {
  const c = cv.getContext('2d'), W = cv.width, H = cv.height, m = { l: 70, r: 15, t: 34, b: 50 };
  const css = getComputedStyle(document.body); const fg = css.color, bg = css.backgroundColor;
  c.fillStyle = getComputedStyle(cv).backgroundColor; c.fillRect(0, 0, W, H); c.fillStyle = fg; c.strokeStyle = fg; c.font = '13px sans-serif';
  const xs = [].concat(...o.series.map(s => s.x)), ys = [].concat(...o.series.map(s => s.y)).filter(v => !o.logy || v > 0);
  let x0 = Math.min(...xs), x1 = Math.max(...xs), y0 = Math.min(...ys), y1 = Math.max(...ys);
  if (o.logy) { y0 = Math.log10(y0); y1 = Math.log10(y1); } if (o.logx) { x0 = Math.log10(x0); x1 = Math.log10(x1); }
  if (y0 === y1) { y0 -= 1; y1 += 1; } if (x0 === x1) { x0 -= 1; x1 += 1; }
  const pad = (y1 - y0) * 0.05; y0 -= pad; y1 += pad;
  const X = v => m.l + ((o.logx ? Math.log10(v) : v) - x0) / (x1 - x0) * (W - m.l - m.r), Y = v => H - m.b - ((o.logy ? Math.log10(v) : v) - y0) / (y1 - y0) * (H - m.t - m.b);
  c.textAlign = 'center'; c.fillText(o.title, W / 2, 20); c.fillText(o.xlabel, W / 2, H - 8);
  c.save(); c.translate(16, H / 2); c.rotate(-Math.PI / 2); c.fillText(o.ylabel, 0, 0); c.restore();
  c.globalAlpha = .25; c.font = '11px sans-serif';
  for (let i = 0; i <= 5; i++) { const xv = x0 + (x1 - x0) * i / 5, yv = y0 + (y1 - y0) * i / 5, px = m.l + (W - m.l - m.r) * i / 5, py = H - m.b - (H - m.t - m.b) * i / 5;
    c.beginPath(); c.moveTo(px, m.t); c.lineTo(px, H - m.b); c.moveTo(m.l, py); c.lineTo(W - m.r, py); c.stroke();
    c.globalAlpha = 1; c.textAlign = 'center'; c.fillText(fmt(o.logx ? Math.pow(10, xv) : xv), px, H - m.b + 15); c.textAlign = 'right'; c.fillText(fmt(o.logy ? Math.pow(10, yv) : yv), m.l - 5, py + 4); c.globalAlpha = .25; }
  c.globalAlpha = 1; c.strokeRect(m.l, m.t, W - m.l - m.r, H - m.t - m.b);
  const cols = ['#1f6feb', '#d1242f', '#1a7f37', '#bf8700', '#8250df', '#e16f24'];
  o.series.forEach((s, i) => { c.strokeStyle = c.fillStyle = s.color || cols[i % cols.length]; c.lineWidth = 2; c.setLineDash(s.dash ? [6, 4] : []);
    if (!s.nolines) { c.beginPath(); s.x.forEach((x, k) => { const px = X(x), py = Y(s.y[k]); k ? c.lineTo(px, py) : c.moveTo(px, py); }); c.stroke(); }
    c.setLineDash([]); if (s.markers) s.x.forEach((x, k) => { c.beginPath(); c.arc(X(x), Y(s.y[k]), 3.5, 0, 7); c.fill(); });
    c.font = '12px sans-serif'; c.textAlign = 'left'; c.fillRect(m.l + 8, m.t + 8 + i * 16, 14, 3); c.fillStyle = fg; c.fillText(s.name, m.l + 28, m.t + 13 + i * 16); });
  c.lineWidth = 1; c.strokeStyle = fg;
}
function fmt(v) { const a = Math.abs(v); return a !== 0 && (a < 0.01 || a >= 1e5) ? v.toExponential(1) : (+v.toPrecision(4)).toString(); }
document.querySelectorAll('[data-png]').forEach(b => b.onclick = () => dlCanvas($('#' + b.dataset.png), b.dataset.png + '.png'));
function dlCanvas(cv, name) { cv.toBlob(bl => { const a = document.createElement('a'); a.href = URL.createObjectURL(bl); a.download = name; a.click(); }); }
function dlText(txt, name, type) { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([txt], { type: type || 'text/csv' })); a.download = name; a.click(); }
// ---------- 3-D viewer (Canvas 2-D, software projection) ----------
const viewer = (() => {
  const cv = $('#view3d'), c = cv.getContext('2d');
  const S = { yaw: -0.6, pitch: 0.4, zoom: 1, px: 0, py: 0, tris: null, nT: 0, nodes: null, bmin: null, bmax: null, sel: -1, moving: false };
  const cmap = t => { t = Math.max(0, Math.min(1, t)); const st = [[49, 54, 149], [69, 117, 180], [116, 173, 209], [171, 217, 233], [254, 224, 144], [253, 174, 97], [244, 109, 67], [215, 48, 39], [165, 0, 38]];
    const f = t * (st.length - 1), i = Math.min(st.length - 2, Math.floor(f)), u = f - i; return st[i].map((a, k) => Math.round(a + (st[i + 1][k] - a) * u)); };
  function bounds() { let mn = [Infinity, Infinity, Infinity], mx = [-Infinity, -Infinity, -Infinity]; const add = (a, b) => { for (let i = 0; i < 3; i++) { mn[i] = Math.min(mn[i], a[i]); mx[i] = Math.max(mx[i], b[i]); } };
    if (S.tris) add(S.bmin, S.bmax); if (S.nodes) add(S.nodes.bmin, S.nodes.bmax); return mn[0] === Infinity ? null : [mn, mx]; }
  function fit() { S.zoom = 1; S.px = S.py = 0; S.yaw = -0.6; S.pitch = 0.4; draw(); }
  function proj() { const b = bounds(); if (!b) return null; const cen = b[0].map((v, i) => (v + b[1][i]) / 2), r = Math.hypot(...b[0].map((v, i) => b[1][i] - v)) / 2 || 1;
    const sc = S.zoom * Math.min(cv.width, cv.height) * 0.45 / r, cy = Math.cos(S.yaw), sy = Math.sin(S.yaw), cp = Math.cos(S.pitch), sp = Math.sin(S.pitch);
    return { cen, sc, f: (x, y, z) => { x -= cen[0]; y -= cen[1]; z -= cen[2]; const x1 = cy * x + sy * z, z1 = -sy * x + cy * z, y1 = cp * y - sp * z1, z2 = sp * y + cp * z1;
      return [cv.width / 2 + S.px + x1 * sc, cv.height / 2 + S.py - y1 * sc, z2]; } }; }
  function draw() {
    c.fillStyle = getComputedStyle(cv).backgroundColor; c.fillRect(0, 0, cv.width, cv.height);
    const P = proj(); if (!P) { c.fillStyle = getComputedStyle(document.body).color; c.fillText('No geometry loaded', 20, 30); return; }
    if (S.tris) { const stride = Math.max(1, Math.ceil(S.nT / (S.moving ? 6000 : 30000))), list = [];
      for (let t = 0; t < S.nT; t += stride) { const o = t * 9, a = P.f(S.tris[o], S.tris[o + 1], S.tris[o + 2]), b = P.f(S.tris[o + 3], S.tris[o + 4], S.tris[o + 5]), d = P.f(S.tris[o + 6], S.tris[o + 7], S.tris[o + 8]);
        const nz = (b[0] - a[0]) * (d[1] - a[1]) - (b[1] - a[1]) * (d[0] - a[0]); list.push([a, b, d, (a[2] + b[2] + d[2]) / 3, Math.abs(nz)]); }
      list.sort((u, v) => v[3] - u[3]); let mxn = 1e-9; for (const q of list) mxn = Math.max(mxn, q[4]);
      for (const q of list) { const sh = 0.35 + 0.65 * Math.min(1, q[4] / (mxn * 0.6)); c.fillStyle = `rgb(${Math.round(120 * sh)},${Math.round(150 * sh)},${Math.round(190 * sh)})`; c.strokeStyle = 'rgba(0,0,0,.25)';
        c.beginPath(); c.moveTo(q[0][0], q[0][1]); c.lineTo(q[1][0], q[1][1]); c.lineTo(q[2][0], q[2][1]); c.closePath(); c.fill(); if (list.length < 8000) c.stroke(); } }
    if (S.nodes) { const n = S.nodes, N = n.T.length, stride = Math.max(1, Math.ceil(N / (S.moving ? 30000 : 200000))), pts = [];
      for (let i = 0; i < N; i += stride) { const p = P.f(n.x[i], n.y[i], n.z[i]); pts.push([p[0], p[1], p[2], i]); } if (pts.length < 60000) pts.sort((a, b) => b[2] - a[2]);
      const rng = n.tmax - n.tmin || 1, r = N > 100000 ? 1.5 : 3.2;
      for (const p of pts) { const col = cmap((n.T[p[3]] - n.tmin) / rng); c.fillStyle = `rgb(${col})`; c.fillRect(p[0] - r, p[1] - r, 2 * r, 2 * r); }
      if (S.sel >= 0) { const p = P.f(n.x[S.sel], n.y[S.sel], n.z[S.sel]); c.strokeStyle = '#000'; c.lineWidth = 2; c.strokeRect(p[0] - 7, p[1] - 7, 14, 14); c.lineWidth = 1; } }
  }
  function legend() { const n = S.nodes, el = $('#legend'); if (!n) { el.innerHTML = ''; return; }
    el.innerHTML = `<b>Temperature (°C)</b><div style="display:flex;gap:6px;align-items:stretch"><div style="width:16px;height:120px;background:linear-gradient(to top,rgb(49,54,149),rgb(171,217,233),rgb(254,224,144),rgb(215,48,39),rgb(165,0,38))"></div><div style="display:flex;flex-direction:column;justify-content:space-between"><span>${fmt(n.tmax)} °C</span><span>${fmt((n.tmax + n.tmin) / 2)} °C</span><span>${fmt(n.tmin)} °C</span></div></div>`; }
  let drag = null; cv.oncontextmenu = e => e.preventDefault();
  cv.onpointerdown = e => { drag = { x: e.clientX, y: e.clientY, pan: e.shiftKey || e.button === 2, moved: 0 }; cv.setPointerCapture(e.pointerId); cv.style.cursor = 'grabbing'; };
  cv.onpointermove = e => { if (!drag) return; const k = cv.width / cv.getBoundingClientRect().width, dx = (e.clientX - drag.x) * k, dy = (e.clientY - drag.y) * k; drag.x = e.clientX; drag.y = e.clientY; drag.moved += Math.abs(dx) + Math.abs(dy);
    if (drag.pan) { S.px += dx; S.py += dy; } else { S.yaw += dx * 0.01; S.pitch = Math.max(-1.55, Math.min(1.55, S.pitch + dy * 0.01)); } S.moving = true; draw(); };
  cv.onpointerup = e => { const was = drag; drag = null; cv.style.cursor = 'grab'; S.moving = false; if (was && was.moved < 4) pick(e); draw(); };
  cv.onwheel = e => { e.preventDefault(); S.zoom *= e.deltaY < 0 ? 1.12 : 1 / 1.12; S.zoom = Math.max(0.05, Math.min(500, S.zoom)); draw(); };
  function pick(e) { if (!S.nodes) return; const P = proj(), r = cv.getBoundingClientRect(), k = cv.width / r.width, mx = (e.clientX - r.left) * k, my = (e.clientY - r.top) * k; let best = -1, bd = 12 * 12, bz = Infinity; const n = S.nodes;
    for (let i = 0; i < n.T.length; i++) { const p = P.f(n.x[i], n.y[i], n.z[i]), d = (p[0] - mx) ** 2 + (p[1] - my) ** 2; if (d < bd - 1e-9 || (Math.abs(d - bd) < 1e-9 && p[2] < bz)) { if (d <= bd) { bd = Math.min(bd, d); best = i; bz = p[2]; } } }
    S.sel = best; $('#nodeInfo').textContent = best < 0 ? '–' : `node_id: ${n.id[best]}\nx: ${n.x[best]} m\ny: ${n.y[best]} m\nz: ${n.z[best]} m\nT: ${n.T[best]} °C`; }
  return { S, draw, fit, legend, canvas: cv };
})();
$('#fit').onclick = () => viewer.fit();
$('#expGeo').onclick = () => dlCanvas(viewer.canvas, 'geometry_view.png');
async function loadStl(text, name) {
  try { setStatus('Parsing STL in C++ backend…'); const j = await api('/api/stl', { method: 'POST', headers: { 'Content-Type': 'text/plain' }, body: text });
    const S = viewer.S; S.tris = new Float32Array(j.v); S.nT = j.triangles; S.bmin = j.bmin; S.bmax = j.bmax; viewer.fit();
    $('#geoInfo').textContent = `STL: ${name}\ntriangles: ${j.triangles}\nbounds min: ${j.bmin.join(', ')}\nbounds max: ${j.bmax.join(', ')}\nunits: ${j.units}` + ($('#geoInfo').textContent.includes('CSV:') ? '\n' + $('#geoInfo').textContent.split('\n').filter(l => /^CSV|^nodes|^T range/.test(l)).join('\n') : '');
    setStatus(`Loaded STL ${name}: ${j.triangles} triangles.`); } catch (e) { setStatus('STL error: ' + e.message, true); } }
async function loadCsv(text, name) {
  try { setStatus('Parsing CSV in C++ backend…'); const j = await api('/api/nodes', { method: 'POST', headers: { 'Content-Type': 'text/plain' }, body: text }); const S = viewer.S;
    const b = [[Infinity, Infinity, Infinity], [-Infinity, -Infinity, -Infinity]]; for (const [k, a] of [[0, j.x], [1, j.y], [2, j.z]]) for (let i = 0; i < a.length; i++) { if (a[i] < b[0][k]) b[0][k] = a[i]; if (a[i] > b[1][k]) b[1][k] = a[i]; }
    S.nodes = { id: j.id, x: j.x, y: j.y, z: j.z, T: j.T, tmin: j.tmin, tmax: j.tmax, bmin: b[0], bmax: b[1] }; S.sel = -1; viewer.legend(); viewer.fit();
    $('#geoInfo').textContent += `\nCSV: ${name}\nnodes: ${j.count}\nT range: ${j.tmin} .. ${j.tmax} °C (units: xyz m, T °C)`; setStatus(`Loaded ${j.count} nodes from ${name}.`); } catch (e) { setStatus('CSV error: ' + e.message, true); } }
function readFile(input, fn) { input.onchange = () => { const f = input.files[0]; if (!f) return; if (f.size === 0) { setStatus(`${f.name} is empty (0 bytes). Select a non-empty file.`, true); return; }
  if (f.size > 120 * 1024 * 1024) { setStatus('File larger than 120 MB limit.', true); return; } const r = new FileReader(); r.onload = () => fn(r.result, f.name); r.onerror = () => setStatus('Could not read file.', true); r.readAsText(f); input.value = ''; }; }
readFile($('#stlFile'), loadStl); readFile($('#csvFile'), loadCsv);
$('#stlSample').onclick = async () => { try { loadStl(await api('/api/sample/sample_rod.stl'), 'sample_rod.stl'); } catch (e) { setStatus(e.message, true); } };
$('#csvSample').onclick = async () => { try { loadCsv(await api('/api/sample/sample_nodes_SYNTHETIC.csv'), 'sample_nodes_SYNTHETIC.csv (synthetic)'); } catch (e) { setStatus(e.message, true); } };
// ---------- FEA ----------
function feaQuery() { const g = id => encodeURIComponent($('#' + id).value.trim()); return `L=${g('pL')}&A=${g('pA')}&k=${g('pk')}&q=${g('pq')}&T0=${g('pT0')}&TL=${g('pTL')}&N=${g('pN')}`; }
$('#feaRun').onclick = async () => {
  try { setStatus('Solving…'); const j = await api('/api/fea?' + feaQuery()); const cols = ['#1f6feb', '#1a7f37', '#bf8700', '#8250df'];
    const s = j.runs.map((r, i) => ({ name: `FE N=${r.N}`, x: r.x, y: r.T, color: cols[i % 4], markers: r.N <= 20 })); const last = j.runs[j.runs.length - 1];
    s.push({ name: 'Exact', x: last.x, y: last.T_exact, color: '#d1242f', dash: true });
    chart($('#feaT'), { title: 'Temperature along rod', xlabel: 'x (m)', ylabel: 'T (°C)', series: s });
    chart($('#feaE'), { title: 'Mesh convergence: max midpoint error', xlabel: 'h (m)', ylabel: 'max |T_FE − T_exact| at midpoints (°C)', logx: true, logy: true, series: [{ name: 'FE', x: j.runs.map(r => r.h), y: j.runs.map(r => r.max_mid_err), markers: true }] });
    $('#feaTable').innerHTML = '<tr><th>N</th><th>h (m)</th><th>max midpoint err (°C)</th><th>observed order</th><th>max nodal err (°C)</th></tr>' + j.runs.map(r => `<tr><td>${r.N}</td><td>${fmt(r.h)}</td><td>${r.max_mid_err.toPrecision(6)}</td><td>${r.order == null ? '–' : r.order.toFixed(3)}</td><td>${r.max_nodal_err.toExponential(2)}</td></tr>`).join('');
    const q = feaQuery(); $('#feaCsv').href = '/api/fea/csv?' + q; $('#feaCsvMid').href = '/api/fea/csv?mid=1&' + q; setStatus('FEA solved.'); } catch (e) { setStatus('FEA error: ' + e.message, true); } };
$('#feaCsv').href = '/api/fea/csv'; $('#feaCsvMid').href = '/api/fea/csv?mid=1';
// ---------- Performance ----------
let lastBench = null, poll = null;
function setBusy(b) { $('#bRun').disabled = $('#bBench').disabled = b; $('#bCancel').disabled = !b; }
function specQ() { const g = id => encodeURIComponent($('#' + id).value.trim()); return `seed=${g('bSeed')}&cases=${g('bCases')}&elements=${g('bElems')}`; }
async function startJob(url) { try { await api(url, { method: 'POST' }); setBusy(true); $('#perfOut').textContent = 'Running…'; poll = setInterval(pollJob, 300); } catch (e) { setStatus('Job error: ' + e.message, true); } }
$('#bRun').onclick = () => startJob(`/api/batch/start?${specQ()}&workers=${encodeURIComponent($('#bWork').value.trim())}`);
$('#bBench').onclick = () => startJob(`/api/bench/start?${specQ()}`);
$('#bCancel').onclick = async () => { await api('/api/job/cancel', { method: 'POST' }); setStatus('Cancelling…'); };
async function pollJob() { try { const j = await api('/api/job/status'); const tot = j.total || 1;
  if (j.kind === 'bench') { $('#prog').removeAttribute('value'); $('#progTxt').textContent = j.state === 'running' ? 'benchmark running (warm-up + 5 reps per worker count)…' : j.state; }
  else { $('#prog').max = tot; $('#prog').value = j.done; $('#progTxt').textContent = `${j.done}/${j.total}`; }
  if (j.state !== 'running') { clearInterval(poll); setBusy(false); $('#prog').value = 0; $('#prog').max = 1;
    if (j.state === 'error') { setStatus('Job failed: ' + j.error, true); $('#perfOut').textContent = 'Error: ' + j.error; }
    else if (j.state === 'cancelled') { setStatus('Job cancelled safely; partial results discarded.'); $('#perfOut').textContent = 'Cancelled — no results kept.'; }
    else if (j.kind === 'bench') showBench(j.result); else { $('#perfOut').textContent = `Batch: ${j.result.cases} cases, ${j.result.workers} worker(s): ${j.result.seconds.toFixed(4)} s, max T = ${j.result.max_T_C.toFixed(3)} °C`; setStatus('Batch done.'); } } }
  catch (e) { clearInterval(poll); setBusy(false); setStatus(e.message, true); } }
function showBench(r) { lastBench = r; const s = r.sys; let t = `CPU: ${s.cpu}\nLogical CPUs: ${s.logical}  Physical cores: ${s.physical}  RAM: ${s.ram_gb.toFixed(2)} GB\nCompiler: ${s.compiler}  Flags: ${s.flags}\nWorkload: seed=${r.workload.seed} cases=${r.workload.cases} elements=${r.workload.elements}; warm-up 1 run; ${r.workload.reps} measured reps\nLaunch-to-ready (server): ${window.launchMs ? window.launchMs.toFixed(1) : '?'} ms (excluded from compute timings)\n\n workers  median(s)  speedup  efficiency  max|ΔT| (°C)\n`;
  r.rows.forEach(w => t += `${String(w.workers).padStart(7)}  ${w.median.toFixed(5).padStart(9)}  ${w.speedup.toFixed(3).padStart(7)}  ${w.efficiency.toFixed(3).padStart(10)}  ${w.max_abs_diff.toExponential(2)}\n`);
  t += `\nAgreement criterion ≤ 1e-8 °C: ${r.rows.every(w => w.max_abs_diff <= 1e-8) ? 'PASS' : 'FAIL'}\n` + (r.note ? '\nNOTE: ' + r.note : ''); $('#perfOut').textContent = t;
  chart($('#perfC'), { title: 'Speedup T1/Tp', xlabel: 'workers p', ylabel: 'speedup', series: [{ name: 'measured', x: r.rows.map(w => w.workers), y: r.rows.map(w => w.speedup), markers: true }, { name: 'ideal', x: r.rows.map(w => w.workers), y: r.rows.map(w => w.workers), dash: true }] }); setStatus('Benchmark done.'); }
$('#perfCsv').onclick = () => { if (!lastBench) { setStatus('Run the benchmark first.', true); return; } let t = 'workers,rep1_s,rep2_s,rep3_s,rep4_s,rep5_s,median_s,speedup,efficiency,max_abs_diff_C\n';
  lastBench.rows.forEach(w => t += [w.workers, ...w.times, w.median, w.speedup, w.efficiency, w.max_abs_diff].join(',') + '\n'); dlText(t, 'benchmark.csv'); };
// ---------- Hardware (simulated) ----------
const hwLog = m => { $('#hwLog').textContent = `[${new Date().toLocaleTimeString()}] ${m}\n` + $('#hwLog').textContent; };
async function discover() { try { const j = await api('/api/hw/discover'); $('#devs').innerHTML = j.devices.map(d => `<div class="dev"><h4>${d.name}</h4><div>[SIMULATED] ${d.kind} · ${d.voltage} · ${d.transport}<br>State: <b>${d.connected ? 'connected' : 'disconnected'}</b></div><ul>${d.capabilities.map(c => `<li>${c.name}: ${c.value}</li>`).join('')}</ul>
  <button data-a="connect" data-id="${d.id}">Connect</button> <button data-a="disconnect" data-id="${d.id}">Disconnect</button> <button data-a="telemetry" data-id="${d.id}">Telemetry</button></div>`).join('');
  document.querySelectorAll('#devs button').forEach(b => b.onclick = () => hwAct(b.dataset.a, b.dataset.id)); } catch (e) { setStatus(e.message, true); } }
async function hwAct(a, id) { try { let j;
  if (a === 'connect') { const inj = $('#hwInj').checked; try { j = await api(`/api/hw/connect?id=${id}&inject_timeout=${inj ? 1 : 0}`, { method: 'POST' }); hwLog(`${id}: ${j.message}`); }
      catch (e) { hwLog(`${id}: FAILED — ${e.message}. Recoverable: untick "inject timeout" and press Connect again.`); setStatus(`${id}: ${e.message} (simulated timeout, recoverable — retry)`, true); $('#hwInj').checked = false; return; } }
  else if (a === 'disconnect') { j = await api(`/api/hw/disconnect?id=${id}`, { method: 'POST' }); hwLog(`${id}: ${j.message}`); }
  else { j = await api(`/api/hw/telemetry?id=${id}`); hwLog(`${id}: telemetry ${JSON.stringify(j.telemetry)}`); }
  setStatus(`${id}: ${a} OK (simulated)`); discover(); } catch (e) { hwLog(`${id}: ${e.message}`); setStatus(e.message, true); } }
$('#hwDisc').onclick = discover; discover();
// ---------- Backprop ----------
$('#bpRun').onclick = async () => { try { const j = await api('/api/backprop'); const f = j.forward, g = j.grad, n = j.numgrad, u = j.updated;
  $('#bpOut').textContent = `Forward: z=${f.z.toFixed(8)}  h=${f.h.toFixed(8)}  y_hat=${f.yhat.toFixed(8)}  J=${f.J.toFixed(8)}\n\nparam   analytic        central-diff    |err|\n` + ['w', 'b', 'v', 'c'].map(p => `${p}   ${g['d' + p].toFixed(9).padStart(14)}  ${n['d' + p].toFixed(9).padStart(14)}  ${Math.abs(g['d' + p] - n['d' + p]).toExponential(2)}`).join('\n') +
   `\nmax gradient error = ${j.max_grad_error.toExponential(2)} (limit 1e-5): ${j.max_grad_error <= 1e-5 ? 'PASS' : 'FAIL'}\n\nAfter 1 simultaneous update (lr=0.1): w=${u.w.toFixed(8)} b=${u.b.toFixed(8)} v=${u.v.toFixed(8)} c=${u.c.toFixed(8)}`;
  chart($('#bpC'), { title: 'Training loss (lr = 0.1)', xlabel: 'training step', ylabel: 'J = ½(ŷ − y)²', series: [{ name: 'loss', x: j.loss.map((_, i) => i), y: j.loss }] }); setStatus('Backprop computed.'); } catch (e) { setStatus(e.message, true); } };
viewer.draw(); $('#feaRun').click(); $('#bpRun').click();

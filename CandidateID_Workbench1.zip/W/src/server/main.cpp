// Transport layer: HTTP/JSON on 127.0.0.1 only. All computation lives in wb_core.
#include "httplib.h"
#include "../core/thermal.hpp"
#include "../core/batch.hpp"
#include "../core/formats.hpp"
#include "../core/backprop.hpp"
#include "../core/devices.hpp"
#include "../core/json.hpp"
#include <chrono>
#include <thread>
#include <mutex>
#include <fstream>
#include <sstream>
#include <memory>
#include <iostream>
#include <cstdlib>
using namespace wb;
using Clock = std::chrono::steady_clock;

static std::string param(const httplib::Request& r, const char* k, const char* def) { return r.has_param(k) ? r.get_param_value(k) : def; }
static bool parseD(const std::string& s, double& d) { char* e; d = std::strtod(s.c_str(), &e); return !s.empty() && *e == 0 && std::isfinite(d); }
static bool parseI(const std::string& s, long& d) { char* e; d = std::strtol(s.c_str(), &e, 10); return !s.empty() && *e == 0; }

struct Job {                       // one asynchronous batch/benchmark job at a time
  std::mutex m; std::thread th; BatchControl ctl; std::string state = "idle", result = "{}", error;
  int total = 0; std::string kind;
  void join() { if (th.joinable()) th.join(); }
};

static std::string benchJson(const BenchReport& r) {
  std::ostringstream o; o.precision(9);
  o << "{\"ok\":true,\"cancelled\":" << (r.cancelled ? "true" : "false") << ",\"sys\":{\"cpu\":" << js::q(r.sys.cpu) << ",\"logical\":" << r.sys.logical
    << ",\"physical\":" << r.sys.physical << ",\"ram_gb\":" << js::num(r.sys.ramGB) << ",\"compiler\":" << js::q(r.sys.compiler) << ",\"flags\":" << js::q(r.sys.flags) << ",\"os\":" << js::q(r.sys.os)
    << "},\"workload\":{\"seed\":" << r.spec.seed << ",\"cases\":" << r.spec.cases << ",\"elements\":" << r.spec.elements << ",\"warmup\":1,\"reps\":" << r.reps
    << "},\"note\":" << js::q(r.note) << ",\"rows\":[";
  for (size_t i = 0; i < r.rows.size(); ++i) { auto& w = r.rows[i]; if (i) o << ",";
    o << "{\"workers\":" << w.workers << ",\"times\":" << js::arr(w.times, 9) << ",\"median\":" << js::num(w.median) << ",\"speedup\":" << js::num(w.speedup)
      << ",\"efficiency\":" << js::num(w.efficiency) << ",\"max_abs_diff\":" << js::num(w.diff) << "}"; }
  o << "]}"; return o.str();
}

int main(int argc, char** argv) {
  auto tStart = Clock::now();
  int port = 8765; std::string web = "src/web", data = "data", results = "results";
  for (int i = 1; i < argc; ++i) {
    std::string a = argv[i];
    if (a == "--port" && i + 1 < argc) port = std::atoi(argv[++i]);
    else if (a == "--web" && i + 1 < argc) web = argv[++i];
    else if (a == "--data" && i + 1 < argc) data = argv[++i];
    else if (a == "--help") { std::cout << "wb_server [--port N] [--web DIR] [--data DIR]\n"; return 0; }
  }
  httplib::Server svr;
  svr.set_payload_max_length(128u * 1024 * 1024);
  DeviceManager dm; std::mutex dmMutex; Job job;
  std::atomic<long long> lastPing{0}; std::atomic<bool> everPinged{false};
  double launchMs = 0;
  auto nowMs = [] { return std::chrono::duration_cast<std::chrono::milliseconds>(Clock::now().time_since_epoch()).count(); };

  auto J = [](httplib::Response& res, const std::string& s, int code = 200) { res.status = code; res.set_content(s, "application/json"); };

  svr.Get("/api/ping", [&](const httplib::Request&, httplib::Response& res) { lastPing = nowMs(); everPinged = true; J(res, "{\"ok\":true,\"app\":\"UnifiedWorkbench\",\"launch_to_ready_ms\":" + js::num(launchMs) + "}"); });
  svr.Post("/api/shutdown", [&](const httplib::Request&, httplib::Response& res) { J(res, "{\"ok\":true}"); std::thread([&] { std::this_thread::sleep_for(std::chrono::milliseconds(200)); svr.stop(); }).detach(); });
  svr.Get("/api/system", [&](const httplib::Request&, httplib::Response& res) {
    SysInfo s = systemInfo();
    J(res, "{\"ok\":true,\"cpu\":" + js::q(s.cpu) + ",\"logical\":" + std::to_string(s.logical) + ",\"physical\":" + std::to_string(s.physical) + ",\"ram_gb\":" + js::num(s.ramGB) + ",\"compiler\":" + js::q(s.compiler) + ",\"flags\":" + js::q(s.flags) + ",\"launch_to_ready_ms\":" + js::num(launchMs) + "}"); });

  // ---- Task C ----
  svr.Get("/api/fea", [&](const httplib::Request& r, httplib::Response& res) {
    RodParams p; double d; long n; std::string e;
    if (!parseD(param(r, "L", "1"), d) ) e += "L is not a number. "; else p.L = d;
    if (!parseD(param(r, "A", "1e-4"), d)) e += "A is not a number. "; else p.A = d;
    if (!parseD(param(r, "k", "10"), d)) e += "k is not a number. "; else p.k = d;
    if (!parseD(param(r, "q", "10000"), d)) e += "q is not a number. "; else p.q = d;
    if (!parseD(param(r, "T0", "100"), d)) e += "T0 is not a number. "; else p.T0 = d;
    if (!parseD(param(r, "TL", "20"), d)) e += "TL is not a number. "; else p.TL = d;
    std::string ns = param(r, "N", "10,20,40,80"); std::vector<int> Ns; std::stringstream ss(ns); std::string t;
    while (std::getline(ss, t, ',')) { if (!parseI(t, n) || n < 1 || n > 200000) { e += "Each N must be an integer in [1, 200000]. "; break; } Ns.push_back((int)n); }
    if (Ns.empty() && e.empty()) e = "Provide at least one N. ";
    if (e.empty()) e = validate(p);
    if (!e.empty()) return J(res, js::err(e), 400);
    std::ostringstream o; o.precision(10); o << "{\"ok\":true,\"units\":{\"x\":\"m\",\"T\":\"C\",\"error\":\"C\"},\"runs\":[";
    double prev = 0; int prevN = 0;
    for (size_t i = 0; i < Ns.size(); ++i) {
      p.N = Ns[i]; RodResult rr = solveRod(p);
      std::vector<double> ex; for (double x : rr.x) ex.push_back(exactT(p, x));
      if (i) o << ",";
      o << "{\"N\":" << p.N << ",\"h\":" << js::num(p.L / p.N) << ",\"max_nodal_err\":" << js::num(rr.maxNodalErr) << ",\"max_mid_err\":" << js::num(rr.maxMidErr)
        << ",\"order\":" << (i && prev > 0 ? js::num(convergenceOrder(prev, rr.maxMidErr, (double)p.N / prevN)) : "null") << ",\"x\":" << js::arr(rr.x) << ",\"T\":" << js::arr(rr.T) << ",\"T_exact\":" << js::arr(ex) << "}";
      prev = rr.maxMidErr; prevN = p.N;
    }
    o << "]}"; J(res, o.str());
  });
  svr.Get("/api/fea/csv", [&](const httplib::Request& r, httplib::Response& res) {
    RodParams p; long n; std::string e; double d;
    if (parseD(param(r, "k", "10"), d)) p.k = d; else e += "bad k. ";
    if (parseD(param(r, "q", "10000"), d)) p.q = d; else e += "bad q. ";
    std::stringstream ss(param(r, "N", "10,20,40,80")); std::string t; std::ostringstream o; o.precision(12);
    o << "N,x_m,T_fe_C,T_exact_C,nodal_abs_err_C\n";
    std::ostringstream m; m.precision(12); m << "N,element,x_mid_m,T_fe_mid_C,T_exact_mid_C,abs_err_C\n";
    bool mid = param(r, "mid", "0") == "1";
    while (std::getline(ss, t, ',')) { if (!parseI(t, n) || n < 1 || n > 200000) { e += "bad N. "; break; } p.N = (int)n;
      if (!validate(p).empty()) { e += validate(p); break; }
      RodResult rr = solveRod(p);
      for (int i = 0; i <= p.N; ++i) o << p.N << "," << rr.x[i] << "," << rr.T[i] << "," << exactT(p, rr.x[i]) << "," << std::fabs(rr.T[i] - exactT(p, rr.x[i])) << "\n";
      for (int i = 0; i < p.N; ++i) { double xm = (i + 0.5) * p.L / p.N, tf = 0.5 * (rr.T[i] + rr.T[i + 1]); m << p.N << "," << i << "," << xm << "," << tf << "," << exactT(p, xm) << "," << std::fabs(tf - exactT(p, xm)) << "\n"; } }
    if (!e.empty()) return J(res, js::err(e), 400);
    res.set_header("Content-Disposition", mid ? "attachment; filename=fea_midpoints.csv" : "attachment; filename=fea_nodes.csv");
    res.set_content(mid ? m.str() : o.str(), "text/csv");
  });

  // ---- Task B ----
  svr.Post("/api/stl", [&](const httplib::Request& r, httplib::Response& res) {
    StlMesh m; std::string e;
    if (!parseAsciiStl(r.body, m, e)) return J(res, js::err(e), 400);
    std::ostringstream o; o << "{\"ok\":true,\"units\":\"as authored (model units)\",\"triangles\":" << m.triangles << ",\"bmin\":" << js::arrf({m.bmin[0], m.bmin[1], m.bmin[2]}) << ",\"bmax\":" << js::arrf({m.bmax[0], m.bmax[1], m.bmax[2]}) << ",\"v\":" << js::arrf(m.v) << "}";
    J(res, o.str()); });
  svr.Post("/api/nodes", [&](const httplib::Request& r, httplib::Response& res) {
    NodeSet n; std::string e;
    if (!parseNodeCsv(r.body, n, e)) return J(res, js::err(e), 400);
    std::ostringstream o; o.precision(9); o << "{\"ok\":true,\"count\":" << n.id.size() << ",\"units\":{\"xyz\":\"m\",\"T\":\"C\"},\"tmin\":" << js::num(n.tmin) << ",\"tmax\":" << js::num(n.tmax) << ",\"id\":[";
    for (size_t i = 0; i < n.id.size(); ++i) { if (i) o << ","; o << n.id[i]; }
    o << "],\"x\":" << js::arr(n.x) << ",\"y\":" << js::arr(n.y) << ",\"z\":" << js::arr(n.z) << ",\"T\":" << js::arr(n.T) << "}"; J(res, o.str()); });
  svr.Get(R"(/api/sample/([A-Za-z0-9_.]+))", [&](const httplib::Request& r, httplib::Response& res) {      // allow-list style: plain file names only
    std::string name = r.matches[1]; if (name.find("..") != std::string::npos) return J(res, js::err("invalid name"), 400);
    std::ifstream f(data + "/" + name, std::ios::binary); if (!f) return J(res, js::err("sample not found: " + name), 404);
    std::stringstream b; b << f.rdbuf(); res.set_content(b.str(), "text/plain"); });

  // ---- Task D (asynchronous jobs: UI thread never blocks; cancel supported) ----
  auto startJob = [&](const std::string& kind, BatchSpec spec, int workers, httplib::Response& res) {
    { std::lock_guard<std::mutex> l(job.m); if (job.state == "running") return J(res, js::err("A job is already running. Cancel it or wait."), 409); }
    job.join();
    { std::lock_guard<std::mutex> l(job.m); job.state = "running"; job.kind = kind; job.error.clear(); job.result = "{}"; }
    job.ctl.cancel = false; job.ctl.done = 0; job.total = kind == "bench" ? 0 : spec.cases;
    job.th = std::thread([&, kind, spec, workers] {
      std::string out, err, st = "done";
      try {
        if (kind == "bench") { BenchReport r = runBenchmark(spec, &job.ctl); if (r.cancelled) st = "cancelled"; out = benchJson(r); }
        else {
          auto cases = generateBatch(spec); std::vector<std::vector<double>> a, b; auto t0 = Clock::now();
          bool ok = workers <= 1 ? solveSerial(cases, a, &job.ctl) : solveParallel(cases, a, workers, &job.ctl);
          double dt = std::chrono::duration<double>(Clock::now() - t0).count();
          if (!ok) { st = "cancelled"; out = "{\"ok\":true,\"cancelled\":true}"; }
          else { double mx = -1e300; for (auto& v : a) for (double t : v) mx = std::fmax(mx, t);
            out = "{\"ok\":true,\"cancelled\":false,\"workers\":" + std::to_string(workers) + ",\"cases\":" + std::to_string(cases.size()) + ",\"seconds\":" + js::num(dt) + ",\"max_T_C\":" + js::num(mx) + "}"; }
        }
      } catch (const std::exception& ex) { st = "error"; err = ex.what(); }
      std::lock_guard<std::mutex> l(job.m); job.state = st; job.result = out; job.error = err; });
    J(res, "{\"ok\":true}");
  };
  auto specFrom = [&](const httplib::Request& r, BatchSpec& s, std::string& e) {
    long a, b, c; if (!parseI(param(r, "seed", "12345"), a) || a < 0) e += "seed must be a non-negative integer. ";
    if (!parseI(param(r, "cases", "2000"), b) || b < 1 || b > 200000) e += "cases must be 1..200000. ";
    if (!parseI(param(r, "elements", "20000"), c) || c < 1 || c > 200000) e += "elements must be 1..200000. ";
    if (e.empty()) { s.seed = (uint32_t)a; s.cases = (int)b; s.elements = (int)c; } };
  svr.Post("/api/batch/start", [&](const httplib::Request& r, httplib::Response& res) {
    BatchSpec s; std::string e; specFrom(r, s, e); long w; if (!parseI(param(r, "workers", "1"), w) || w < 1 || w > 64) e += "workers must be 1..64. ";
    if (!e.empty()) return J(res, js::err(e), 400); startJob("batch", s, (int)w, res); });
  svr.Post("/api/bench/start", [&](const httplib::Request& r, httplib::Response& res) {
    BatchSpec s; std::string e; specFrom(r, s, e); if (!e.empty()) return J(res, js::err(e), 400); startJob("bench", s, 0, res); });
  svr.Post("/api/job/cancel", [&](const httplib::Request&, httplib::Response& res) { job.ctl.cancel = true; J(res, "{\"ok\":true}"); });
  svr.Get("/api/job/status", [&](const httplib::Request&, httplib::Response& res) {
    std::lock_guard<std::mutex> l(job.m);
    J(res, "{\"ok\":true,\"state\":" + js::q(job.state) + ",\"kind\":" + js::q(job.kind) + ",\"done\":" + std::to_string(job.ctl.done.load()) + ",\"total\":" + std::to_string(job.total) + ",\"error\":" + js::q(job.error) + ",\"result\":" + job.result + "}"); });

  // ---- Task E (all SIMULATED) ----
  auto hw = [&](httplib::Response& res, const HwResult& h) { J(res, "{\"ok\":" + std::string(h.ok ? "true" : "false") + ",\"simulated\":true,\"code\":" + js::q(h.code) + ",\"message\":" + js::q(h.message) + "}", h.ok ? 200 : 422); };
  svr.Get("/api/hw/discover", [&](const httplib::Request&, httplib::Response& res) {
    std::lock_guard<std::mutex> l(dmMutex); std::string o = "{\"ok\":true,\"simulated\":true,\"devices\":[";
    bool first = true; for (auto& d : dm.discover()) { if (!first) o += ","; first = false;
      std::vector<Capability> caps; dm.capabilities(d.id, caps); std::string cs; for (auto& c : caps) { if (!cs.empty()) cs += ","; cs += "{\"name\":" + js::q(c.name) + ",\"value\":" + js::q(c.value) + "}"; }
      o += "{\"id\":" + js::q(d.id) + ",\"name\":" + js::q(d.name) + ",\"kind\":" + js::q(d.kind) + ",\"voltage\":" + js::q(d.voltage) + ",\"transport\":" + js::q(d.transport) + ",\"connected\":" + (d.connected ? "true" : "false") + ",\"capabilities\":[" + cs + "]}"; }
    J(res, o + "]}"); });
  svr.Post("/api/hw/connect", [&](const httplib::Request& r, httplib::Response& res) { std::lock_guard<std::mutex> l(dmMutex); hw(res, dm.connect(param(r, "id", ""), param(r, "inject_timeout", "0") == "1")); });
  svr.Post("/api/hw/disconnect", [&](const httplib::Request& r, httplib::Response& res) { std::lock_guard<std::mutex> l(dmMutex); hw(res, dm.disconnect(param(r, "id", ""))); });
  svr.Get("/api/hw/telemetry", [&](const httplib::Request& r, httplib::Response& res) {
    std::lock_guard<std::mutex> l(dmMutex); std::string j; HwResult h = dm.telemetry(param(r, "id", ""), j);
    if (!h.ok) return hw(res, h); J(res, "{\"ok\":true,\"simulated\":true,\"telemetry\":" + j + "}"); });

  // ---- Task F ----
  svr.Get("/api/backprop", [&](const httplib::Request&, httplib::Response& res) {
    BpParams p; double x = 1, y = 2, lr = 0.1; BpForward f = bpForward(p, x, y); BpGrad g = bpGrad(p, x, y), n = bpNumGrad(p, x, y, 1e-6); BpParams u = bpStep(p, g, lr);
    BpRun run = bpTrain(u, x, y, lr, 100);   
    std::vector<double> loss = {f.J, bpForward(u, x, y).J}; for (size_t i = 1; i < run.loss.size(); ++i) loss.push_back(run.loss[i]);
    double maxe = std::fmax(std::fmax(std::fabs(g.dw - n.dw), std::fabs(g.db - n.db)), std::fmax(std::fabs(g.dv - n.dv), std::fabs(g.dc - n.dc)));
    J(res, "{\"ok\":true,\"forward\":{\"z\":" + js::num(f.z) + ",\"h\":" + js::num(f.h) + ",\"yhat\":" + js::num(f.yhat) + ",\"J\":" + js::num(f.J) + "},\"grad\":{\"dw\":" + js::num(g.dw) + ",\"db\":" + js::num(g.db) + ",\"dv\":" + js::num(g.dv) + ",\"dc\":" + js::num(g.dc) + "},\"numgrad\":{\"dw\":" + js::num(n.dw) + ",\"db\":" + js::num(n.db) + ",\"dv\":" + js::num(n.dv) + ",\"dc\":" + js::num(n.dc) + "},\"max_grad_error\":" + js::num(maxe) + ",\"updated\":{\"w\":" + js::num(u.w) + ",\"b\":" + js::num(u.b) + ",\"v\":" + js::num(u.v) + ",\"c\":" + js::num(u.c) + "},\"loss\":" + js::arr(loss, 10) + "}"); });

  svr.set_mount_point("/", web);
  svr.set_error_handler([](const httplib::Request&, httplib::Response& res) { if (res.body.empty()) res.set_content("{\"ok\":false,\"error\":\"not found\"}", "application/json"); });
  // idle watchdog: exit ~25 s after the UI stops pinging (browser closed)
  std::thread([&] { for (;;) { std::this_thread::sleep_for(std::chrono::seconds(2)); if (everPinged && nowMs() - lastPing > 25000) { svr.stop(); return; } } }).detach();
  if (!svr.bind_to_port("127.0.0.1", port)) { std::cerr << "Cannot bind 127.0.0.1:" << port << "\n"; return 2; }
  launchMs = std::chrono::duration<double, std::milli>(Clock::now() - tStart).count();
  std::cout << "UnifiedWorkbench listening on http://127.0.0.1:" << port << " (ready in " << launchMs << " ms)" << std::endl;
  svr.listen_after_bind();
  job.ctl.cancel = true; job.join();
  return 0;
}

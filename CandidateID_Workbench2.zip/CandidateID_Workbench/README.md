# PASS Engineering Workbench

Unified engineering workbench written in **C++17** with **CMake**. The C++ program is a self-contained
local server (no third-party libraries) that serves a browser-based frontend and runs all engineering
computations natively.

| # | Feature | Where |
|---|---------|-------|
| 1 | Engineering dashboard (status cards, run-all) | Dashboard page |
| 2 | STL (ASCII/binary) and CSV 3D visualization (rotate, pan, zoom, fit, drag-and-drop) | `src/geometry.hpp`, Geometry page |
| 3 | 1D steady-state thermal FEM + exact solution + mesh convergence | `src/fem.hpp`, Thermal page |
| 4 | Serial vs multithreaded benchmark (speedup, efficiency, result match check) | `src/benchmark.hpp`, Performance page |
| 5 | STM32 / FPGA / JTAG simulation (real 16-state TAP FSM, IDCODE read, LUT filter) | `src/embedded.hpp`, Hardware page |
| 6 | Backpropagation neural network (XOR / AND / OR, configurable layers, lr, epochs) | `src/nn.hpp`, Neural Network page |

## Windows: install, build, run

Prerequisites (one time, in an admin PowerShell):

```powershell
winget install Kitware.CMake
winget install Microsoft.VisualStudio.2022.BuildTools --override "--quiet --add Microsoft.VisualStudio.Workload.VCTools --includeRecommended"
```

Open a **new** "Developer PowerShell for VS 2022" (or any terminal), then, inside the unzipped folder:

```powershell
scripts\build.bat      # configure + build (Release) + run all tests
scripts\run.bat        # starts the server and opens http://127.0.0.1:8080/
```

Manual equivalent:

```powershell
cmake -S . -B build
cmake --build build --config Release
ctest --test-dir build -C Release --output-on-failure
build\Release\workbench.exe
```

MinGW also works: `cmake -S . -B build -G "MinGW Makefiles" && cmake --build build`.

## Linux / macOS

```bash
./scripts/build.sh && ./build/workbench
```

## Command line options

`workbench [--port N] [--web DIR] [--data DIR] [--no-browser]`. If the port is busy a free one is chosen and printed.
The server listens on 127.0.0.1 only.

## Using it

* **Geometry** - *Load sample cube* / *Load sample points*, or choose/drag your own `.stl` (ASCII or binary) or `.csv` (`x,y,z[,value]`, header optional).
* **Thermal** - edit parameters, *Run simulation*. Table shows max midpoint error for N = 10/20/40/80.
* **Performance** - pick worker count, *Run benchmark*. Results are checked: serial and parallel peak temperatures must agree within 1e-8 degC.
* **Hardware** - runs sensor -> 12-bit ADC -> MCU filter -> FPGA alarm simulation and reads the device ID through the JTAG TAP.
* **Neural Network** - choose dataset, hidden layers (e.g. `4` or `6,4`), learning rate, epochs.

## Tests

`ctest` runs `wb_tests` (55 checks): JSON writer, FEM exactness and O(h^2) convergence, STL/CSV parsing and error paths,
serial/parallel equivalence, JTAG IDCODE and FPGA majority filter, backprop convergence and gradient check, API routing.

## Layout

```
src/   C++17 headers + main.cpp      web/   index.html, style.css, app.js
data/  sample_cube.stl, sample_points.csv   tests/  test_main.cpp
docs/  DESIGN.md   scripts/  build.bat, run.bat, build.sh
```

## Troubleshooting

* *`cmake` not found* - reopen the terminal after installing CMake.
* *Browser did not open* - go to the URL printed in the console.
* *Blank page / 404* - run from the build output folder (the build copies `web/` and `data/` next to `workbench.exe`) or pass `--web` and `--data`.
* *Windows Firewall prompt* - not needed; the server only binds to localhost, click Cancel.
* Benchmark speedup depends on physical cores; on a 1-core machine speedup is ~1.0.

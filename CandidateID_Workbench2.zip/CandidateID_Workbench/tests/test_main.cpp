// Dependency-free unit tests. Exit code 0 == all pass.
#include <cmath>
#include <cstring>
#include <fstream>
#include <iostream>
#include <sstream>
#include "api.hpp"

static int g_fail = 0, g_total = 0;
#define CHECK(cond) do { ++g_total; if (!(cond)) { ++g_fail; std::cerr << "FAIL " << __FILE__ << ":" << __LINE__ << "  " #cond "\n"; } } while (0)
#define NEAR(a, b, tol) CHECK(std::fabs((a) - (b)) <= (tol))

static std::string readFile(const std::string& p) { std::ifstream f(p, std::ios::binary); std::ostringstream s; s << f.rdbuf(); return s.str(); }

static void testJson() {
    wb::Json j; j.beginObj().kv("a", 1).kv("s", "x\"y").key("arr").beginArr().val(1).val(2.5).endArr().endObj();
    CHECK(j.str() == "{\"a\":1,\"s\":\"x\\\"y\",\"arr\":[1,2.5]}");
    CHECK(wb::jnum(NAN) == "null");
}

static void testFem() {
    wb::ThermalParams p;
    auto r = wb::solveThermal(p);
    NEAR(r.T.front(), 100.0, 1e-12); NEAR(r.T.back(), 20.0, 1e-12);
    CHECK(r.maxNodalError < 1e-8);                    // linear FE is nodally exact in 1D
    double prev = 1e9;
    for (int n : {10, 20, 40, 80}) {                  // midpoint error must fall ~4x per refinement
        p.N = n; double e = wb::solveThermal(p).maxMidpointError;
        CHECK(e < prev); prev = e;
    }
    p.N = 10; double e10 = wb::solveThermal(p).maxMidpointError;
    p.N = 20; double e20 = wb::solveThermal(p).maxMidpointError;
    NEAR(e10 / e20, 4.0, 0.05);
    wb::ThermalParams bad; bad.k = -1;
    bool threw = false; try { wb::solveThermal(bad); } catch (const std::invalid_argument&) { threw = true; }
    CHECK(threw);
    wb::ThermalParams one; one.N = 1;                  // single element edge case
    CHECK(wb::solveThermal(one).T.size() == 2);
    wb::ThermalParams zeroQ; zeroQ.q = 0; zeroQ.N = 8;  // pure conduction: linear profile
    auto lin = wb::solveThermal(zeroQ);
    NEAR(lin.T[4], 60.0, 1e-9);
}

static void testGeometry() {
    std::string cube = readFile(std::string(WB_DATA_DIR) + "/sample_cube.stl");
    CHECK(!cube.empty());
    auto m = wb::parseGeometry("sample_cube.stl", cube);
    CHECK(m.format == "ASCII STL");
    CHECK(m.triangleCount() == 1728);
    CHECK(m.vertexCount() == 13 * 13 * 13 - 11 * 11 * 11);  // shared vertices merged: 866
    NEAR(m.bmin[0], 0.0, 1e-6); NEAR(m.bmax[2], 1.0, 1e-6);

    // binary round trip: one triangle
    std::string bin(80, ' '); uint32_t cnt = 1; bin.append((char*)&cnt, 4);
    float tri[12] = {0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0};
    bin.append((char*)tri, 48); bin.append(2, '\0');
    auto b = wb::parseGeometry("t.stl", bin);
    CHECK(b.format == "Binary STL" && b.triangleCount() == 1 && b.vertexCount() == 3);

    auto c = wb::parseGeometry("p.csv", readFile(std::string(WB_DATA_DIR) + "/sample_points.csv"));
    CHECK(c.vertexCount() == 400 && c.values.size() == 400 && c.triangleCount() == 0);

    bool threw = false; try { wb::parseGeometry("x.stl", "garbage"); } catch (const std::exception&) { threw = true; }
    CHECK(threw);
    threw = false; try { wb::parseGeometry("x.csv", "a,b,c\n"); } catch (const std::exception&) { threw = true; }
    CHECK(threw);
    threw = false; try { wb::parseGeometry("x.stl", "solid x\nfacet normal 0 0 1\nvertex 1 2\nendsolid"); } catch (const std::exception&) { threw = true; }
    CHECK(threw);
}

static void testBenchmark() {
    auto r = wb::runBenchmark(3, 24, 2000);
    CHECK(r.rows.size() == 3);
    NEAR(r.rows[0].speedup, 1.0, 1e-12);
    CHECK(r.maxDiff <= 1e-8);                         // serial and parallel results agree
    for (auto& row : r.rows) CHECK(row.seconds > 0);
}

static void testJtagFpga() {
    wb::JtagDevice d;
    int cycles = 0;
    CHECK(d.readIdcode(&cycles) == 0x04A3u);
    CHECK(d.state() == wb::Tap::RunTestIdle);
    CHECK(cycles > 32);
    for (int i = 0; i < 5; ++i) d.clock(true, false);
    CHECK(d.state() == wb::Tap::TestLogicReset);     // 5x TMS=1 always resets
    wb::FpgaFilter f;
    CHECK(!f.step(true)); CHECK(f.step(true)); CHECK(f.step(false)); CHECK(!f.step(false));  // majority-of-3
    auto s = wb::simulateHardware(120, 60.0);
    CHECK(s.idcode == 0x04A3u); CHECK(s.alarmSamples > 0); CHECK(s.alarm.front() == 0);
}

static void testNeural() {
    wb::NnConfig c;
    auto r = wb::trainNetwork("xor", c);
    CHECK(r.loss.back() < r.loss.front());
    CHECK(r.finalLoss < 0.01);
    for (size_t i = 0; i < 4; ++i) CHECK(std::fabs(r.pred[i] - r.data.y[i]) < 0.15);
    // gradient check: analytic update direction must reduce loss; compare against finite differences
    wb::Dataset d = wb::makeDataset("xor");
    wb::Mlp net(2, {3}, 7);
    double l0 = net.lossOf(d);
    wb::Mlp ref = net;
    net.trainEpoch(d, 1e-3);
    // numeric gradient step of the same size
    double eps = 1e-6; double dotNum = 0, dotAna = 0;
    for (size_t l = 0; l < ref.weights().size(); ++l)
        for (size_t k = 0; k < ref.weights()[l].size(); ++k) {
            wb::Mlp a = ref, b = ref;
            a.weights()[l][k] += eps; b.weights()[l][k] -= eps;
            double g = (a.lossOf(d) - b.lossOf(d)) / (2 * eps);
            double step = (ref.weights()[l][k] - net.weights()[l][k]) / 1e-3 * 4.0 / 4.0;  // = analytic dL/dw * (1/N)*N
            dotNum += g * g; dotAna += g * step;
        }
    CHECK(dotAna > 0.5 * dotNum);                    // analytic and numeric gradients agree in direction/magnitude
    CHECK(net.lossOf(d) < l0);
    bool threw = false; try { wb::makeDataset("nope"); } catch (const std::invalid_argument&) { threw = true; }
    CHECK(threw);
}

static void testApi() {
    wb::Request r; r.path = "/api/thermal"; r.query["N"] = "20";
    auto res = wb::handleApi(r);
    CHECK(res.status == 200 && res.body.find("\"converged\":true") != std::string::npos);
    r.query["N"] = "abc";
    bool threw = false; try { wb::handleApi(r); } catch (const std::exception&) { threw = true; }
    CHECK(threw);
    wb::Request h; h.path = "/api/hardware"; CHECK(wb::handleApi(h).body.find("0x04A3") != std::string::npos);
    wb::Request n; n.path = "/api/neural"; n.query["epochs"] = "300";
    CHECK(wb::handleApi(n).body.find("\"rows\"") != std::string::npos);
    wb::Request u; u.path = "/api/nothing"; CHECK(wb::handleApi(u).status == 404);
}

int main() {
    testJson(); testFem(); testGeometry(); testBenchmark(); testJtagFpga(); testNeural(); testApi();
    std::cout << (g_total - g_fail) << "/" << g_total << " checks passed\n";
    return g_fail ? 1 : 0;
}

// STL (ASCII + binary) and CSV point-cloud parsing.
#pragma once
#include <algorithm>
#include <cctype>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <map>
#include <sstream>
#include <stdexcept>
#include <string>
#include <tuple>
#include <vector>
#include "json.hpp"

namespace wb {

struct Mesh {
    std::string format;               // "ASCII STL", "Binary STL", "CSV points"
    std::vector<float> positions;     // x,y,z per unique vertex
    std::vector<float> values;        // optional per-vertex scalar (CSV 4th column)
    std::vector<uint32_t> indices;    // 3 per triangle (empty for point clouds)
    float bmin[3] = {0, 0, 0}, bmax[3] = {0, 0, 0};
    size_t vertexCount() const { return positions.size() / 3; }
    size_t triangleCount() const { return indices.size() / 3; }
};

namespace detail {
struct VertexKey {
    long long x, y, z;
    bool operator<(const VertexKey& o) const { return std::tie(x, y, z) < std::tie(o.x, o.y, o.z); }
};
inline uint32_t addVertex(Mesh& m, std::map<VertexKey, uint32_t>& cache, float x, float y, float z) {
    VertexKey k{std::llround(x * 1e5), std::llround(y * 1e5), std::llround(z * 1e5)};
    auto it = cache.find(k);
    if (it != cache.end()) return it->second;
    uint32_t id = static_cast<uint32_t>(m.positions.size() / 3);
    m.positions.insert(m.positions.end(), {x, y, z});
    cache.emplace(k, id);
    return id;
}
inline void computeBounds(Mesh& m) {
    if (m.positions.empty()) return;
    for (int a = 0; a < 3; ++a) m.bmin[a] = m.bmax[a] = m.positions[a];
    for (size_t i = 0; i < m.positions.size(); i += 3)
        for (int a = 0; a < 3; ++a) {
            m.bmin[a] = std::min(m.bmin[a], m.positions[i + a]);
            m.bmax[a] = std::max(m.bmax[a], m.positions[i + a]);
        }
}
}  // namespace detail

inline bool looksAscii(const std::string& d) {
    size_t i = 0;
    while (i < d.size() && std::isspace(static_cast<unsigned char>(d[i]))) ++i;
    if (d.compare(i, 5, "solid") != 0) return false;
    return d.find("facet", i) != std::string::npos && d.find("vertex", i) != std::string::npos;
}

inline Mesh parseAsciiStl(const std::string& data) {
    Mesh m; m.format = "ASCII STL";
    std::map<detail::VertexKey, uint32_t> cache;
    std::istringstream in(data);
    std::string tok;
    uint32_t tri[3]; int n = 0;
    while (in >> tok) {
        if (tok == "vertex") {
            float x, y, z;
            if (!(in >> x >> y >> z)) throw std::runtime_error("Malformed vertex in ASCII STL");
            tri[n++] = detail::addVertex(m, cache, x, y, z);
            if (n == 3) { m.indices.insert(m.indices.end(), {tri[0], tri[1], tri[2]}); n = 0; }
        }
    }
    if (n != 0) throw std::runtime_error("Facet with fewer than 3 vertices");
    if (m.indices.empty()) throw std::runtime_error("No triangles found in STL");
    detail::computeBounds(m);
    return m;
}

inline Mesh parseBinaryStl(const std::string& d) {
    if (d.size() < 84) throw std::runtime_error("Not a valid STL file (too short)");
    uint32_t count; std::memcpy(&count, d.data() + 80, 4);
    if (d.size() < 84 + static_cast<size_t>(count) * 50) throw std::runtime_error("Binary STL truncated");
    Mesh m; m.format = "Binary STL";
    std::map<detail::VertexKey, uint32_t> cache;
    for (uint32_t t = 0; t < count; ++t) {
        const char* p = d.data() + 84 + static_cast<size_t>(t) * 50 + 12;
        uint32_t id[3];
        for (int v = 0; v < 3; ++v) {
            float xyz[3]; std::memcpy(xyz, p + v * 12, 12);
            id[v] = detail::addVertex(m, cache, xyz[0], xyz[1], xyz[2]);
        }
        m.indices.insert(m.indices.end(), {id[0], id[1], id[2]});
    }
    if (m.indices.empty()) throw std::runtime_error("No triangles found in STL");
    detail::computeBounds(m);
    return m;
}

// CSV: x,y,z[,value]; optional header row; separators , ; or whitespace.
inline Mesh parseCsv(const std::string& data) {
    Mesh m; m.format = "CSV points";
    std::istringstream in(data);
    std::string line;
    bool hasValue = false;
    while (std::getline(in, line)) {
        for (char& c : line) if (c == ',' || c == ';' || c == '\t' || c == '\r') c = ' ';
        std::istringstream ls(line);
        std::vector<double> v; std::string t;
        bool ok = true;
        while (ls >> t) {
            char* end = nullptr; double x = std::strtod(t.c_str(), &end);
            if (end == t.c_str() || *end) { ok = false; break; }
            v.push_back(x);
        }
        if (!ok || v.size() < 3) continue;  // header / blank / bad row
        m.positions.insert(m.positions.end(), {(float)v[0], (float)v[1], (float)v[2]});
        if (v.size() >= 4) { hasValue = true; m.values.push_back((float)v[3]); }
        else m.values.push_back(0.f);
    }
    if (m.positions.empty()) throw std::runtime_error("No numeric x,y,z rows found in CSV");
    if (!hasValue) m.values.clear();
    detail::computeBounds(m);
    return m;
}

inline Mesh parseGeometry(const std::string& name, const std::string& data) {
    std::string lower = name;
    std::transform(lower.begin(), lower.end(), lower.begin(), [](unsigned char c) { return (char)std::tolower(c); });
    bool csv = lower.size() > 4 && lower.compare(lower.size() - 4, 4, ".csv") == 0;
    if (csv) return parseCsv(data);
    return looksAscii(data) ? parseAsciiStl(data) : parseBinaryStl(data);
}

inline std::string meshToJson(const Mesh& m, const std::string& name, size_t fileBytes) {
    Json j; j.beginObj();
    j.kv("ok", true).kv("name", name).kv("format", m.format).kv("units", "meters (m)");
    j.kv("vertices", m.vertexCount()).kv("triangles", m.triangleCount()).kv("fileSize", fileBytes);
    j.key("bboxMin").beginArr().val((double)m.bmin[0]).val((double)m.bmin[1]).val((double)m.bmin[2]).endArr();
    j.key("bboxMax").beginArr().val((double)m.bmax[0]).val((double)m.bmax[1]).val((double)m.bmax[2]).endArr();
    j.key("positions").beginArr(); for (float f : m.positions) j.val((double)f); j.endArr();
    j.key("indices").beginArr(); for (uint32_t i : m.indices) j.val((long long)i); j.endArr();
    j.key("values").beginArr(); for (float f : m.values) j.val((double)f); j.endArr();
    j.endObj();
    return j.str();
}

}  // namespace wb

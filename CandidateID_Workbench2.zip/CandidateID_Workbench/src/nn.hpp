// Fully-connected neural network trained with backpropagation (batch gradient descent).
#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <stdexcept>
#include <string>
#include <vector>
#include "json.hpp"

namespace wb {

struct Dataset { std::string name; std::vector<std::vector<double>> x; std::vector<double> y; };

inline Dataset makeDataset(const std::string& name) {
    Dataset d; d.name = name;
    d.x = {{0, 0}, {0, 1}, {1, 0}, {1, 1}};
    if (name == "xor") d.y = {0, 1, 1, 0};
    else if (name == "and") d.y = {0, 0, 0, 1};
    else if (name == "or") d.y = {0, 1, 1, 1};
    else throw std::invalid_argument("Unknown dataset: " + name);
    return d;
}

struct NnConfig {
    std::vector<int> hidden = {4};
    double lr = 2.0;
    int epochs = 2000;
    uint32_t seed = 42;
};

class Mlp {
public:
    Mlp(int in, const std::vector<int>& hidden, uint32_t seed) {
        sizes_.push_back(in);
        for (int h : hidden) { if (h < 1 || h > 256) throw std::invalid_argument("hidden size must be 1..256"); sizes_.push_back(h); }
        sizes_.push_back(1);
        uint32_t s = seed;
        auto rnd = [&]() { s = s * 1664525u + 1013904223u; return ((s >> 8) & 0xFFFFFF) / 16777215.0; };
        for (size_t l = 1; l < sizes_.size(); ++l) {
            double lim = std::sqrt(6.0 / (sizes_[l - 1] + sizes_[l]));  // Xavier uniform
            W_.emplace_back(sizes_[l] * sizes_[l - 1]);
            for (double& w : W_.back()) w = (2 * rnd() - 1) * lim;
            b_.emplace_back(sizes_[l], 0.0);
        }
    }
    static double sig(double z) { return 1.0 / (1.0 + std::exp(-z)); }

    // forward pass returning activations of every layer
    std::vector<std::vector<double>> forward(const std::vector<double>& x) const {
        std::vector<std::vector<double>> a{x};
        for (size_t l = 0; l < W_.size(); ++l) {
            std::vector<double> o(sizes_[l + 1]);
            for (int j = 0; j < sizes_[l + 1]; ++j) {
                double z = b_[l][j];
                for (int i = 0; i < sizes_[l]; ++i) z += W_[l][j * sizes_[l] + i] * a[l][i];
                o[j] = sig(z);
            }
            a.push_back(std::move(o));
        }
        return a;
    }
    double predict(const std::vector<double>& x) const { return forward(x).back()[0]; }

    // One epoch of full-batch gradient descent; returns MSE loss before the update.
    double trainEpoch(const Dataset& d, double lr) {
        std::vector<std::vector<double>> gW(W_.size()), gB(W_.size());
        for (size_t l = 0; l < W_.size(); ++l) { gW[l].assign(W_[l].size(), 0.0); gB[l].assign(b_[l].size(), 0.0); }
        double loss = 0.0;
        for (size_t n = 0; n < d.x.size(); ++n) {
            auto a = forward(d.x[n]);
            double err = a.back()[0] - d.y[n];
            loss += err * err;
            std::vector<double> delta{err * a.back()[0] * (1 - a.back()[0])};  // dL/dz at output
            for (int l = (int)W_.size() - 1; l >= 0; --l) {
                for (int j = 0; j < sizes_[l + 1]; ++j) {
                    gB[l][j] += delta[j];
                    for (int i = 0; i < sizes_[l]; ++i) gW[l][j * sizes_[l] + i] += delta[j] * a[l][i];
                }
                if (l > 0) {
                    std::vector<double> nd(sizes_[l], 0.0);
                    for (int i = 0; i < sizes_[l]; ++i) {
                        double s = 0;
                        for (int j = 0; j < sizes_[l + 1]; ++j) s += W_[l][j * sizes_[l] + i] * delta[j];
                        nd[i] = s * a[l][i] * (1 - a[l][i]);
                    }
                    delta = std::move(nd);
                }
            }
        }
        const double scale = lr / d.x.size();
        for (size_t l = 0; l < W_.size(); ++l) {
            for (size_t k = 0; k < W_[l].size(); ++k) W_[l][k] -= scale * gW[l][k];
            for (size_t k = 0; k < b_[l].size(); ++k) b_[l][k] -= scale * gB[l][k];
        }
        return loss / d.x.size();
    }
    // Finite-difference check helper (used by tests).
    double lossOf(const Dataset& d) const {
        double s = 0; for (size_t n = 0; n < d.x.size(); ++n) { double e = predict(d.x[n]) - d.y[n]; s += e * e; }
        return s / d.x.size();
    }
    std::vector<std::vector<double>>& weights() { return W_; }
    const std::vector<std::vector<double>>& weights() const { return W_; }
private:
    std::vector<int> sizes_;
    std::vector<std::vector<double>> W_, b_;
};

struct NnResult { std::vector<double> loss; std::vector<double> pred; double finalLoss = 0; Dataset data; };

inline NnResult trainNetwork(const std::string& dataset, const NnConfig& c) {
    if (c.epochs < 1 || c.epochs > 200000) throw std::invalid_argument("epochs must be 1..200000");
    if (!(c.lr > 0) || c.lr > 100) throw std::invalid_argument("learning rate must be in (0, 100]");
    NnResult r; r.data = makeDataset(dataset);
    Mlp net(2, c.hidden, c.seed);
    for (int e = 0; e < c.epochs; ++e) r.loss.push_back(net.trainEpoch(r.data, c.lr));
    for (auto& x : r.data.x) r.pred.push_back(net.predict(x));
    r.finalLoss = net.lossOf(r.data);
    return r;
}

inline std::string nnToJson(const NnResult& r) {
    Json j; j.beginObj().kv("ok", true).kv("dataset", r.data.name);
    // down-sample loss curve to at most ~500 points (always keep the last)
    size_t step = std::max<size_t>(1, r.loss.size() / 500);
    j.key("epochs").beginArr(); for (size_t i = 0; i < r.loss.size(); i += step) j.val(i + 1); j.endArr();
    j.key("loss").beginArr(); for (size_t i = 0; i < r.loss.size(); i += step) j.val(r.loss[i]); j.endArr();
    j.kv("finalLoss", r.finalLoss);
    j.key("rows").beginArr();
    bool ok = true;
    for (size_t i = 0; i < r.data.x.size(); ++i) {
        j.beginObj().kv("in1", r.data.x[i][0]).kv("in2", r.data.x[i][1]).kv("target", r.data.y[i]).kv("predicted", r.pred[i]).endObj();
        if (std::fabs(r.pred[i] - r.data.y[i]) >= 0.5) ok = false;
    }
    j.endArr().kv("allCorrect", ok).endObj();
    return j.str();
}

}  // namespace wb

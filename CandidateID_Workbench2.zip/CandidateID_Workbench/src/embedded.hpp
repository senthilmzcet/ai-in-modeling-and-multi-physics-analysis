// Microcontroller + FPGA + JTAG simulation.
#pragma once
#include <cmath>
#include <cstdint>
#include <string>
#include <vector>
#include "json.hpp"

namespace wb {

// ---- JTAG TAP controller (IEEE 1149.1), 16-state FSM ----
enum class Tap { TestLogicReset, RunTestIdle, SelectDR, CaptureDR, ShiftDR, Exit1DR, PauseDR, Exit2DR, UpdateDR,
                 SelectIR, CaptureIR, ShiftIR, Exit1IR, PauseIR, Exit2IR, UpdateIR };

inline Tap tapNext(Tap s, bool tms) {
    switch (s) {
        case Tap::TestLogicReset: return tms ? Tap::TestLogicReset : Tap::RunTestIdle;
        case Tap::RunTestIdle:    return tms ? Tap::SelectDR : Tap::RunTestIdle;
        case Tap::SelectDR:       return tms ? Tap::SelectIR : Tap::CaptureDR;
        case Tap::CaptureDR:      return tms ? Tap::Exit1DR : Tap::ShiftDR;
        case Tap::ShiftDR:        return tms ? Tap::Exit1DR : Tap::ShiftDR;
        case Tap::Exit1DR:        return tms ? Tap::UpdateDR : Tap::PauseDR;
        case Tap::PauseDR:        return tms ? Tap::Exit2DR : Tap::PauseDR;
        case Tap::Exit2DR:        return tms ? Tap::UpdateDR : Tap::ShiftDR;
        case Tap::UpdateDR:       return tms ? Tap::SelectDR : Tap::RunTestIdle;
        case Tap::SelectIR:       return tms ? Tap::TestLogicReset : Tap::CaptureIR;
        case Tap::CaptureIR:      return tms ? Tap::Exit1IR : Tap::ShiftIR;
        case Tap::ShiftIR:        return tms ? Tap::Exit1IR : Tap::ShiftIR;
        case Tap::Exit1IR:        return tms ? Tap::UpdateIR : Tap::PauseIR;
        case Tap::PauseIR:        return tms ? Tap::Exit2IR : Tap::PauseIR;
        case Tap::Exit2IR:        return tms ? Tap::UpdateIR : Tap::ShiftIR;
        case Tap::UpdateIR:       return tms ? Tap::SelectDR : Tap::RunTestIdle;
    }
    return Tap::TestLogicReset;
}

class JtagDevice {
public:
    static constexpr uint32_t kDefaultId = 0x04A3u;  // simulated device ID
    explicit JtagDevice(uint32_t idcode = kDefaultId) : id_(idcode) {}
    Tap state() const { return state_; }
    uint32_t instruction() const { return ir_; }

    // One TCK cycle. Returns TDO.
    bool clock(bool tms, bool tdi) {
        bool tdo = false;
        ++cycles_;
        if (state_ == Tap::ShiftDR) { tdo = dr_ & 1u; dr_ = (dr_ >> 1) | ((uint32_t)tdi << (drLen_ - 1)); }
        else if (state_ == Tap::ShiftIR) { tdo = shiftIr_ & 1u; shiftIr_ = (shiftIr_ >> 1) | ((uint32_t)tdi << 3); }
        Tap next = tapNext(state_, tms);
        switch (next) {
            case Tap::TestLogicReset: ir_ = kIdcode; break;
            case Tap::CaptureIR: shiftIr_ = 0x1; break;  // mandated pattern ...01
            case Tap::UpdateIR: ir_ = shiftIr_ & 0xF; break;
            case Tap::CaptureDR:
                if (ir_ == kIdcode) { dr_ = id_; drLen_ = 32; }
                else { dr_ = 0; drLen_ = 1; }  // BYPASS
                break;
            default: break;
        }
        state_ = next;
        return tdo;
    }
    void reset() { for (int i = 0; i < 5; ++i) clock(true, false); }

    // Reads IDCODE through the real TAP sequence.
    uint32_t readIdcode(int* cycles = nullptr) {
        int c0 = cycles_;
        reset();
        clock(false, false);            // Run-Test/Idle
        clock(true, false);             // Select-DR
        clock(false, false);            // Capture-DR (IDCODE selected after reset)
        clock(false, false);            // enter Shift-DR
        uint32_t v = 0;
        // Shift-DR: first shift clock happens leaving Capture-DR
        for (int i = 0; i < 32; ++i) v |= (uint32_t)clock(i == 31, false) << i;
        clock(true, false);             // Update-DR
        clock(false, false);            // Run-Test/Idle
        if (cycles) *cycles = cycles_ - c0;
        return v;
    }
private:
    static constexpr uint32_t kIdcode = 0x1;
    uint32_t id_, dr_ = 0, ir_ = kIdcode, shiftIr_ = 0;
    int drLen_ = 32, cycles_ = 0;
    Tap state_ = Tap::TestLogicReset;
public:
    int cycleCount() const { return cycles_; }
};

// ---- FPGA logic: 4-input LUT network implementing alarm = (T > thr) with 3-sample majority filter ----
struct Lut4 {
    uint16_t table = 0;
    bool eval(bool a, bool b, bool c, bool d) const { return (table >> (a | (b << 1) | (c << 2) | (d << 3))) & 1u; }
};

struct FpgaFilter {
    Lut4 majority3;  // inputs a,b,c = last three comparator outputs (d unused)
    bool h[3] = {false, false, false};
    FpgaFilter() { for (int i = 0; i < 16; ++i) { int a = i & 1, b = (i >> 1) & 1, c = (i >> 2) & 1; if (a + b + c >= 2) majority3.table |= (1u << i); } }
    bool step(bool over) { h[2] = h[1]; h[1] = h[0]; h[0] = over; return majority3.eval(h[0], h[1], h[2], false); }
};

struct HwSim {
    std::vector<double> t, sensor, adcCounts, filtered;
    std::vector<int> over, alarm;
    uint32_t idcode = 0; int jtagCycles = 0;
    int adcBits = 12;
    double vref = 3.3, thresholdC = 60.0;
    int alarmSamples = 0;
};

inline HwSim simulateHardware(int samples = 120, double threshold = 60.0) {
    HwSim s; s.thresholdC = threshold;
    FpgaFilter fpga;
    double lp = 25.0; uint32_t rng = 12345u;
    const int maxCount = (1 << s.adcBits) - 1;
    for (int i = 0; i < samples; ++i) {
        double ti = i * 0.5;  // seconds
        rng = rng * 1664525u + 1013904223u;
        double noise = ((rng >> 8) & 0xFFFF) / 65535.0 - 0.5;
        // ramp up with a heating event between 20 s and 40 s
        double truth = 25.0 + (ti > 20 ? 45.0 * (1 - std::exp(-(ti - 20) / 6.0)) : 0.0) - (ti > 40 ? 45.0 * (1 - std::exp(-(ti - 40) / 6.0)) : 0.0);
        double reading = truth + 2.0 * noise;
        // Sensor: 10 mV/degC (LM35 style) -> 12-bit ADC at 3.3 V
        double volts = std::min(s.vref, std::max(0.0, reading * 0.010 + 0.0));
        int counts = (int)std::lround(volts / s.vref * maxCount);
        // MCU: convert counts to temperature, exponential moving average (alpha = 0.5)
        double tc = counts * s.vref / maxCount / 0.010;
        lp = 0.5 * tc + 0.5 * lp;
        bool o = lp > threshold;
        bool a = fpga.step(o);
        s.t.push_back(ti); s.sensor.push_back(reading); s.adcCounts.push_back(counts);
        s.filtered.push_back(lp); s.over.push_back(o); s.alarm.push_back(a);
        s.alarmSamples += a;
    }
    JtagDevice dev; s.idcode = dev.readIdcode(); s.jtagCycles = dev.cycleCount();
    return s;
}

inline std::string hwToJson(const HwSim& s) {
    Json j; j.beginObj().kv("ok", true);
    j.key("mcu").beginObj().kv("cpu", "ARM Cortex-M4").kv("clockMHz", 120).kv("flashKB", 512).kv("ramKB", 128)
        .kv("adcBits", s.adcBits).kv("vref", s.vref).endObj();
    j.key("fpga").beginObj().kv("device", "Xilinx Artix-7 (simulated)").kv("logicElements", 12000).kv("ramBlocks", 50)
        .kv("design", "4-input LUT majority-of-3 alarm filter").endObj();
    char id[16]; std::snprintf(id, sizeof id, "0x%04X", s.idcode);
    j.key("jtag").beginObj().kv("connected", s.idcode == JtagDevice::kDefaultId).kv("deviceId", std::string(id))
        .kv("status", "Ready").kv("tckCycles", s.jtagCycles).endObj();
    j.kv("threshold", s.thresholdC).kv("alarmSamples", s.alarmSamples);
    j.key("t").arr(s.t).key("sensor").arr(s.sensor).key("adc").arr(s.adcCounts).key("filtered").arr(s.filtered);
    j.key("alarm").arr(s.alarm);
    j.endObj();
    return j.str();
}

}  // namespace wb

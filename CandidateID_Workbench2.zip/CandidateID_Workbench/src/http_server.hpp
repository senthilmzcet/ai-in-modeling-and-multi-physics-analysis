// Tiny blocking HTTP/1.1 server (localhost only). Windows (Winsock) and POSIX.
#pragma once
#include <atomic>
#include <cstring>
#include <fstream>
#include <functional>
#include <map>
#include <sstream>
#include <string>
#include <thread>

#ifdef _WIN32
  #define WIN32_LEAN_AND_MEAN
  #ifndef NOMINMAX
  #define NOMINMAX
  #endif
  #include <winsock2.h>
  #include <ws2tcpip.h>
  using sock_t = SOCKET;
  static const sock_t kBadSock = INVALID_SOCKET;
  inline void closeSock(sock_t s) { closesocket(s); }
#else
  #include <arpa/inet.h>
  #include <netinet/in.h>
  #include <sys/socket.h>
  #include <unistd.h>
  using sock_t = int;
  static const sock_t kBadSock = -1;
  inline void closeSock(sock_t s) { close(s); }
#endif

namespace wb {

struct Request {
    std::string method, path, body;
    std::map<std::string, std::string> query;
    std::string param(const std::string& k, const std::string& def = "") const {
        auto it = query.find(k); return it == query.end() ? def : it->second;
    }
};
struct Response { int status = 200; std::string type = "application/json"; std::string body; };

inline std::string urlDecode(const std::string& s) {
    std::string o;
    for (size_t i = 0; i < s.size(); ++i) {
        if (s[i] == '%' && i + 2 < s.size()) { o += (char)std::strtol(s.substr(i + 1, 2).c_str(), nullptr, 16); i += 2; }
        else if (s[i] == '+') o += ' ';
        else o += s[i];
    }
    return o;
}

inline void parseQuery(const std::string& qs, std::map<std::string, std::string>& out) {
    size_t i = 0;
    while (i < qs.size()) {
        size_t amp = qs.find('&', i); if (amp == std::string::npos) amp = qs.size();
        std::string kv = qs.substr(i, amp - i); size_t eq = kv.find('=');
        if (eq == std::string::npos) out[urlDecode(kv)] = "";
        else out[urlDecode(kv.substr(0, eq))] = urlDecode(kv.substr(eq + 1));
        i = amp + 1;
    }
}

inline const char* statusText(int c) {
    switch (c) { case 200: return "OK"; case 400: return "Bad Request"; case 404: return "Not Found";
                 case 413: return "Payload Too Large"; default: return "Internal Server Error"; }
}

inline std::string mimeFor(const std::string& p) {
    auto ends = [&](const char* e) { size_t n = std::strlen(e); return p.size() >= n && p.compare(p.size() - n, n, e) == 0; };
    if (ends(".html")) return "text/html; charset=utf-8";
    if (ends(".css")) return "text/css; charset=utf-8";
    if (ends(".js")) return "application/javascript; charset=utf-8";
    if (ends(".json")) return "application/json";
    if (ends(".svg")) return "image/svg+xml";
    if (ends(".stl") || ends(".csv")) return "text/plain; charset=utf-8";
    return "application/octet-stream";
}

class HttpServer {
public:
    using Handler = std::function<Response(const Request&)>;
    static constexpr size_t kMaxBody = 64u * 1024 * 1024;

    HttpServer(std::string webRoot, Handler api) : root_(std::move(webRoot)), api_(std::move(api)) {}
    ~HttpServer() { stop(); }

    // Binds 127.0.0.1:port (0 = pick free port). Returns actual port or -1.
    int start(int port) {
#ifdef _WIN32
        WSADATA w; if (WSAStartup(MAKEWORD(2, 2), &w) != 0) return -1;
#endif
        listen_ = socket(AF_INET, SOCK_STREAM, 0);
        if (listen_ == kBadSock) return -1;
        int yes = 1;
#ifdef _WIN32
        setsockopt(listen_, SOL_SOCKET, SO_REUSEADDR, (const char*)&yes, sizeof yes);
#else
        setsockopt(listen_, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof yes);
#endif
        sockaddr_in a{}; a.sin_family = AF_INET; a.sin_port = htons((unsigned short)port);
        inet_pton(AF_INET, "127.0.0.1", &a.sin_addr);
        if (bind(listen_, (sockaddr*)&a, sizeof a) != 0 || listen(listen_, 16) != 0) { closeSock(listen_); listen_ = kBadSock; return -1; }
        socklen_t len = sizeof a; getsockname(listen_, (sockaddr*)&a, &len);
        port_ = ntohs(a.sin_port);
        running_ = true;
        thread_ = std::thread([this] { loop(); });
        return port_;
    }
    void stop() {
        if (!running_.exchange(false)) return;
        sock_t s = listen_; listen_ = kBadSock;
        if (s != kBadSock) {
#ifndef _WIN32
            shutdown(s, SHUT_RDWR);
#endif
            closeSock(s);
        }
        if (thread_.joinable()) thread_.join();
    }
    void wait() { if (thread_.joinable()) thread_.join(); }
    int port() const { return port_; }

private:
    void loop() {
        while (running_) {
            sock_t c = accept(listen_, nullptr, nullptr);
            if (c == kBadSock) { if (!running_) break; continue; }
            std::thread([this, c] { serve(c); }).detach();
        }
    }
    static bool readSome(sock_t c, std::string& buf) {
        char tmp[65536];
        int n = recv(c, tmp, sizeof tmp, 0);
        if (n <= 0) return false;
        buf.append(tmp, (size_t)n); return true;
    }
    void serve(sock_t c) {
        std::string buf; size_t hdrEnd = std::string::npos;
        while ((hdrEnd = buf.find("\r\n\r\n")) == std::string::npos) {
            if (buf.size() > 65536 || !readSome(c, buf)) { closeSock(c); return; }
        }
        std::istringstream hs(buf.substr(0, hdrEnd));
        Request req; std::string target, ver, line; hs >> req.method >> target >> ver;
        size_t contentLen = 0;
        while (std::getline(hs, line)) {
            if (!line.empty() && line.back() == '\r') line.pop_back();
            size_t col = line.find(':');
            if (col == std::string::npos) continue;
            std::string k = line.substr(0, col), v = line.substr(col + 1);
            for (auto& ch : k) ch = (char)std::tolower((unsigned char)ch);
            if (k == "content-length") contentLen = (size_t)std::strtoull(v.c_str(), nullptr, 10);
        }
        Response res;
        if (contentLen > kMaxBody) { res = err(413, "Request body too large (max 64 MB)"); }
        else {
            while (buf.size() < hdrEnd + 4 + contentLen) if (!readSome(c, buf)) { closeSock(c); return; }
            req.body = buf.substr(hdrEnd + 4, contentLen);
            size_t q = target.find('?');
            req.path = urlDecode(target.substr(0, q));
            if (q != std::string::npos) parseQuery(target.substr(q + 1), req.query);
            try { res = route(req); }
            catch (const std::exception& e) { res = err(400, e.what()); }
            catch (...) { res = err(500, "Unexpected error"); }
        }
        std::ostringstream o;
        o << "HTTP/1.1 " << res.status << ' ' << statusText(res.status) << "\r\nContent-Type: " << res.type
          << "\r\nContent-Length: " << res.body.size() << "\r\nCache-Control: no-store\r\nConnection: close\r\n\r\n";
        std::string head = o.str();
        sendAll(c, head.data(), head.size()); sendAll(c, res.body.data(), res.body.size());
        closeSock(c);
    }
    static void sendAll(sock_t c, const char* d, size_t n) {
        size_t off = 0;
        while (off < n) { int k = send(c, d + off, (int)(n - off), 0); if (k <= 0) return; off += (size_t)k; }
    }
    static Response err(int code, const std::string& msg) {
        Response r; r.status = code; r.body = "{\"ok\":false,\"error\":\"" + [&] {
            std::string o; for (char ch : msg) { if (ch == '"' || ch == '\\') o += '\\'; if (ch == '\n') o += ' '; else o += ch; } return o; }() + "\"}";
        return r;
    }
    Response route(const Request& req) {
        if (req.path.rfind("/api/", 0) == 0) return api_(req);
        std::string p = req.path == "/" ? "/index.html" : req.path;
        if (p.find("..") != std::string::npos || p.find('\\') != std::string::npos) return err(400, "Bad path");
        std::ifstream f(root_ + p, std::ios::binary);
        if (!f) return err(404, "Not found: " + p);
        std::ostringstream ss; ss << f.rdbuf();
        Response r; r.type = mimeFor(p); r.body = ss.str(); return r;
    }

    std::string root_; Handler api_;
    sock_t listen_ = kBadSock; int port_ = 0;
    std::atomic<bool> running_{false}; std::thread thread_;
};

}  // namespace wb

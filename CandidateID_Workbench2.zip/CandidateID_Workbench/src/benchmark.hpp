// Serial vs multithreaded benchmark: many independent 1D thermal FEM solves.
#pragma once
#include <algorithm>
#include <chrono>
#include <functional>
#include <thread>
#include <vector>
#include "fem.hpp"

namespace wb {

struct BenchRow { int workers; double seconds, speedup, efficiency; };
struct BenchResult {
    unsigned logicalCores = 1;
    std::vector<BenchRow> rows;
    double maxDiff = 0.0;
    int jobs = 0, elements = 0;
};

inline ThermalParams jobParams(int job, int elements) {
    ThermalParams p;
    p.N = elements;
    p.q = 5000.0 + 37.0 * job;
    p.k = 5.0 + (job % 17);
    p.T0 = 80.0 + (job % 7);
    p.TL = 15.0 + (job % 5);
    return p;
}

// Runs jobs first, first+stride, ...; stores each job's peak temperature.
inline void runJobs(int first, int stride, int jobs, int elements, std::vector<double>& out) {
    std::vector<double> T, cp, dp;
    for (int j = first; j < jobs; j += stride) {
        solveThermalInto(jobParams(j, elements), T, cp, dp);
        out[j] = *std::max_element(T.begin(), T.end());
    }
}

inline double timedRun(int workers, int jobs, int elements, std::vector<double>& out) {
    out.assign(jobs, 0.0);
    auto t0 = std::chrono::steady_clock::now();
    if (workers <= 1) runJobs(0, 1, jobs, elements, out);
    else {
        std::vector<std::thread> th;
        for (int w = 0; w < workers; ++w) th.emplace_back(runJobs, w, workers, jobs, elements, std::ref(out));
        for (auto& t : th) t.join();
    }
    return std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
}

inline BenchResult runBenchmark(int maxWorkers, int jobs, int elements) {
    BenchResult r; r.logicalCores = std::max(1u, std::thread::hardware_concurrency());
    r.jobs = jobs; r.elements = elements;
    std::vector<double> serial, par;
    double t1 = 0;
    for (int w = 1; w <= maxWorkers; ++w) {
        double best = 1e300;
        for (int rep = 0; rep < 2; ++rep)   // best of two to reduce noise
            best = std::min(best, timedRun(w, jobs, elements, w == 1 ? serial : par));
        if (w == 1) t1 = best;
        else for (int j = 0; j < jobs; ++j) r.maxDiff = std::max(r.maxDiff, std::fabs(serial[j] - par[j]));
        r.rows.push_back({w, best, t1 / best, t1 / best / w});
    }
    return r;
}

inline std::string benchToJson(const BenchResult& r) {
    Json j; j.beginObj();
    j.kv("ok", true).kv("logicalCores", (int)r.logicalCores).kv("jobs", r.jobs).kv("elements", r.elements);
#if defined(__clang__)
    j.kv("compiler", std::string("Clang ") + __clang_version__);
#elif defined(__GNUC__)
    j.kv("compiler", std::string("GCC ") + std::to_string(__GNUC__) + "." + std::to_string(__GNUC_MINOR__) + "." + std::to_string(__GNUC_PATCHLEVEL__));
#elif defined(_MSC_VER)
    j.kv("compiler", std::string("MSVC ") + std::to_string(_MSC_VER));
#else
    j.kv("compiler", "unknown");
#endif
#ifdef NDEBUG
    j.kv("optimisation", "Release (optimised)");
#else
    j.kv("optimisation", "Debug (unoptimised)");
#endif
    j.kv("maxDiff", r.maxDiff).kv("match", r.maxDiff <= 1e-8);
    j.key("rows").beginArr();
    for (auto& row : r.rows)
        j.beginObj().kv("workers", row.workers).kv("time", row.seconds).kv("speedup", row.speedup).kv("efficiency", row.efficiency).endObj();
    j.endArr().endObj();
    return j.str();
}

}  // namespace wb

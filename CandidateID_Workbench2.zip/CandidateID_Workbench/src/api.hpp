// Maps /api/* routes to the engineering modules.
#pragma once
#include <cstdlib>
#include <thread>
#include "benchmark.hpp"
#include "embedded.hpp"
#include "fem.hpp"
#include "geometry.hpp"
#include "http_server.hpp"
#include "nn.hpp"

namespace wb {

inline double numParam(const Request& r, const char* k, double def) {
    std::string s = r.param(k);
    if (s.empty()) return def;
    char* end = nullptr; double v = std::strtod(s.c_str(), &end);
    if (end == s.c_str() || *end) throw std::invalid_argument(std::string("Parameter '") + k + "' is not a number");
    return v;
}

inline std::vector<int> parseIntList(const std::string& s, std::vector<int> def) {
    if (s.empty()) return def;
    std::vector<int> v; std::string t;
    for (size_t i = 0; i <= s.size(); ++i) {
        if (i == s.size() || s[i] == ',') { if (!t.empty()) v.push_back(std::atoi(t.c_str())); t.clear(); }
        else t += s[i];
    }
    return v.empty() ? def : v;
}

inline std::string& dataDir() { static std::string d = "data"; return d; }

inline Response jsonOk(const std::string& body) { Response r; r.body = body; return r; }

inline Response handleApi(const Request& r) {
    if (r.path == "/api/info") {
        Json j; j.beginObj().kv("ok", true).kv("name", "PASS Engineering Workbench").kv("version", "1.0.0")
            .kv("cores", (int)std::max(1u, std::thread::hardware_concurrency())).kv("cpp", "C++17");
        j.key("modules").beginArr();
        for (const char* m : {"geometry", "thermal", "performance", "hardware", "neural"}) j.val(m);
        j.endArr().endObj();
        return jsonOk(j.str());
    }
    if (r.path == "/api/geometry" && r.method == "POST") {
        std::string name = r.param("name", "upload.stl");
        Mesh m = parseGeometry(name, r.body);
        return jsonOk(meshToJson(m, name, r.body.size()));
    }
    if (r.path == "/api/sample") {  // load a bundled sample file from ./data
        std::string name = r.param("name", "sample_cube.stl");
        if (name.find("..") != std::string::npos || name.find('/') != std::string::npos || name.find('\\') != std::string::npos)
            throw std::invalid_argument("Invalid sample name");
        std::ifstream f(dataDir() + "/" + name, std::ios::binary);
        if (!f) throw std::runtime_error("Sample file not found: " + name);
        std::ostringstream ss; ss << f.rdbuf(); std::string data = ss.str();
        return jsonOk(meshToJson(parseGeometry(name, data), name, data.size()));
    }
    if (r.path == "/api/thermal") {
        ThermalParams p;
        p.L = numParam(r, "L", 1.0); p.A = numParam(r, "A", 1e-4); p.k = numParam(r, "k", 10.0);
        p.q = numParam(r, "q", 10000.0); p.T0 = numParam(r, "T0", 100.0); p.TL = numParam(r, "TL", 20.0);
        p.N = (int)numParam(r, "N", 40);
        p.validate();
        return jsonOk(thermalToJson(p, {10, 20, 40, 80}));
    }
    if (r.path == "/api/benchmark") {
        int hw = (int)std::max(1u, std::thread::hardware_concurrency());
        int workers = (int)numParam(r, "workers", std::min(4, hw));
        int jobs = (int)numParam(r, "jobs", 6000);
        int elements = (int)numParam(r, "elements", 20000);
        if (workers < 1 || workers > 64 || jobs < 1 || jobs > 100000 || elements < 2 || elements > 1000000)
            throw std::invalid_argument("workers 1-64, jobs 1-100000, elements 2-1000000");
        return jsonOk(benchToJson(runBenchmark(workers, jobs, elements)));
    }
    if (r.path == "/api/hardware") {
        return jsonOk(hwToJson(simulateHardware((int)numParam(r, "samples", 120), numParam(r, "threshold", 60.0))));
    }
    if (r.path == "/api/neural") {
        NnConfig c;
        c.hidden = parseIntList(r.param("hidden"), {4});
        c.lr = numParam(r, "lr", 2.0); c.epochs = (int)numParam(r, "epochs", 2000);
        return jsonOk(nnToJson(trainNetwork(r.param("dataset", "xor"), c)));
    }
    Response nf; nf.status = 404; nf.body = "{\"ok\":false,\"error\":\"Unknown endpoint\"}"; return nf;
}

}  // namespace wb

#include <cstdlib>
#include <iostream>
#include <string>
#include "api.hpp"

static void openBrowser(const std::string& url) {
#ifdef _WIN32
    std::string cmd = "start \"\" \"" + url + "\"";
#elif defined(__APPLE__)
    std::string cmd = "open \"" + url + "\"";
#else
    std::string cmd = "xdg-open \"" + url + "\" >/dev/null 2>&1 &";
#endif
    if (std::system(cmd.c_str()) != 0) { /* browser not opened; URL is printed above */ }
}

int main(int argc, char** argv) {
    std::string web = "web";
    int port = 8080; bool open = true;
    for (int i = 1; i < argc; ++i) {
        std::string a = argv[i];
        if (a == "--no-browser") open = false;
        else if (a == "--port" && i + 1 < argc) port = std::atoi(argv[++i]);
        else if (a == "--web" && i + 1 < argc) web = argv[++i];
        else if (a == "--data" && i + 1 < argc) wb::dataDir() = argv[++i];
        else if (a == "--help") { std::cout << "workbench [--port N] [--web DIR] [--data DIR] [--no-browser]\n"; return 0; }
    }
    wb::HttpServer server(web, wb::handleApi);
    int p = server.start(port);
    if (p < 0) p = server.start(0);  // port busy: pick any free port
    if (p < 0) { std::cerr << "Error: could not start the local server.\n"; return 1; }
    std::string url = "http://127.0.0.1:" + std::to_string(p) + "/";
    std::cout << "PASS Engineering Workbench running at " << url << "\nPress Ctrl+C to stop.\n";
    if (open) openBrowser(url);
    server.wait();
    return 0;
}

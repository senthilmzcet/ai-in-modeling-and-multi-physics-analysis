// Minimal JSON writer (no external dependencies).
#pragma once
#include <cmath>
#include <cstdio>
#include <string>
#include <vector>

namespace wb {

inline std::string jescape(const std::string& s) {
    std::string o;
    o.reserve(s.size() + 2);
    for (unsigned char c : s) {
        switch (c) {
            case '"': o += "\\\""; break;
            case '\\': o += "\\\\"; break;
            case '\n': o += "\\n"; break;
            case '\r': o += "\\r"; break;
            case '\t': o += "\\t"; break;
            default:
                if (c < 0x20) { char b[8]; std::snprintf(b, sizeof b, "\\u%04x", c); o += b; }
                else o += static_cast<char>(c);
        }
    }
    return o;
}

inline std::string jnum(double v) {
    if (!std::isfinite(v)) return "null";
    char b[40];
    std::snprintf(b, sizeof b, "%.10g", v);
    return b;
}

// Builder: object/array with automatic commas.
class Json {
public:
    Json& beginObj() { sep(); s_ += '{'; first_.push_back(true); return *this; }
    Json& endObj()   { s_ += '}'; first_.pop_back(); return *this; }
    Json& beginArr() { sep(); s_ += '['; first_.push_back(true); return *this; }
    Json& endArr()   { s_ += ']'; first_.pop_back(); return *this; }
    Json& key(const std::string& k) { sep(); s_ += '"' + jescape(k) + "\":"; pendingKey_ = true; return *this; }
    Json& val(double v)             { sep(); s_ += jnum(v); return *this; }
    Json& val(int v)                { sep(); s_ += std::to_string(v); return *this; }
    Json& val(long long v)          { sep(); s_ += std::to_string(v); return *this; }
    Json& val(size_t v)             { sep(); s_ += std::to_string(v); return *this; }
    Json& val(bool v)               { sep(); s_ += v ? "true" : "false"; return *this; }
    Json& val(const std::string& v) { sep(); s_ += '"' + jescape(v) + '"'; return *this; }
    Json& val(const char* v)        { return val(std::string(v)); }
    template <class T> Json& kv(const std::string& k, const T& v) { key(k); return val(v); }
    Json& arr(const std::vector<double>& v) { beginArr(); for (double d : v) val(d); return endArr(); }
    Json& arr(const std::vector<int>& v)    { beginArr(); for (int d : v) val(d); return endArr(); }
    const std::string& str() const { return s_; }
private:
    void sep() {
        if (pendingKey_) { pendingKey_ = false; return; }
        if (!first_.empty()) { if (!first_.back()) s_ += ','; first_.back() = false; }
    }
    std::string s_;
    std::vector<bool> first_;
    bool pendingKey_ = false;
};

}  // namespace wb

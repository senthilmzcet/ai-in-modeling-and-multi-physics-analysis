// 1D steady-state heat conduction:  -k A T'' = q A,  T(0)=T0, T(L)=TL
// Linear two-node finite elements, tridiagonal (Thomas) solver.
#pragma once
#include <algorithm>
#include <cmath>
#include <stdexcept>
#include <vector>
#include "json.hpp"

namespace wb {

struct ThermalParams {
    double L = 1.0, A = 1e-4, k = 10.0, q = 10000.0, T0 = 100.0, TL = 20.0;
    int N = 40;
    void validate() const {
        if (!(L > 0) || !(A > 0) || !(k > 0)) throw std::invalid_argument("L, A and k must be > 0");
        if (N < 1 || N > 5000000) throw std::invalid_argument("N must be in [1, 5000000]");
    }
};

struct ThermalResult {
    std::vector<double> x, T, exact;
    double maxMidpointError = 0.0, maxNodalError = 0.0;
};

inline double exactTemp(const ThermalParams& p, double x) {
    double c1 = (p.TL - p.T0 + p.q * p.L * p.L / (2 * p.k)) / p.L;
    return -p.q / (2 * p.k) * x * x + c1 * x + p.T0;
}

// Solve into T (size N+1); scratch vectors passed to avoid allocations in benchmarks.
inline void solveThermalInto(const ThermalParams& p, std::vector<double>& T,
                             std::vector<double>& cp, std::vector<double>& dp) {
    p.validate();
    const int N = p.N, n = N - 1;  // interior unknowns
    const double h = p.L / N, kk = p.k * p.A / h, f = p.q * p.A * h / 2.0;
    T.assign(N + 1, 0.0);
    T[0] = p.T0; T[N] = p.TL;
    if (n <= 0) return;
    cp.assign(n, 0.0); dp.assign(n, 0.0);
    const double a = -kk, b = 2 * kk, c = -kk;
    for (int i = 0; i < n; ++i) {
        double rhs = 2 * f;
        if (i == 0) rhs -= a * p.T0;
        if (i == n - 1) rhs -= c * p.TL;
        if (i == 0) { cp[0] = c / b; dp[0] = rhs / b; }
        else {
            double m = b - a * cp[i - 1];
            cp[i] = c / m; dp[i] = (rhs - a * dp[i - 1]) / m;
        }
    }
    T[n] = dp[n - 1];  // interior node index n == N-1
    for (int i = n - 2; i >= 0; --i) T[i + 1] = dp[i] - cp[i] * T[i + 2];
}

inline ThermalResult solveThermal(const ThermalParams& p) {
    ThermalResult r;
    std::vector<double> cp, dp;
    solveThermalInto(p, r.T, cp, dp);
    const double h = p.L / p.N;
    r.x.resize(p.N + 1); r.exact.resize(p.N + 1);
    for (int i = 0; i <= p.N; ++i) {
        r.x[i] = i * h; r.exact[i] = exactTemp(p, r.x[i]);
        r.maxNodalError = std::max(r.maxNodalError, std::fabs(r.T[i] - r.exact[i]));
    }
    for (int e = 0; e < p.N; ++e) {
        double xm = (e + 0.5) * h, Tm = 0.5 * (r.T[e] + r.T[e + 1]);
        r.maxMidpointError = std::max(r.maxMidpointError, std::fabs(Tm - exactTemp(p, xm)));
    }
    return r;
}

inline std::string thermalToJson(const ThermalParams& p, const std::vector<int>& meshes) {
    ThermalResult r = solveThermal(p);
    Json j; j.beginObj();
    j.kv("ok", true).kv("N", p.N);
    j.key("x").arr(r.x).key("T").arr(r.T).key("exact").arr(r.exact);
    j.kv("maxMidpointError", r.maxMidpointError).kv("maxNodalError", r.maxNodalError);
    j.kv("maxTemp", *std::max_element(r.T.begin(), r.T.end()));
    j.key("convergence").beginArr();
    double prev = -1; bool converged = true;
    for (int n : meshes) {
        ThermalParams q = p; q.N = n;
        double e = solveThermal(q).maxMidpointError;
        if (prev >= 0 && e > prev * 1.0000001 && e > 1e-12) converged = false;
        prev = e;
        j.beginObj().kv("N", n).kv("error", e).endObj();
    }
    j.endArr().kv("converged", converged);
    j.endObj();
    return j.str();
}

}  // namespace wb

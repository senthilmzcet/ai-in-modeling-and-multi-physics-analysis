'use strict';
const $ = (s, r = document) => r.querySelector(s);
const esc = s => String(s).replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const fmt = (v, d = 3) => (v === null || v === undefined || Number.isNaN(v)) ? '–' : (Math.abs(v) !== 0 && (Math.abs(v) < 1e-3 || Math.abs(v) >= 1e6) ? v.toExponential(2) : Number(v.toFixed(d)).toString());
const state = {};          // last results, used by the dashboard

/* ---------- API ---------- */
function setStatus(kind, text) { const s = $('#status'); s.className = 'status ' + kind; s.textContent = text; }
async function api(path, opts) {
  setStatus('busy', 'Working…');
  try {
    const r = await fetch(path, opts);
    let j; try { j = await r.json(); } catch { throw new Error('Server returned an invalid response'); }
    if (!r.ok || j.ok === false) throw new Error(j.error || ('HTTP ' + r.status));
    setStatus('ok', 'Ready');
    return j;
  } catch (e) { setStatus('err', 'Error'); throw e; }
}
const qs = o => Object.entries(o).map(([k, v]) => encodeURIComponent(k) + '=' + encodeURIComponent(v)).join('&');
function badge(el, ok, title, text) {
  el.className = 'badge' + (ok ? '' : ' bad');
  el.innerHTML = '<b>' + esc(title) + '</b><span>' + esc(text || '') + '</span>';
}
function table(el, head, rows) {
  el.innerHTML = '<thead><tr>' + head.map(h => '<th>' + esc(h) + '</th>').join('') + '</tr></thead><tbody>' +
    rows.map(r => '<tr>' + r.map(c => '<td>' + esc(c) + '</td>').join('') + '</tr>').join('') + '</tbody>';
}
function kv(el, pairs) { el.innerHTML = pairs.map(([k, v]) => '<dt>' + esc(k) + '</dt><dd>' + esc(v) + '</dd>').join(''); }

/* ---------- Navigation ---------- */
const titles = { home: 'Engineering Dashboard', geometry: 'STL / CSV 3D Visualization', thermal: '1D Thermal FEM Solver',
  perf: 'Serial / Parallel CPU Benchmark', hardware: 'Microcontroller, FPGA & JTAG Simulation', neural: 'Neural Network Backpropagation' };
function show(page) {
  document.querySelectorAll('.page').forEach(p => p.classList.toggle('on', p.id === page));
  document.querySelectorAll('#nav button').forEach(b => b.classList.toggle('on', b.dataset.page === page));
  $('#title').textContent = titles[page];
  location.hash = page;
  if (page === 'geometry') requestAnimationFrame(draw3d);
}
$('#nav').addEventListener('click', e => { const b = e.target.closest('button'); if (b) show(b.dataset.page); });

async function guarded(btn, fn, msgEl) {
  btn.disabled = true;
  try { await fn(); if (msgEl) msgEl.innerHTML = ''; }
  catch (e) { const t = msgEl || null; if (t) { t.innerHTML = '<div class="badge bad"><b>Error</b><span>' + esc(e.message) + '</span></div>'; } else alert(e.message); }
  finally { btn.disabled = false; }
}

/* ---------- Chart helpers ---------- */
function niceTicks(lo, hi, n = 5) {
  if (hi === lo) { hi = lo + 1; }
  const raw = (hi - lo) / n, p = Math.pow(10, Math.floor(Math.log10(raw))), f = raw / p;
  const step = (f < 1.5 ? 1 : f < 3.5 ? 2 : f < 7.5 ? 5 : 10) * p, t = [];
  for (let v = Math.ceil(lo / step) * step; v <= hi + step * 1e-9; v += step) t.push(+v.toPrecision(12));
  return t;
}
function plot(canvas, o) {
  const ctx = canvas.getContext('2d'), W = canvas.width, H = canvas.height, m = { l: 62, r: 16, t: 14, b: 46 };
  ctx.clearRect(0, 0, W, H); ctx.font = '12px Segoe UI, sans-serif';
  const ly = o.logY, ty = v => ly ? Math.log10(Math.max(v, 1e-300)) : v;
  let y0 = o.ymin, y1 = o.ymax;
  if (ly) { y0 = Math.floor(ty(y0)); y1 = Math.ceil(ty(y1)); } else { const t = niceTicks(y0, y1); y0 = Math.min(y0, t[0]); y1 = Math.max(y1, t[t.length - 1]); }
  const X = v => m.l + (v - o.xmin) / (o.xmax - o.xmin || 1) * (W - m.l - m.r);
  const Y = v => H - m.b - (ty(v) - y0) / (y1 - y0 || 1) * (H - m.t - m.b);
  ctx.strokeStyle = '#e3e9f3'; ctx.fillStyle = '#5b6b85'; ctx.lineWidth = 1;
  ctx.textAlign = 'right';
  const yt = ly ? Array.from({ length: y1 - y0 + 1 }, (_, i) => Math.pow(10, y0 + i)) : niceTicks(y0, y1);
  for (const v of yt) { const y = Y(v); ctx.beginPath(); ctx.moveTo(m.l, y); ctx.lineTo(W - m.r, y); ctx.stroke(); ctx.fillText(ly ? '1e' + Math.round(Math.log10(v)) : fmt(v, 2), m.l - 6, y + 4); }
  ctx.textAlign = 'center';
  const xt = o.xticks || niceTicks(o.xmin, o.xmax);
  for (const v of xt) { const x = X(v); ctx.beginPath(); ctx.moveTo(x, m.t); ctx.lineTo(x, H - m.b); ctx.stroke(); ctx.fillText(o.xlabels ? o.xlabels(v) : fmt(v, 2), x, H - m.b + 16); }
  ctx.strokeStyle = '#8a98b0'; ctx.strokeRect(m.l, m.t, W - m.l - m.r, H - m.t - m.b);
  ctx.fillStyle = '#14233b'; ctx.fillText(o.xtitle || '', (m.l + W - m.r) / 2, H - 8);
  ctx.save(); ctx.translate(14, (m.t + H - m.b) / 2); ctx.rotate(-Math.PI / 2); ctx.fillText(o.ytitle || '', 0, 0); ctx.restore();
  ctx.save(); ctx.beginPath(); ctx.rect(m.l, m.t, W - m.l - m.r, H - m.t - m.b); ctx.clip();
  (o.series || []).forEach(s => {
    ctx.strokeStyle = ctx.fillStyle = s.color; ctx.lineWidth = s.width || 2; ctx.setLineDash(s.dash || []);
    ctx.beginPath(); s.x.forEach((xv, i) => { const px = X(xv), py = Y(s.y[i]); i ? ctx.lineTo(px, py) : ctx.moveTo(px, py); }); ctx.stroke();
    if (s.dots) { ctx.setLineDash([]); s.x.forEach((xv, i) => { if (i % s.dots === 0) { ctx.beginPath(); ctx.arc(X(xv), Y(s.y[i]), 3, 0, 7); ctx.fill(); } }); }
  });
  ctx.restore(); ctx.setLineDash([]);
  if (o.legend) { ctx.textAlign = 'left'; o.legend.forEach((l, i) => { const x = W - m.r - 150, y = m.t + 18 + i * 18; ctx.fillStyle = l.color; ctx.fillRect(x, y - 8, 18, 3); ctx.fillStyle = '#14233b'; ctx.fillText(l.name, x + 24, y - 2); }); }
  if (o.hlines) o.hlines.forEach(h => { ctx.strokeStyle = h.color; ctx.setLineDash([5, 4]); ctx.beginPath(); ctx.moveTo(m.l, Y(h.y)); ctx.lineTo(W - m.r, Y(h.y)); ctx.stroke(); ctx.setLineDash([]); });
  return { X, Y };
}
function bars(canvas, labels, values, xtitle, ytitle) {
  const ymax = Math.max(...values) * 1.15, n = values.length;
  const { X, Y } = plot(canvas, { xmin: 0.4, xmax: n + 0.6, ymin: 0, ymax, xticks: labels.map((_, i) => i + 1), xlabels: v => labels[v - 1], xtitle, ytitle, series: [] });
  const ctx = canvas.getContext('2d'), bw = (X(2) - X(1)) * 0.6;
  values.forEach((v, i) => { const x = X(i + 1), y = Y(v); ctx.fillStyle = '#2f7be8'; ctx.fillRect(x - bw / 2, y, bw, Y(0) - y); ctx.fillStyle = '#14233b'; ctx.textAlign = 'center'; ctx.fillText(fmt(v, 2), x, y - 5); });
}

/* ---------- 3D viewer ---------- */
const gl = $('#gl'), gctx = gl.getContext('2d');
const view = { yaw: -0.7, pitch: 0.5, zoom: 1, px: 0, py: 0, tool: 'rotate', mesh: null };
function hue(t) { return 'hsl(' + Math.round((1 - Math.min(1, Math.max(0, t))) * 240) + ',85%,50%)'; }
function draw3d() {
  const W = gl.width, H = gl.height, c = gctx;
  c.clearRect(0, 0, W, H);
  const g = c.createLinearGradient(0, 0, 0, H); g.addColorStop(0, '#0e1a31'); g.addColorStop(1, '#0a1220'); c.fillStyle = g; c.fillRect(0, 0, W, H);
  const m = view.mesh; if (!m) { c.fillStyle = '#8fa3c6'; c.font = '15px Segoe UI'; c.textAlign = 'center'; c.fillText('Load an STL or CSV file to begin', W / 2, H / 2); return; }
  const P = m.positions, n = P.length / 3, ctr = m.bboxMin.map((v, i) => (v + m.bboxMax[i]) / 2);
  const size = Math.max(...m.bboxMax.map((v, i) => v - m.bboxMin[i])) || 1;
  const cy = Math.cos(view.yaw), sy = Math.sin(view.yaw), cp = Math.cos(view.pitch), sp = Math.sin(view.pitch);
  const sc = view.zoom * Math.min(W, H) * 0.55 / size, cam = 3.2 * size;
  const T = new Float32Array(n * 3), S = new Float32Array(n * 2);
  const xform = (x, y, z) => { // Z-up: yaw about Z, then pitch about X
    const a = x * cy - y * sy, b = x * sy + y * cy, d = b * cp - z * sp, e = b * sp + z * cp; return [a, d, e]; };
  for (let i = 0; i < n; i++) {
    const [a, d, e] = xform(P[3 * i] - ctr[0], P[3 * i + 1] - ctr[1], P[3 * i + 2] - ctr[2]);
    const k = cam / (cam + d);
    T[3 * i] = a; T[3 * i + 1] = d; T[3 * i + 2] = e;
    S[2 * i] = W / 2 + view.px + a * k * sc; S[2 * i + 1] = H / 2 + view.py - e * k * sc;
  }
  const span = (m.bboxMax[0] - m.bboxMin[0]) || 1;
  let vlo = 0, vhi = 1; const hasVal = m.values.length === n;
  if (hasVal) { vlo = Math.min(...m.values); vhi = Math.max(...m.values); if (vhi === vlo) vhi = vlo + 1; }
  const col = i => hasVal ? hue((m.values[i] - vlo) / (vhi - vlo)) : hue((P[3 * i] - m.bboxMin[0]) / span);
  if (m.indices.length === 0) {  // point cloud
    const order = Array.from({ length: n }, (_, i) => i).sort((a, b) => T[3 * b + 1] - T[3 * a + 1]);
    for (const i of order) { c.fillStyle = col(i); c.beginPath(); c.arc(S[2 * i], S[2 * i + 1], 3.2, 0, 7); c.fill(); }
  } else {
    const I = m.indices, nt = I.length / 3, tris = new Array(nt);
    for (let t = 0; t < nt; t++) tris[t] = [t, (T[3 * I[3 * t] + 1] + T[3 * I[3 * t + 1] + 1] + T[3 * I[3 * t + 2] + 1]) / 3];
    tris.sort((a, b) => b[1] - a[1]);  // far to near
    const wire = $('#wire').checked && nt < 40000;
    for (const [t] of tris) {
      const a = I[3 * t], b = I[3 * t + 1], d = I[3 * t + 2];
      const ux = T[3 * b] - T[3 * a], uy = T[3 * b + 1] - T[3 * a + 1], uz = T[3 * b + 2] - T[3 * a + 2];
      const vx = T[3 * d] - T[3 * a], vy = T[3 * d + 1] - T[3 * a + 1], vz = T[3 * d + 2] - T[3 * a + 2];
      let nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx; const l = Math.hypot(nx, ny, nz) || 1;
      const lit = Math.abs((nx * -0.3 + ny * -0.5 + nz * 0.8) / l);
      c.fillStyle = col(a); c.beginPath(); c.moveTo(S[2 * a], S[2 * a + 1]); c.lineTo(S[2 * b], S[2 * b + 1]); c.lineTo(S[2 * d], S[2 * d + 1]); c.closePath(); c.fill();
      c.fillStyle = 'rgba(0,0,0,' + (0.42 * (1 - lit)).toFixed(3) + ')'; c.fill();
      if (wire) { c.strokeStyle = 'rgba(255,255,255,.28)'; c.lineWidth = 0.6; c.stroke(); }
    }
  }
  // axis gizmo
  const ax = [['X', '#ff5a5a', 1, 0, 0], ['Y', '#4ddc7a', 0, 1, 0], ['Z', '#5aa2ff', 0, 0, 1]];
  c.font = '12px Segoe UI'; c.textAlign = 'center';
  for (const [nm, cl, x, y, z] of ax) { const [a, , e] = xform(x, y, z); c.strokeStyle = c.fillStyle = cl; c.lineWidth = 2; c.beginPath(); c.moveTo(50, H - 50); c.lineTo(50 + a * 34, H - 50 - e * 34); c.stroke(); c.fillText(nm, 50 + a * 44, H - 46 - e * 44); }
}
let drag = null;
gl.addEventListener('pointerdown', e => { drag = { x: e.clientX, y: e.clientY, pan: view.tool === 'pan' || e.shiftKey || e.button === 2 }; gl.setPointerCapture(e.pointerId); gl.style.cursor = 'grabbing'; });
gl.addEventListener('pointermove', e => {
  if (!drag) return; const k = gl.width / gl.getBoundingClientRect().width, dx = (e.clientX - drag.x) * k, dy = (e.clientY - drag.y) * k;
  drag.x = e.clientX; drag.y = e.clientY;
  if (drag.pan) { view.px += dx; view.py += dy; } else { view.yaw += dx * 0.01; view.pitch = Math.max(-1.55, Math.min(1.55, view.pitch + dy * 0.01)); }
  draw3d();
});
gl.addEventListener('pointerup', () => { drag = null; gl.style.cursor = 'grab'; });
gl.addEventListener('contextmenu', e => e.preventDefault());
gl.addEventListener('wheel', e => { e.preventDefault(); view.zoom = Math.min(20, Math.max(0.1, view.zoom * (e.deltaY < 0 ? 1.1 : 1 / 1.1))); draw3d(); }, { passive: false });
document.querySelectorAll('.tool').forEach(b => b.addEventListener('click', () => { view.tool = b.dataset.tool; document.querySelectorAll('.tool').forEach(x => x.classList.toggle('on', x === b)); }));
$('#zoomIn').onclick = () => { view.zoom = Math.min(20, view.zoom * 1.25); draw3d(); };
$('#fit').onclick = () => { Object.assign(view, { yaw: -0.7, pitch: 0.5, zoom: 1, px: 0, py: 0 }); draw3d(); };
$('#wire').onchange = draw3d;

function showMesh(j) {
  view.mesh = j; Object.assign(view, { yaw: -0.7, pitch: 0.5, zoom: 1, px: 0, py: 0 });
  const bb = (a, b) => [0, 1, 2].map(i => fmt(a[i], 3) + ' – ' + fmt(b[i], 3));
  kv($('#gInfo'), [['Name', j.name], ['Format', j.format], ['Vertices', j.vertices.toLocaleString()], ['Triangles', j.triangles.toLocaleString()],
    ['File size', (j.fileSize / 1024).toFixed(1) + ' KB'], ['Units', j.units], ['X range', bb(j.bboxMin, j.bboxMax)[0]], ['Y range', bb(j.bboxMin, j.bboxMax)[1]], ['Z range', bb(j.bboxMin, j.bboxMax)[2]]]);
  badge($('#gMsg'), true, (j.triangles ? 'STL' : 'CSV') + ' file loaded successfully', 'File is valid and ready for visualization.');
  state.geometry = j; refreshCards(); draw3d();
}
const geoErr = e => { $('#gMsg').innerHTML = '<div class="badge bad"><b>Could not load file</b><span>' + esc(e.message) + '</span></div>'; };
$('#choose').onclick = () => $('#file').click();
$('#file').onchange = async e => {
  const f = e.target.files[0]; if (!f) return;
  try { showMesh(await api('/api/geometry?' + qs({ name: f.name }), { method: 'POST', headers: { 'Content-Type': 'application/octet-stream' }, body: await f.arrayBuffer() })); }
  catch (err) { geoErr(err); } finally { e.target.value = ''; }
};
$('#sampleStl').onclick = () => api('/api/sample?name=sample_cube.stl').then(showMesh).catch(geoErr);
$('#sampleCsv').onclick = () => api('/api/sample?name=sample_points.csv').then(showMesh).catch(geoErr);
['dragover', 'drop'].forEach(ev => gl.addEventListener(ev, e => { e.preventDefault(); if (ev === 'drop' && e.dataTransfer.files[0]) { const f = e.dataTransfer.files[0]; f.arrayBuffer().then(buf => api('/api/geometry?' + qs({ name: f.name }), { method: 'POST', body: buf })).then(showMesh).catch(geoErr); } }));

/* ---------- Thermal ---------- */
const tFields = [['L', 'Length L (m)', 1.0], ['A', 'Area A (m²)', 1e-4], ['k', 'Conductivity k (W/m·K)', 10], ['q', 'Heat generation q (W/m³)', 10000], ['T0', 'T(0) (°C)', 100], ['TL', 'T(L) (°C)', 20], ['N', 'Elements N', 40]];
$('#tForm').innerHTML = tFields.map(([id, lab, v]) => '<label>' + esc(lab) + '<input id="t_' + id + '" type="number" step="any" value="' + v + '"></label>').join('');
async function runThermal() {
  const p = {}; tFields.forEach(([id]) => p[id] = $('#t_' + id).value);
  const j = await api('/api/thermal?' + qs(p)); state.thermal = j;
  $('#tTitle').textContent = 'Temperature distribution (N = ' + j.N + ')';
  const lo = Math.min(...j.T, ...j.exact), hi = Math.max(...j.T, ...j.exact);
  plot($('#tChart'), { xmin: 0, xmax: j.x[j.x.length - 1], ymin: lo, ymax: hi, xtitle: 'Position x (m)', ytitle: 'Temperature (°C)',
    series: [{ x: j.x, y: j.exact, color: '#e5484d', dash: [6, 4], width: 2 }, { x: j.x, y: j.T, color: '#1f6fe0', dots: Math.max(1, Math.floor(j.x.length / 30)) }],
    legend: [{ name: 'FE (N=' + j.N + ')', color: '#1f6fe0' }, { name: 'Exact', color: '#e5484d' }] });
  table($('#tTable'), ['Elements (N)', 'Max error (°C)'], j.convergence.map(c => [c.N, fmt(c.error, 4)]));
  badge($('#tBadge'), j.converged, j.converged ? 'Converged' : 'Not converging', j.converged ? 'Error decreases with mesh refinement.' : 'Error did not decrease with refinement.');
  refreshCards();
}
$('#tRun').onclick = e => guarded(e.target, runThermal, $('#tBadge'));

/* ---------- Performance ---------- */
async function runBench() {
  const j = await api('/api/benchmark?' + qs({ workers: $('#bWorkers').value, jobs: $('#bJobs').value, elements: $('#bElems').value })); state.bench = j;
  kv($('#sysInfo'), [['CPU (logical cores)', j.logicalCores], ['Compiler', j.compiler], ['Optimisation', j.optimisation], ['Solves × elements', j.jobs + ' × ' + j.elements]]);
  bars($('#bChart'), j.rows.map(r => String(r.workers)), j.rows.map(r => r.time), 'Workers', 'Time (s)');
  table($('#bTable'), ['Workers', 'Time (s)', 'Speedup (T1/Tp)', 'Efficiency (T1/Tp)/p'], j.rows.map(r => [r.workers, fmt(r.time, 3), fmt(r.speedup, 2), fmt(r.efficiency, 2)]));
  badge($('#bBadge'), j.match, j.match ? 'Serial / Parallel results match' : 'Results differ', 'Max |ΔT| = ' + j.maxDiff.toExponential(1) + ' °C (limit 1e-8)');
  refreshCards();
}
$('#bRun').onclick = e => guarded(e.target, runBench, $('#bBadge'));

/* ---------- Hardware ---------- */
async function runHw() {
  const j = await api('/api/hardware?' + qs({ threshold: $('#hThr').value })); state.hw = j;
  kv($('#hwMcu'), [['CPU', j.mcu.cpu], ['Clock', j.mcu.clockMHz + ' MHz'], ['Flash', j.mcu.flashKB + ' KB'], ['RAM', j.mcu.ramKB + ' KB'], ['ADC', j.mcu.adcBits + '-bit, ' + j.mcu.vref + ' V']]);
  kv($('#hwFpga'), [['Device', j.fpga.device], ['Logic elements', j.fpga.logicElements.toLocaleString()], ['RAM blocks', j.fpga.ramBlocks], ['Design', j.fpga.design]]);
  const t = j.t, hi = Math.max(...j.sensor, j.threshold) + 5, lo = Math.min(...j.sensor) - 5;
  plot($('#hChart'), { xmin: 0, xmax: t[t.length - 1], ymin: lo, ymax: hi, xtitle: 'Time (s)', ytitle: 'Temperature (°C)',
    series: [{ x: t, y: j.sensor, color: '#9fb4d6', width: 1.5 }, { x: t, y: j.filtered, color: '#1f6fe0' }, { x: t, y: j.alarm.map(a => a ? hi - 2 : lo + 2), color: '#e5484d', width: 2 }],
    hlines: [{ y: j.threshold, color: '#e5a000' }], legend: [{ name: 'Sensor', color: '#9fb4d6' }, { name: 'MCU filtered', color: '#1f6fe0' }, { name: 'FPGA alarm', color: '#e5484d' }] });
  badge($('#hJtag'), j.jtag.connected, j.jtag.connected ? 'JTAG connection successful' : 'JTAG connection failed',
    'Device ID: ' + j.jtag.deviceId + ' · Status: ' + j.jtag.status + ' · ' + j.jtag.tckCycles + ' TCK cycles · alarm samples: ' + j.alarmSamples);
  refreshCards();
}
$('#hRun').onclick = e => guarded(e.target, runHw, $('#hJtag'));

/* ---------- Neural network ---------- */
async function runNn() {
  const j = await api('/api/neural?' + qs({ dataset: $('#nData').value, hidden: $('#nHidden').value, lr: $('#nLr').value, epochs: $('#nEp').value })); state.nn = j;
  const lo = Math.max(1e-12, Math.min(...j.loss)), hi = Math.max(...j.loss);
  plot($('#nChart'), { xmin: 1, xmax: j.epochs[j.epochs.length - 1], ymin: lo, ymax: hi, logY: true, xtitle: 'Epoch', ytitle: 'Loss (MSE)', series: [{ x: j.epochs, y: j.loss, color: '#1f6fe0' }] });
  table($('#nTable'), ['In 1', 'In 2', 'Target', 'Predicted'], j.rows.map(r => [r.in1, r.in2, r.target, fmt(r.predicted, 3)]));
  badge($('#nBadge'), j.allCorrect, j.allCorrect ? 'Model trained successfully' : 'Not converged', 'Final loss: ' + j.finalLoss.toExponential(1) + (j.allCorrect ? '' : ' — try more epochs or a higher learning rate'));
  refreshCards();
}
$('#nRun').onclick = e => guarded(e.target, runNn, $('#nBadge'));

/* ---------- Dashboard ---------- */
const cardDefs = [
  ['geometry', 'Geometry', () => state.geometry ? state.geometry.triangles.toLocaleString() + ' triangles' : 'No file loaded', () => state.geometry ? state.geometry.name + ' · ' + state.geometry.vertices.toLocaleString() + ' vertices' : 'Open to load an STL or CSV'],
  ['thermal', 'Thermal FEM', () => state.thermal ? fmt(state.thermal.maxTemp, 1) + ' °C peak' : 'Not run', () => state.thermal ? 'N = ' + state.thermal.N + ' · ' + (state.thermal.converged ? 'converged' : 'check mesh') : 'Rod conduction solver'],
  ['perf', 'Performance', () => state.bench ? fmt(state.bench.rows[state.bench.rows.length - 1].speedup, 2) + '× speedup' : 'Not run', () => state.bench ? state.bench.rows.length + ' workers · results ' + (state.bench.match ? 'match' : 'differ') : 'Serial vs parallel solves'],
  ['hardware', 'Hardware', () => state.hw ? state.hw.jtag.deviceId : 'Not run', () => state.hw ? 'JTAG ' + (state.hw.jtag.connected ? 'connected' : 'failed') + ' · ' + state.hw.alarmSamples + ' alarm samples' : 'MCU, FPGA and JTAG'],
  ['neural', 'Neural Network', () => state.nn ? state.nn.finalLoss.toExponential(1) + ' loss' : 'Not trained', () => state.nn ? state.nn.dataset.toUpperCase() + ' · ' + (state.nn.allCorrect ? 'all correct' : 'not converged') : 'Backpropagation demo']];
function refreshCards() {
  $('#cards').innerHTML = cardDefs.map(([id, name, big, sub]) => '<button class="card" data-go="' + id + '"><h2>' + esc(name) + '</h2><div class="big">' + esc(big()) + '</div><div class="sub">' + esc(sub()) + '</div></button>').join('');
}
$('#cards').addEventListener('click', e => { const c = e.target.closest('.card'); if (c) show(c.dataset.go); });
$('#runAll').onclick = async e => {
  e.target.disabled = true;
  try {
    await api('/api/sample?name=sample_cube.stl').then(showMesh);
    await runThermal(); await runHw(); await runNn(); await runBench();
  } catch (err) { alert(err.message); } finally { e.target.disabled = false; refreshCards(); }
};

/* ---------- Init ---------- */
(async () => {
  refreshCards();
  try {
    const info = await api('/api/info');
    $('#bWorkers').value = Math.min(4, info.cores); $('#bWorkers').max = Math.min(64, info.cores * 2);
    kv($('#sysInfo'), [['CPU (logical cores)', info.cores], ['Standard', info.cpp]]);
  } catch (e) { setStatus('err', 'Server offline'); }
  draw3d();
  const h = location.hash.slice(1); if (titles[h]) show(h);
})();

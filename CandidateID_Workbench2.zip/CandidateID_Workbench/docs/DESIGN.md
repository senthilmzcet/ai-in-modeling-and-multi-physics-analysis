# Design notes

## Architecture
`workbench.exe` = header-only engineering modules + a small HTTP/1.1 server (Winsock/POSIX sockets, localhost only).
The browser frontend (plain HTML/CSS/JS, canvas-based charts and a software 3D renderer) calls a JSON API.
No third-party dependencies, so the build needs only CMake and a C++17 compiler.

## API
| Endpoint | Purpose |
|---|---|
| `GET /api/info` | version, core count |
| `POST /api/geometry?name=f.stl` (raw body) | parse STL/CSV, returns bbox, counts, unique vertices, indices |
| `GET /api/sample?name=` | parse bundled file from `data/` |
| `GET /api/thermal?L&A&k&q&T0&TL&N` | FEM solution, exact solution, convergence table |
| `GET /api/benchmark?workers&jobs&elements` | serial vs parallel timings |
| `GET /api/hardware?threshold` | MCU/FPGA/JTAG simulation |
| `GET /api/neural?dataset&hidden&lr&epochs` | training loss history and predictions |

Errors return HTTP 400 with `{"ok":false,"error":"..."}`; the UI shows them inline.

## Thermal FEM
Governing equation `-k A T'' = q A`, `T(0)=T0`, `T(L)=TL`. Linear 2-node elements; element stiffness `kA/h [1 -1; -1 1]`,
load `qAh/2` per node. Dirichlet nodes eliminated, remaining tridiagonal system solved with the Thomas algorithm (O(N)).
Exact solution `T = -q/(2k) x^2 + c1 x + T0`. Linear FE is nodally exact in 1D; the error reported is at element midpoints,
which falls as O(h^2) (factor 4 per refinement).

## Benchmark
`jobs` independent solves (parameters vary by job index) are interleaved over `workers` `std::thread`s; each writes its own slot,
so no locking is needed. Time is best-of-two; speedup = T1/Tp, efficiency = speedup/p. Serial results are compared with parallel.

## Hardware simulation
* **JTAG**: full IEEE 1149.1 TAP state machine. `readIdcode()` resets via 5x TMS=1, walks Run-Test/Idle -> Select-DR -> Capture-DR -> Shift-DR, shifts 32 bits, returns to idle. Simulated device ID `0x04A3`.
* **FPGA**: 4-input LUT truth table implementing a majority-of-3 filter on the over-temperature comparator.
* **MCU**: LM35-style sensor (10 mV/degC) -> 12-bit ADC (3.3 V) -> exponential moving average -> threshold comparator.

## Neural network
MLP, sigmoid activations, Xavier init (fixed seed => reproducible), MSE loss, full-batch gradient descent. Tests include a numerical gradient check.

## Limits / assumptions
STL vertices are merged at 1e-5 m resolution. The software renderer sorts triangles per frame (fine to ~50k triangles).
Request bodies are limited to 64 MB. Units are assumed to be meters.

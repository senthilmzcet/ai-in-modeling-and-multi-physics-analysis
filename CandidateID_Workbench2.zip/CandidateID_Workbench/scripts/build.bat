@echo off
REM Builds the workbench (Release) and runs the tests. Requires CMake + Visual Studio Build Tools (or MinGW).
cd /d "%~dp0.."
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
if errorlevel 1 goto :fail
cmake --build build --config Release
if errorlevel 1 goto :fail
ctest --test-dir build -C Release --output-on-failure
if errorlevel 1 goto :fail
echo.
echo Build OK. Start with scripts\run.bat
exit /b 0
:fail
echo.
echo BUILD FAILED - see messages above.
exit /b 1

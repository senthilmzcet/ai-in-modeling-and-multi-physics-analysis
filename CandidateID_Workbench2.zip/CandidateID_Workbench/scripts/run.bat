@echo off
cd /d "%~dp0.."
if exist build\Release\workbench.exe (cd build\Release) else (cd build)
workbench.exe %*
